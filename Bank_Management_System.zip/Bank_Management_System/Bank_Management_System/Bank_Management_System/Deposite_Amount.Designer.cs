﻿namespace Bank_Management_System
{
    partial class Deposite_Amount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Main_Panel = new System.Windows.Forms.Panel();
            this.Submit_Button = new System.Windows.Forms.Panel();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.Captcha = new System.Windows.Forms.Label();
            this.text_Captcha = new System.Windows.Forms.TextBox();
            this.Deposite_Panel = new System.Windows.Forms.Panel();
            this.DepositeAmount = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.AcDetailpanel = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.Lastname = new System.Windows.Forms.Label();
            this.AcHoldername = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.AccountBal = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.CheckAcBalance = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.Clear_Panel = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.Main_Panel.SuspendLayout();
            this.Submit_Button.SuspendLayout();
            this.Deposite_Panel.SuspendLayout();
            this.AcDetailpanel.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.Clear_Panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // Main_Panel
            // 
            this.Main_Panel.BackColor = System.Drawing.Color.Teal;
            this.Main_Panel.Controls.Add(this.Clear_Panel);
            this.Main_Panel.Controls.Add(this.Submit_Button);
            this.Main_Panel.Controls.Add(this.Deposite_Panel);
            this.Main_Panel.Controls.Add(this.AcDetailpanel);
            this.Main_Panel.Controls.Add(this.panel3);
            this.Main_Panel.Location = new System.Drawing.Point(105, 204);
            this.Main_Panel.Name = "Main_Panel";
            this.Main_Panel.Size = new System.Drawing.Size(1717, 727);
            this.Main_Panel.TabIndex = 12;
            // 
            // Submit_Button
            // 
            this.Submit_Button.BackColor = System.Drawing.Color.DarkCyan;
            this.Submit_Button.Controls.Add(this.label39);
            this.Submit_Button.Controls.Add(this.label40);
            this.Submit_Button.Controls.Add(this.Captcha);
            this.Submit_Button.Controls.Add(this.text_Captcha);
            this.Submit_Button.Location = new System.Drawing.Point(12, 502);
            this.Submit_Button.Name = "Submit_Button";
            this.Submit_Button.Size = new System.Drawing.Size(1687, 99);
            this.Submit_Button.TabIndex = 27;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Calisto MT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.Yellow;
            this.label39.Location = new System.Drawing.Point(945, 17);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(99, 17);
            this.label39.TabIndex = 37;
            this.label39.Text = "Captcha Code";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Calisto MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.Color.Yellow;
            this.label40.Location = new System.Drawing.Point(680, 15);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(77, 22);
            this.label40.TabIndex = 34;
            this.label40.Text = "Captcha";
            // 
            // Captcha
            // 
            this.Captcha.AutoSize = true;
            this.Captcha.BackColor = System.Drawing.Color.LightSkyBlue;
            this.Captcha.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Captcha.Font = new System.Drawing.Font("Buxton Sketch", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Captcha.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.Captcha.Location = new System.Drawing.Point(948, 34);
            this.Captcha.Name = "Captcha";
            this.Captcha.Size = new System.Drawing.Size(118, 45);
            this.Captcha.TabIndex = 35;
            this.Captcha.Text = "Captcha";
            // 
            // text_Captcha
            // 
            this.text_Captcha.BackColor = System.Drawing.Color.CadetBlue;
            this.text_Captcha.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.text_Captcha.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_Captcha.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.text_Captcha.Location = new System.Drawing.Point(684, 40);
            this.text_Captcha.Name = "text_Captcha";
            this.text_Captcha.Size = new System.Drawing.Size(174, 39);
            this.text_Captcha.TabIndex = 36;
            this.text_Captcha.KeyDown += new System.Windows.Forms.KeyEventHandler(this.text_Captcha_KeyDown);
            // 
            // Deposite_Panel
            // 
            this.Deposite_Panel.BackColor = System.Drawing.Color.DarkCyan;
            this.Deposite_Panel.Controls.Add(this.DepositeAmount);
            this.Deposite_Panel.Controls.Add(this.label3);
            this.Deposite_Panel.Location = new System.Drawing.Point(12, 362);
            this.Deposite_Panel.Name = "Deposite_Panel";
            this.Deposite_Panel.Size = new System.Drawing.Size(1687, 86);
            this.Deposite_Panel.TabIndex = 26;
            // 
            // DepositeAmount
            // 
            this.DepositeAmount.BackColor = System.Drawing.Color.CadetBlue;
            this.DepositeAmount.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DepositeAmount.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DepositeAmount.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.DepositeAmount.Location = new System.Drawing.Point(850, 26);
            this.DepositeAmount.MaxLength = 15;
            this.DepositeAmount.Name = "DepositeAmount";
            this.DepositeAmount.Size = new System.Drawing.Size(264, 43);
            this.DepositeAmount.TabIndex = 21;
            this.DepositeAmount.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DepositeAmount_KeyDown);
            this.DepositeAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DepositeAmount_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.DarkCyan;
            this.label3.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.OldLace;
            this.label3.Location = new System.Drawing.Point(339, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(505, 43);
            this.label3.TabIndex = 21;
            this.label3.Text = "Enter Deposite Amount : ";
            // 
            // AcDetailpanel
            // 
            this.AcDetailpanel.BackColor = System.Drawing.Color.DarkCyan;
            this.AcDetailpanel.Controls.Add(this.panel6);
            this.AcDetailpanel.Controls.Add(this.panel5);
            this.AcDetailpanel.Controls.Add(this.label5);
            this.AcDetailpanel.Controls.Add(this.label2);
            this.AcDetailpanel.Location = new System.Drawing.Point(12, 209);
            this.AcDetailpanel.Name = "AcDetailpanel";
            this.AcDetailpanel.Size = new System.Drawing.Size(1687, 86);
            this.AcDetailpanel.TabIndex = 12;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Teal;
            this.panel6.Controls.Add(this.Lastname);
            this.panel6.Controls.Add(this.AcHoldername);
            this.panel6.Location = new System.Drawing.Point(353, 14);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(318, 56);
            this.panel6.TabIndex = 25;
            // 
            // Lastname
            // 
            this.Lastname.AutoSize = true;
            this.Lastname.BackColor = System.Drawing.Color.Teal;
            this.Lastname.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lastname.ForeColor = System.Drawing.Color.Transparent;
            this.Lastname.Location = new System.Drawing.Point(120, 14);
            this.Lastname.Name = "Lastname";
            this.Lastname.Size = new System.Drawing.Size(25, 33);
            this.Lastname.TabIndex = 25;
            this.Lastname.Text = "-";
            // 
            // AcHoldername
            // 
            this.AcHoldername.AutoSize = true;
            this.AcHoldername.BackColor = System.Drawing.Color.Teal;
            this.AcHoldername.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AcHoldername.ForeColor = System.Drawing.Color.Transparent;
            this.AcHoldername.Location = new System.Drawing.Point(17, 14);
            this.AcHoldername.Name = "AcHoldername";
            this.AcHoldername.Size = new System.Drawing.Size(25, 33);
            this.AcHoldername.TabIndex = 22;
            this.AcHoldername.Text = "-";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Teal;
            this.panel5.Controls.Add(this.AccountBal);
            this.panel5.Location = new System.Drawing.Point(1312, 14);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(207, 56);
            this.panel5.TabIndex = 13;
            // 
            // AccountBal
            // 
            this.AccountBal.AutoSize = true;
            this.AccountBal.BackColor = System.Drawing.Color.Teal;
            this.AccountBal.Font = new System.Drawing.Font("Calisto MT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AccountBal.ForeColor = System.Drawing.Color.Transparent;
            this.AccountBal.Location = new System.Drawing.Point(13, 9);
            this.AccountBal.Name = "AccountBal";
            this.AccountBal.Size = new System.Drawing.Size(26, 37);
            this.AccountBal.TabIndex = 24;
            this.AccountBal.Text = "-";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.DarkCyan;
            this.label5.Font = new System.Drawing.Font("Century Schoolbook", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.OldLace;
            this.label5.Location = new System.Drawing.Point(1064, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(242, 30);
            this.label5.TabIndex = 23;
            this.label5.Text = "Account Balance : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.DarkCyan;
            this.label2.Font = new System.Drawing.Font("Century Schoolbook", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.OldLace;
            this.label2.Location = new System.Drawing.Point(40, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(307, 30);
            this.label2.TabIndex = 21;
            this.label2.Text = "Account Holder Name : ";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkCyan;
            this.panel3.Controls.Add(this.CheckAcBalance);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(12, 49);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1687, 120);
            this.panel3.TabIndex = 11;
            // 
            // CheckAcBalance
            // 
            this.CheckAcBalance.BackColor = System.Drawing.Color.CadetBlue;
            this.CheckAcBalance.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CheckAcBalance.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckAcBalance.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.CheckAcBalance.Location = new System.Drawing.Point(816, 44);
            this.CheckAcBalance.MaxLength = 15;
            this.CheckAcBalance.Name = "CheckAcBalance";
            this.CheckAcBalance.Size = new System.Drawing.Size(510, 43);
            this.CheckAcBalance.TabIndex = 20;
            this.CheckAcBalance.TextChanged += new System.EventHandler(this.CheckAcBalance_TextChanged);
            this.CheckAcBalance.KeyDown += new System.Windows.Forms.KeyEventHandler(this.CheckAcBalance_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkCyan;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.OldLace;
            this.label1.Location = new System.Drawing.Point(293, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(497, 43);
            this.label1.TabIndex = 4;
            this.label1.Text = "Enter Account Number : ";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.label44);
            this.panel1.Controls.Add(this.label45);
            this.panel1.Location = new System.Drawing.Point(502, 121);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(948, 61);
            this.panel1.TabIndex = 11;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.Teal;
            this.label44.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.Chartreuse;
            this.label44.Location = new System.Drawing.Point(122, 9);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(270, 43);
            this.label44.TabIndex = 3;
            this.label44.Text = "GIR BANK  - ";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Teal;
            this.label45.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.OldLace;
            this.label45.Location = new System.Drawing.Point(398, 9);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(353, 43);
            this.label45.TabIndex = 2;
            this.label45.Text = "Deposite Amount";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Teal;
            this.panel2.Controls.Add(this.label7);
            this.panel2.Location = new System.Drawing.Point(1503, 121);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(272, 61);
            this.panel2.TabIndex = 51;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(31, 17);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(212, 33);
            this.label7.TabIndex = 22;
            this.label7.Text = "Exit - (Ctrl + X)";
            // 
            // Clear_Panel
            // 
            this.Clear_Panel.BackColor = System.Drawing.Color.DarkCyan;
            this.Clear_Panel.Controls.Add(this.label4);
            this.Clear_Panel.Location = new System.Drawing.Point(715, 640);
            this.Clear_Panel.Name = "Clear_Panel";
            this.Clear_Panel.Size = new System.Drawing.Size(341, 65);
            this.Clear_Panel.TabIndex = 53;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(45, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(249, 33);
            this.label4.TabIndex = 22;
            this.label4.Text = "Logout - (Ctrl+R)";
            // 
            // Deposite_Amount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(1911, 1063);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.Main_Panel);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Deposite_Amount";
            this.Text = "Deposite_Amount";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Deposite_Amount_Load);
            this.Main_Panel.ResumeLayout(false);
            this.Submit_Button.ResumeLayout(false);
            this.Submit_Button.PerformLayout();
            this.Deposite_Panel.ResumeLayout(false);
            this.Deposite_Panel.PerformLayout();
            this.AcDetailpanel.ResumeLayout(false);
            this.AcDetailpanel.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.Clear_Panel.ResumeLayout(false);
            this.Clear_Panel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Main_Panel;
        private System.Windows.Forms.Panel Deposite_Panel;
        private System.Windows.Forms.Panel AcDetailpanel;
        private System.Windows.Forms.Label Lastname;
        private System.Windows.Forms.Label AccountBal;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label AcHoldername;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        public System.Windows.Forms.TextBox CheckAcBalance;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel Submit_Button;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label Captcha;
        public System.Windows.Forms.TextBox text_Captcha;
        public System.Windows.Forms.TextBox DepositeAmount;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel Clear_Panel;
        private System.Windows.Forms.Label label4;
    }
}