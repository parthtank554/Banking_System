﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Bank_Management_System
{
    public partial class Active_Debit_Card : Form
    {
        SqlConnection con;
        SqlDataAdapter oda,oda2;
        SqlCommand cmd,cmd2,cmd3;
        DataTable dt,dt2;
        string blocklist;
        public Active_Debit_Card()
        {
            InitializeComponent();
        }
        public void Block_List()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();

            cmd3 = new SqlCommand("select * from Block_Unblock_Status where Debit_Number='" + CheckAcBalance.Text + "'", con);
            oda2 = new SqlDataAdapter(cmd3);
            dt2 = new DataTable();
            oda2.Fill(dt2);

            foreach (DataRow dr in dt2.Rows)
            {
                blocklist = dr["Debit_Number"].ToString();
            }
        }
        private void CheckAcBalance_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt32(CheckAcBalance.Text.Length) == 16)
            {
                Block_List();
                if (blocklist == CheckAcBalance.Text)
                {
                    MessageBox.Show("Account Is Blocked...", "DeActivated", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    CheckAcBalance.Enabled = true;
                    CheckAcBalance.Clear();
                    CheckAcBalance.Focus();
                }
                else
                {
                    CheckAcBalance.Enabled = false;
                    con = new SqlConnection(Con_Class.cnn);
                    con.Open();

                    cmd = new SqlCommand("select * from Debit_Card_Apply where DebitNumber='" + CheckAcBalance.Text + "'", con);
                    oda = new SqlDataAdapter(cmd);
                    dt = new DataTable();
                    oda.Fill(dt);

                    foreach (DataRow dr in dt.Rows)
                    {
                        Status_Panel.Enabled = true;
                        lbl_Satus.Text = dr["Status"].ToString();
                    }
                    if (lbl_Satus.Text == "-")
                    {
                        MessageBox.Show("Account Not Found....", "Not Founnd", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        lbl_Satus.Text = "-";
                        Status_Panel.Enabled = false;
                        CheckAcBalance.Enabled = true;
                        CheckAcBalance.Clear();
                        CheckAcBalance.Focus();
                    }
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Temper_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                lbl_Satus.Text = "-";
                Status_Panel.Enabled = false;
                CheckAcBalance.Enabled = true;
                CheckAcBalance.Clear();
                CheckAcBalance.Focus();
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                MessageBox.Show("Please Logout First......", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.A)
            {
                if (lbl_Satus.Text == "Active")
                {
                    MessageBox.Show("Card Is Alredy Activated...", "Activeted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    con = new SqlConnection(Con_Class.cnn);
                    con.Open();

                    cmd2 = new SqlCommand("update Debit_Card_Apply set Status='Activate' where DebitNumber='" + CheckAcBalance.Text + "'", con);
                    int res = cmd2.ExecuteNonQuery();
                    if (res > 0)
                    {
                        MessageBox.Show("Card Activated......", "Activate", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        lbl_Satus.Text = "-";
                        Status_Panel.Enabled = false;
                        CheckAcBalance.Enabled = true;
                        CheckAcBalance.Clear();
                        CheckAcBalance.Focus();
                    }
                    else
                    {
                        MessageBox.Show("Error", "404", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.D)
            {
                if (lbl_Satus.Text == "DeActive")
                {
                    MessageBox.Show("Card Is Alredy DeActivated...", "DeActiveted", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    con = new SqlConnection(Con_Class.cnn);
                    con.Open();

                    cmd2 = new SqlCommand("update Debit_Card_Apply set Status='DeActivate' where DebitNumber='" + CheckAcBalance.Text + "'", con);
                    int res = cmd2.ExecuteNonQuery();
                    if (res > 0)
                    {
                        MessageBox.Show("Card DeActivated......", "DeActivate", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        lbl_Satus.Text = "-";
                        Status_Panel.Enabled = false;
                        CheckAcBalance.Enabled = true;
                        CheckAcBalance.Clear();
                        CheckAcBalance.Focus();
                    }
                    else
                    {
                        MessageBox.Show("Error", "404", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        private void Active_Debit_Card_Load(object sender, EventArgs e)
        {
            Status_Panel.Enabled = false;
            CheckAcBalance.Focus();
           
        }

        private void CheckAcBalance_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                this.Close();
                Next_Page_Dashbord obj = new Next_Page_Dashbord();
                obj.Show();
            }
        }

        private void CheckAcBalance_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122)
            {
                e.Handled = true;
            }
        }
    }
}
