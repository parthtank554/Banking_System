﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank_Management_System
{
    public partial class Reset_And_Forggot_Card_Pin : Form
    {
        public Reset_And_Forggot_Card_Pin()
        {
            InitializeComponent();
        }

        private void ComboContry_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (ChkOperations.SelectedItem == "Generate New Pin")
                {
                    this.Hide();
                    Generate_New_Pin obj = new Generate_New_Pin();
                    obj.Show();
                }
                else if (ChkOperations.SelectedItem == "Reset Pin")
                {
                    this.Hide();
                    Reset_Pin obj = new Reset_Pin();
                    obj.Show();
                }
               
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                this.Close();
                Next_Page_Dashbord obj = new Next_Page_Dashbord();
                obj.Show();
            }
        }

        private void Reset_And_Forggot_Card_Pin_Load(object sender, EventArgs e)
        {
            
        }
    }
}
