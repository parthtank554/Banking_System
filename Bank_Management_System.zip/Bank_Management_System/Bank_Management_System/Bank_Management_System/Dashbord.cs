﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Bank_Management_System
{
    public partial class Dashbord : Form
    {
        SqlCommand cmd,cmd2;
        SqlConnection con;
        SqlDataAdapter oda,oda2;
        DataTable dt,dt2;
        string cardnumber = "", cardstatus = "",Pin = "";
        public Dashbord()
        {
            InitializeComponent();
        }

        private void Dashbord_Load(object sender, EventArgs e)
        {
            Card_Number.Focus();
            Card_Pin_Panel.Enabled = false;
        }
        public void getdata()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();

            cmd = new SqlCommand("select * from Debit_Card_Apply where DebitNumber='" + Card_Number.Text + "'", con);
            oda = new SqlDataAdapter(cmd);
            dt = new DataTable();
            oda.Fill(dt);

            foreach (DataRow dr in dt.Rows)
            {
                cardnumber = dr["DebitNumber"].ToString();
                cardstatus = dr["Status"].ToString();
            }
            con.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        public void Pin_getdata()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();

            cmd2 = new SqlCommand("select * from Debit_Card_Apply where DebitNumber='" + Card_Number.Text + "'", con);
            oda2 = new SqlDataAdapter(cmd2);
            dt2 = new DataTable();
            oda.Fill(dt2);

            foreach (DataRow dr in dt.Rows)
            {
                Pin = dr["Pin"].ToString();
            }

        }
        private void Card_Number_TextChanged(object sender, EventArgs e)
        {
             if (Convert.ToInt16(Card_Number.Text.Length) == 16)
             {
                 getdata();
                if (cardnumber == Card_Number.Text)
                {
                    if (cardstatus == "DeActivate")
                    {
                        MessageBox.Show("Card Is DeActivted Please Contact Branch......", "Deactivated", MessageBoxButtons.OK, MessageBoxIcon.Stop); Card_Number.Enabled = true;
                        Card_Number.Clear();
                        Card_Number.Focus();
                        cardstatus = "";
                    }
                    else
                    {
                        Card_Number.Enabled = false;
                        Card_Pin_Panel.Enabled = true;
                        txtxpin.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Card Number...", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Card_Number.Enabled = true;
                    Card_Number.Clear();
                    Card_Number.Focus();
                }
            }
        }

        private void txtxpin_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt16(txtxpin.Text.Length) == 4)
            {
                txtxpin.Enabled = false;
                Pin_getdata();
                if (txtxpin.Text == Pin)
                {
                    this.Hide();
                    Trasaction_Dashbord obj = new Trasaction_Dashbord();
                    obj.Acnumber.Text = Card_Number.Text;
                    obj.Show();
                }
                else
                {
                    MessageBox.Show("Invalid Pin...", "Incorrect", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtxpin.Enabled = true;
                    txtxpin.Clear();
                    Card_Pin_Panel.Enabled = false;
                    Card_Number.Enabled = true;
                    Card_Number.Clear();
                    Card_Number.Focus();
                }
            }
        }

        private void Reset_Password_Link_Click(object sender, EventArgs e)
        {
            this.Hide();
            Generate_New_Atm_Pin obj = new Generate_New_Atm_Pin();
            obj.Show();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 obj = new Form1();
            obj.Show();
        }
    }
}
