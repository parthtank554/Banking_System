﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Bank_Management_System
{
    public partial class Block_Unblock_Debit_Card : Form
    {
        string qry, BlockList, Status;
        SqlConnection con;
        DataTable dt;
        SqlCommand cmd, cmd2, cmd3,cmd4,cmd5;
        SqlDataAdapter oda;

        public Block_Unblock_Debit_Card()
        {
            InitializeComponent();
        }
        public void Block_List()
        {

            string qry = "select * from Blocke_Ac where BalockAcNumber='" + CheckAcBalance.Text + "'";
            cmd = new SqlCommand(qry, con);
            DataTable dt = new DataTable();
            SqlDataAdapter oda = new SqlDataAdapter(cmd);
            oda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                BlockList = dr["BalockAcNumber"].ToString();
            }
        }
        public void StstusData()
        {
            string qry = "select * from Blocke_Ac where BalockAcNumber='" + CheckAcBalance.Text + "'";
            cmd = new SqlCommand(qry, con);
            DataTable dt = new DataTable();
            SqlDataAdapter oda = new SqlDataAdapter(cmd);
            oda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                BlockList = dr["BalockAcNumber"].ToString();
            }
        }
        public void ResetData()
        {
            text_Captcha.Clear();
            Block_Panel.Enabled = false;
            Unblock_Panel.Enabled = false;
            Block_Unblock_Panel.Enabled = false;
            AcHoldername.Text = "-";
            Lastname.Text = "-";
            DebitNumber.Text = "-";
            Name_Detail_Panel.Enabled = false;
            CheckAcBalance.Enabled = true;
            CheckAcBalance.Clear();
            CheckAcBalance.Focus();
        }
        private void Block_Unblock_Debit_Card_Load(object sender, EventArgs e)
        {

            Random rand = new Random();
            int num = rand.Next(6, 7);
            int total = 0;
            string captcha = "";

            do
            {
                int chr = rand.Next(100, 123);
                if ((chr >= 48 && chr <= 57) || (chr >= 65 && chr <= 90) || (chr >= 97 && chr <= 122))
                {
                    captcha = captcha + (char)chr;
                    total++;
                    if (total == num)
                        break;
                    {

                    }
                }
            } while (true);
            Captcha.Text = captcha;

            Name_Detail_Panel.Enabled = false;
            Block_Unblock_Panel.Enabled = false;
            Block_Panel.Enabled = false;
            Unblock_Panel.Enabled = false;
        }

        private void CheckAcBalance_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                this.Close();
                Next_Page_Dashbord obj = new Next_Page_Dashbord();
                obj.Show();
            }

        }
        private void CheckAcBalance_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt32(CheckAcBalance.Text.Length) == 15)
            {
                CheckAcBalance.Enabled = false;
                con = new SqlConnection(Con_Class.cnn);
                con.Open();

                Block_List();
                if (CheckAcBalance.Text == BlockList) { MessageBox.Show("Account Is Blocked...", "DaActivted", MessageBoxButtons.OK, MessageBoxIcon.Error); CheckAcBalance.Enabled = true; CheckAcBalance.Clear(); CheckAcBalance.Focus(); }
                else
                {
                    CheckAcBalance.Enabled = false;
                    qry = "select * from Debit_Card_Apply where AcNumber='" + CheckAcBalance.Text + "'";
                    cmd = new SqlCommand(qry, con);
                    dt = new DataTable();
                    oda = new SqlDataAdapter(cmd);
                    oda.Fill(dt);
                    foreach (DataRow dr in dt.Rows)
                    {
                        Name_Detail_Panel.Enabled = true;
                        Block_Unblock_Panel.Enabled = true;
                        text_Captcha.Focus();
                        AcHoldername.Text = dr["Firstname"].ToString();
                        Lastname.Text = dr["Lastname"].ToString();
                        DebitNumber.Text = dr["DebitNumber"].ToString();
                        Status = dr["Status"].ToString();
                    }
                    if (Status == "DeActivate") { Unblock_Panel.Enabled = true; }
                    else { if (Status == "Activate") { Block_Panel.Enabled = true; } }
                    if (AcHoldername.Text == "-") { MessageBox.Show("Account Not Found Enter Valid Account Number....", "Invalid User", MessageBoxButtons.OK, MessageBoxIcon.Error); CheckAcBalance.Enabled = true; CheckAcBalance.Clear(); CheckAcBalance.Focus(); }
                }
            }

        }

        private void text_Captcha_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                ResetData();
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X) { MessageBox.Show("Please Logout First (Ctrl + R)........", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); }

            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.B)
            {

                if (text_Captcha.Text == "")
                { MessageBox.Show("Enter Captcha..", "Blank Record", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); text_Captcha.Focus(); }
                else
                {
                    if (text_Captcha.Text != Captcha.Text) { MessageBox.Show("Invalid Captcha Try Again...", "Invalid Captcha..", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); text_Captcha.Clear(); text_Captcha.Focus(); }
                    else
                    {
                        if (Block_Panel.Enabled == false) { MessageBox.Show("Account Is Alredy Blocked....", "DeActivated", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); }
                        else
                        {
                            con = new SqlConnection(Con_Class.cnn);
                            con.Open();
                            cmd2 = new SqlCommand("insert into Block_Unblock_Status values('" + DebitNumber.Text + "')", con);
                            cmd3 = new SqlCommand("update Debit_Card_Apply set Status='DeActivate' where AcNumber='" + CheckAcBalance.Text + "'", con);
                            cmd3.ExecuteNonQuery();
                            int res = cmd2.ExecuteNonQuery();
                            if (res > 0)
                            {
                                MessageBox.Show("Account Blocked Successfully......", "DeActivated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                ResetData();
                            }
                        }
                    }
                }
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.U)
            {

                if (text_Captcha.Text == "")
                { MessageBox.Show("Enter Captcha..", "Blank Record", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); text_Captcha.Focus(); }
                else
                {
                    if (text_Captcha.Text != Captcha.Text) { MessageBox.Show("Invalid Captcha Try Again...", "Invalid Captcha..", MessageBoxButtons.OK, MessageBoxIcon.Exclamation); text_Captcha.Clear(); text_Captcha.Focus(); }
                    else
                    {
                        if (Unblock_Panel.Enabled == false) { MessageBox.Show("Account Is Alredy Unlocked....", "Activated", MessageBoxButtons.OK, MessageBoxIcon.Asterisk); }
                        else
                        {
                            con = new SqlConnection(Con_Class.cnn);
                            con.Open();

                            cmd4 = new SqlCommand("delete from Block_Unblock_Status where Debit_Number='" + DebitNumber.Text + "'", con);
                            cmd5 = new SqlCommand("update Debit_Card_Apply set Status='Activate' where AcNumber='" + CheckAcBalance.Text + "'", con);
                            cmd4.ExecuteNonQuery();
                            int res = cmd5.ExecuteNonQuery();
                            if (res > 0)
                            {
                                MessageBox.Show("Account Unlocked Successfully......", "Activated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                ResetData();
                            }
                        }
                    }
                }
            }
        }
    }
}
