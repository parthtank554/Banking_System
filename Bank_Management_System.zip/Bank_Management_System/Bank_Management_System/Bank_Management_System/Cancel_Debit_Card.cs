﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Bank_Management_System
{
    public partial class Cancel_Debit_Card : Form
    {
        SqlCommand cmd,cmdd2,cmd2;
        SqlConnection con;
        SqlDataAdapter oda,oda2;
        DataTable dt,dt2;
        string blocklist;
        public Cancel_Debit_Card()
        {
            InitializeComponent();
        }

        private void Cancel_Debit_Card_Load(object sender, EventArgs e)
        {
            Detail_Panel.Enabled = false;
            CheckAcBalance.Focus();
        }
        public void Block_List()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();

            cmd2 = new SqlCommand("select * from Block_Unblock_Status where Debit_Number='" + CheckAcBalance.Text + "'", con);
            oda2 = new SqlDataAdapter(cmd2);
            dt2 = new DataTable();
            oda2.Fill(dt2);

            foreach (DataRow dr in dt2.Rows)
            {
                blocklist = dr["Debit_Number"].ToString();
            }
        }
        private void CheckAcBalance_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt32(CheckAcBalance.Text.Length) == 15)
            {
                Block_List();
                if (blocklist == CheckAcBalance.Text)
                {
                    MessageBox.Show("Account Is Blocked...", "DeActivated", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    CheckAcBalance.Enabled = true;
                    CheckAcBalance.Clear();
                    CheckAcBalance.Focus();
                }
                else
                {
                    CheckAcBalance.Enabled = false;
                    con = new SqlConnection(Con_Class.cnn);
                    con.Open();

                    cmd = new SqlCommand("Select * from Debit_Card_Apply where AcNumber='" + CheckAcBalance.Text + "'", con);
                    oda = new SqlDataAdapter(cmd);
                    dt = new DataTable();
                    oda.Fill(dt);

                    foreach (DataRow dr in dt.Rows)
                    {
                        Detail_Panel.Enabled = true;
                        lblfirstname.Text = dr["Firstname"].ToString();
                        Lastname.Text = dr["Lastname"].ToString();
                        Card_Number.Text = dr["DebitNumber"].ToString();
                    }
                    if (lblfirstname.Text == "-")
                    {
                        MessageBox.Show("Account Not Found....", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Detail_Panel.Enabled = false;
                        CheckAcBalance.Enabled = true;
                        CheckAcBalance.Clear();
                        CheckAcBalance.Focus();
                    }

                }
            }
        }
        private void Temper_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.C)
            {
                DialogResult di = MessageBox.Show("Confirm Cancel Permenat Debit Card....", "Cancel", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (di == DialogResult.Yes)
                {
                    con = new SqlConnection(Con_Class.cnn);
                    con.Open();

                    cmdd2 = new SqlCommand("delete from Debit_Card_Apply where AcNumber='" + CheckAcBalance.Text + "'", con);
                    int res = cmdd2.ExecuteNonQuery();

                    if (res > 0)
                    {
                        MessageBox.Show("Canceled....", "Success !", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        lblfirstname.Text = "-";
                        Lastname.Text = "-";
                        Card_Number.Text = "-";
                        Detail_Panel.Enabled = false;
                        CheckAcBalance.Enabled = true;
                        CheckAcBalance.Clear();
                        CheckAcBalance.Focus();
                    }
                    else
                    {
                        MessageBox.Show("Error");
                    }
                }
               
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                lblfirstname.Text = "-";
                Lastname.Text = "-";
                Card_Number.Text = "-";
                Detail_Panel.Enabled = false;
                CheckAcBalance.Enabled = true;
                CheckAcBalance.Clear();
                CheckAcBalance.Focus();
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                MessageBox.Show("Please Logout First......", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void CheckAcBalance_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122)
            {
                e.Handled = true;
            }
        }

        private void CheckAcBalance_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                this.Close();
                Next_Page_Dashbord obj = new Next_Page_Dashbord();
                obj.Show();
            }
        }
    }
}
