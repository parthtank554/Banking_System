﻿namespace Bank_Management_System
{
    partial class Edit_Customer_Data
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel3 = new System.Windows.Forms.Panel();
            this.CheckAcBalance = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.categorypael = new System.Windows.Forms.Panel();
            this.oddvaluepanel = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.dcddcdscsdcscdsd = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.panel33 = new System.Windows.Forms.Panel();
            this.panel34 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.newvaluepanel = new System.Windows.Forms.Panel();
            this.panel36 = new System.Windows.Forms.Panel();
            this.panel37 = new System.Windows.Forms.Panel();
            this.panel38 = new System.Windows.Forms.Panel();
            this.panel39 = new System.Windows.Forms.Panel();
            this.panel40 = new System.Windows.Forms.Panel();
            this.panel41 = new System.Windows.Forms.Panel();
            this.panel42 = new System.Windows.Forms.Panel();
            this.panel43 = new System.Windows.Forms.Panel();
            this.panel44 = new System.Windows.Forms.Panel();
            this.panel45 = new System.Windows.Forms.Panel();
            this.panel46 = new System.Windows.Forms.Panel();
            this.panel47 = new System.Windows.Forms.Panel();
            this.panel48 = new System.Windows.Forms.Panel();
            this.lblfirstname = new System.Windows.Forms.Label();
            this.lblmiddlename = new System.Windows.Forms.Label();
            this.lblMobilenumber = new System.Windows.Forms.Label();
            this.lblDatOfBirth = new System.Windows.Forms.Label();
            this.lbllastname = new System.Windows.Forms.Label();
            this.lblgender = new System.Windows.Forms.Label();
            this.lblcontry = new System.Windows.Forms.Label();
            this.lbldistric = new System.Windows.Forms.Label();
            this.lblemailid = new System.Windows.Forms.Label();
            this.lblstate = new System.Windows.Forms.Label();
            this.lbltaluka = new System.Windows.Forms.Label();
            this.lblaccounttype = new System.Windows.Forms.Label();
            this.lblcityvillage = new System.Windows.Forms.Label();
            this.txtfirstname = new System.Windows.Forms.TextBox();
            this.txtmiddlename = new System.Windows.Forms.TextBox();
            this.txtlastname = new System.Windows.Forms.TextBox();
            this.txtmobile = new System.Windows.Forms.TextBox();
            this.txtdob = new System.Windows.Forms.TextBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txtstate = new System.Windows.Forms.TextBox();
            this.txtdistric = new System.Windows.Forms.TextBox();
            this.txttaluka = new System.Windows.Forms.TextBox();
            this.cityvillage = new System.Windows.Forms.TextBox();
            this.selectcontry = new System.Windows.Forms.ComboBox();
            this.selectactype = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.selectgender = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.categorypael.SuspendLayout();
            this.oddvaluepanel.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel34.SuspendLayout();
            this.panel35.SuspendLayout();
            this.newvaluepanel.SuspendLayout();
            this.panel36.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel38.SuspendLayout();
            this.panel39.SuspendLayout();
            this.panel40.SuspendLayout();
            this.panel41.SuspendLayout();
            this.panel42.SuspendLayout();
            this.panel43.SuspendLayout();
            this.panel44.SuspendLayout();
            this.panel45.SuspendLayout();
            this.panel46.SuspendLayout();
            this.panel47.SuspendLayout();
            this.panel48.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkCyan;
            this.panel3.Controls.Add(this.CheckAcBalance);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(29, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1192, 86);
            this.panel3.TabIndex = 14;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // CheckAcBalance
            // 
            this.CheckAcBalance.BackColor = System.Drawing.Color.CadetBlue;
            this.CheckAcBalance.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CheckAcBalance.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckAcBalance.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.CheckAcBalance.Location = new System.Drawing.Point(539, 20);
            this.CheckAcBalance.MaxLength = 15;
            this.CheckAcBalance.Name = "CheckAcBalance";
            this.CheckAcBalance.Size = new System.Drawing.Size(510, 43);
            this.CheckAcBalance.TabIndex = 20;
            this.CheckAcBalance.TextChanged += new System.EventHandler(this.CheckAcBalance_TextChanged);
            this.CheckAcBalance.KeyDown += new System.Windows.Forms.KeyEventHandler(this.CheckAcBalance_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkCyan;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.OldLace;
            this.label1.Location = new System.Drawing.Point(36, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(497, 43);
            this.label1.TabIndex = 4;
            this.label1.Text = "Enter Account Number : ";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkCyan;
            this.panel4.Controls.Add(this.label20);
            this.panel4.Controls.Add(this.label19);
            this.panel4.Location = new System.Drawing.Point(1596, 12);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(257, 86);
            this.panel4.TabIndex = 58;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(39, 49);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(176, 28);
            this.label7.TabIndex = 22;
            this.label7.Text = "Exit - (Ctrl + X)";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkCyan;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(1312, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(268, 86);
            this.panel1.TabIndex = 59;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(26, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(201, 28);
            this.label2.TabIndex = 22;
            this.label2.Text = "Reset - (Ctrl + R)";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkCyan;
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(29, 114);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(541, 61);
            this.panel2.TabIndex = 59;
            // 
            // categorypael
            // 
            this.categorypael.BackColor = System.Drawing.Color.DarkCyan;
            this.categorypael.Controls.Add(this.panel20);
            this.categorypael.Controls.Add(this.panel15);
            this.categorypael.Controls.Add(this.panel21);
            this.categorypael.Controls.Add(this.panel12);
            this.categorypael.Controls.Add(this.panel16);
            this.categorypael.Controls.Add(this.panel22);
            this.categorypael.Controls.Add(this.panel13);
            this.categorypael.Controls.Add(this.panel17);
            this.categorypael.Controls.Add(this.panel14);
            this.categorypael.Controls.Add(this.panel19);
            this.categorypael.Controls.Add(this.panel11);
            this.categorypael.Controls.Add(this.panel18);
            this.categorypael.Controls.Add(this.panel10);
            this.categorypael.Location = new System.Drawing.Point(29, 181);
            this.categorypael.Name = "categorypael";
            this.categorypael.Size = new System.Drawing.Size(541, 891);
            this.categorypael.TabIndex = 60;
            // 
            // oddvaluepanel
            // 
            this.oddvaluepanel.BackColor = System.Drawing.Color.DarkCyan;
            this.oddvaluepanel.Controls.Add(this.panel35);
            this.oddvaluepanel.Controls.Add(this.panel29);
            this.oddvaluepanel.Controls.Add(this.panel26);
            this.oddvaluepanel.Controls.Add(this.panel30);
            this.oddvaluepanel.Controls.Add(this.panel25);
            this.oddvaluepanel.Controls.Add(this.panel31);
            this.oddvaluepanel.Controls.Add(this.panel27);
            this.oddvaluepanel.Controls.Add(this.panel32);
            this.oddvaluepanel.Controls.Add(this.panel33);
            this.oddvaluepanel.Controls.Add(this.panel23);
            this.oddvaluepanel.Controls.Add(this.panel34);
            this.oddvaluepanel.Controls.Add(this.panel28);
            this.oddvaluepanel.Controls.Add(this.panel24);
            this.oddvaluepanel.Location = new System.Drawing.Point(680, 181);
            this.oddvaluepanel.Name = "oddvaluepanel";
            this.oddvaluepanel.Size = new System.Drawing.Size(541, 891);
            this.oddvaluepanel.TabIndex = 62;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DarkCyan;
            this.panel6.Controls.Add(this.label4);
            this.panel6.Location = new System.Drawing.Point(680, 114);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(541, 61);
            this.panel6.TabIndex = 61;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.DarkCyan;
            this.panel9.Controls.Add(this.label5);
            this.panel9.Location = new System.Drawing.Point(1312, 114);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(541, 61);
            this.panel9.TabIndex = 61;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.DarkCyan;
            this.label3.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.OldLace;
            this.label3.Location = new System.Drawing.Point(57, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(377, 43);
            this.label3.TabIndex = 21;
            this.label3.Text = "Fields - Cetagory\'s";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.DarkCyan;
            this.label4.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.OldLace;
            this.label4.Location = new System.Drawing.Point(72, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(395, 43);
            this.label4.TabIndex = 22;
            this.label4.Text = "Old Ragitered Data";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.DarkCyan;
            this.label5.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.OldLace;
            this.label5.Location = new System.Drawing.Point(93, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(328, 43);
            this.label5.TabIndex = 23;
            this.label5.Text = "Enter New Data";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Teal;
            this.label6.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.OldLace;
            this.label6.Location = new System.Drawing.Point(91, 16);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(200, 32);
            this.label6.TabIndex = 22;
            this.label6.Text = "1.  Firstname :";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Teal;
            this.panel10.Controls.Add(this.label6);
            this.panel10.Location = new System.Drawing.Point(13, 12);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(503, 61);
            this.panel10.TabIndex = 62;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Teal;
            this.panel11.Controls.Add(this.label8);
            this.panel11.Location = new System.Drawing.Point(13, 79);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(503, 61);
            this.panel11.TabIndex = 63;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.Teal;
            this.panel12.Controls.Add(this.label11);
            this.panel12.Location = new System.Drawing.Point(13, 280);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(503, 61);
            this.panel12.TabIndex = 64;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.Teal;
            this.panel13.Controls.Add(this.label10);
            this.panel13.Location = new System.Drawing.Point(13, 213);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(503, 61);
            this.panel13.TabIndex = 64;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.Teal;
            this.panel14.Controls.Add(this.label9);
            this.panel14.Location = new System.Drawing.Point(13, 146);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(503, 61);
            this.panel14.TabIndex = 64;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.Teal;
            this.panel15.Controls.Add(this.label12);
            this.panel15.Location = new System.Drawing.Point(13, 614);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(503, 61);
            this.panel15.TabIndex = 67;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.Teal;
            this.panel16.Controls.Add(this.label14);
            this.panel16.Location = new System.Drawing.Point(13, 547);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(503, 61);
            this.panel16.TabIndex = 68;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.Teal;
            this.panel17.Controls.Add(this.label13);
            this.panel17.Location = new System.Drawing.Point(13, 480);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(503, 61);
            this.panel17.TabIndex = 69;
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.Teal;
            this.panel18.Controls.Add(this.label18);
            this.panel18.Location = new System.Drawing.Point(13, 414);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(503, 60);
            this.panel18.TabIndex = 66;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.Teal;
            this.panel19.Controls.Add(this.dcddcdscsdcscdsd);
            this.panel19.Location = new System.Drawing.Point(13, 347);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(503, 61);
            this.panel19.TabIndex = 65;
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.Teal;
            this.panel20.Controls.Add(this.label17);
            this.panel20.Location = new System.Drawing.Point(13, 812);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(503, 61);
            this.panel20.TabIndex = 72;
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.Teal;
            this.panel21.Controls.Add(this.label16);
            this.panel21.Location = new System.Drawing.Point(13, 745);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(503, 61);
            this.panel21.TabIndex = 73;
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.Teal;
            this.panel22.Controls.Add(this.label15);
            this.panel22.Location = new System.Drawing.Point(13, 678);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(503, 61);
            this.panel22.TabIndex = 74;
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.Teal;
            this.panel23.Controls.Add(this.lblfirstname);
            this.panel23.Location = new System.Drawing.Point(20, 12);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(503, 61);
            this.panel23.TabIndex = 70;
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.Teal;
            this.panel24.Controls.Add(this.lblmiddlename);
            this.panel24.Location = new System.Drawing.Point(20, 80);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(503, 60);
            this.panel24.TabIndex = 71;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Teal;
            this.label8.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.OldLace;
            this.label8.Location = new System.Drawing.Point(91, 19);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(222, 32);
            this.label8.TabIndex = 23;
            this.label8.Text = "2. Middlename :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Teal;
            this.label9.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.OldLace;
            this.label9.Location = new System.Drawing.Point(91, 17);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(196, 32);
            this.label9.TabIndex = 24;
            this.label9.Text = "3.  Lastname :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Teal;
            this.label10.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.OldLace;
            this.label10.Location = new System.Drawing.Point(91, 17);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(246, 32);
            this.label10.TabIndex = 25;
            this.label10.Text = "4 . Date Of Birth :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Teal;
            this.label11.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.OldLace;
            this.label11.Location = new System.Drawing.Point(91, 16);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(264, 32);
            this.label11.TabIndex = 26;
            this.label11.Text = "5. Mobile Number :";
            // 
            // dcddcdscsdcscdsd
            // 
            this.dcddcdscsdcscdsd.AutoSize = true;
            this.dcddcdscsdcscdsd.BackColor = System.Drawing.Color.Teal;
            this.dcddcdscsdcscdsd.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dcddcdscsdcscdsd.ForeColor = System.Drawing.Color.OldLace;
            this.dcddcdscsdcscdsd.Location = new System.Drawing.Point(91, 14);
            this.dcddcdscsdcscdsd.Name = "dcddcdscsdcscdsd";
            this.dcddcdscsdcscdsd.Size = new System.Drawing.Size(199, 32);
            this.dcddcdscsdcscdsd.TabIndex = 27;
            this.dcddcdscsdcscdsd.Text = "6. Email - ID :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Teal;
            this.label13.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.OldLace;
            this.label13.Location = new System.Drawing.Point(91, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(160, 32);
            this.label13.TabIndex = 28;
            this.label13.Text = "8.  Contry :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Teal;
            this.label14.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.OldLace;
            this.label14.Location = new System.Drawing.Point(91, 15);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(134, 32);
            this.label14.TabIndex = 29;
            this.label14.Text = "9.  State :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Teal;
            this.label15.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.OldLace;
            this.label15.Location = new System.Drawing.Point(91, 20);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(173, 32);
            this.label15.TabIndex = 30;
            this.label15.Text = "11.  Taluka :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Teal;
            this.label16.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.OldLace;
            this.label16.Location = new System.Drawing.Point(91, 17);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(254, 32);
            this.label16.TabIndex = 31;
            this.label16.Text = "12. City / Village :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Teal;
            this.label17.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.OldLace;
            this.label17.Location = new System.Drawing.Point(91, 14);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(260, 32);
            this.label17.TabIndex = 32;
            this.label17.Text = "13.  Account Type :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Teal;
            this.label18.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.OldLace;
            this.label18.Location = new System.Drawing.Point(91, 14);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(160, 32);
            this.label18.TabIndex = 33;
            this.label18.Text = "7. Gender :";
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.Teal;
            this.panel25.Controls.Add(this.lbllastname);
            this.panel25.Location = new System.Drawing.Point(20, 146);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(503, 60);
            this.panel25.TabIndex = 72;
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.Color.Teal;
            this.panel26.Controls.Add(this.lblemailid);
            this.panel26.Location = new System.Drawing.Point(20, 347);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(503, 60);
            this.panel26.TabIndex = 75;
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.Color.Teal;
            this.panel27.Controls.Add(this.lblDatOfBirth);
            this.panel27.Location = new System.Drawing.Point(20, 213);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(503, 61);
            this.panel27.TabIndex = 73;
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.Color.Teal;
            this.panel28.Controls.Add(this.lblMobilenumber);
            this.panel28.Location = new System.Drawing.Point(20, 281);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(503, 60);
            this.panel28.TabIndex = 74;
            // 
            // panel29
            // 
            this.panel29.BackColor = System.Drawing.Color.Teal;
            this.panel29.Controls.Add(this.lblcityvillage);
            this.panel29.Location = new System.Drawing.Point(20, 749);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(503, 60);
            this.panel29.TabIndex = 81;
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.Color.Teal;
            this.panel30.Controls.Add(this.lblstate);
            this.panel30.Location = new System.Drawing.Point(20, 548);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(503, 60);
            this.panel30.TabIndex = 78;
            // 
            // panel31
            // 
            this.panel31.BackColor = System.Drawing.Color.Teal;
            this.panel31.Controls.Add(this.lbldistric);
            this.panel31.Location = new System.Drawing.Point(20, 615);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(503, 61);
            this.panel31.TabIndex = 79;
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.Color.Teal;
            this.panel32.Controls.Add(this.lblgender);
            this.panel32.Location = new System.Drawing.Point(20, 414);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(503, 61);
            this.panel32.TabIndex = 76;
            // 
            // panel33
            // 
            this.panel33.BackColor = System.Drawing.Color.Teal;
            this.panel33.Controls.Add(this.lbltaluka);
            this.panel33.Location = new System.Drawing.Point(20, 683);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(503, 60);
            this.panel33.TabIndex = 80;
            // 
            // panel34
            // 
            this.panel34.BackColor = System.Drawing.Color.Teal;
            this.panel34.Controls.Add(this.lblcontry);
            this.panel34.Location = new System.Drawing.Point(20, 482);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(503, 60);
            this.panel34.TabIndex = 77;
            // 
            // panel35
            // 
            this.panel35.BackColor = System.Drawing.Color.Teal;
            this.panel35.Controls.Add(this.lblaccounttype);
            this.panel35.Location = new System.Drawing.Point(20, 815);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(503, 60);
            this.panel35.TabIndex = 82;
            // 
            // newvaluepanel
            // 
            this.newvaluepanel.BackColor = System.Drawing.Color.DarkCyan;
            this.newvaluepanel.Controls.Add(this.panel36);
            this.newvaluepanel.Controls.Add(this.panel37);
            this.newvaluepanel.Controls.Add(this.panel38);
            this.newvaluepanel.Controls.Add(this.panel39);
            this.newvaluepanel.Controls.Add(this.panel40);
            this.newvaluepanel.Controls.Add(this.panel41);
            this.newvaluepanel.Controls.Add(this.panel42);
            this.newvaluepanel.Controls.Add(this.panel43);
            this.newvaluepanel.Controls.Add(this.panel44);
            this.newvaluepanel.Controls.Add(this.panel45);
            this.newvaluepanel.Controls.Add(this.panel46);
            this.newvaluepanel.Controls.Add(this.panel47);
            this.newvaluepanel.Controls.Add(this.panel48);
            this.newvaluepanel.Location = new System.Drawing.Point(1312, 181);
            this.newvaluepanel.Name = "newvaluepanel";
            this.newvaluepanel.Size = new System.Drawing.Size(541, 891);
            this.newvaluepanel.TabIndex = 83;
            // 
            // panel36
            // 
            this.panel36.BackColor = System.Drawing.Color.Teal;
            this.panel36.Controls.Add(this.selectactype);
            this.panel36.Location = new System.Drawing.Point(20, 815);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(503, 60);
            this.panel36.TabIndex = 82;
            // 
            // panel37
            // 
            this.panel37.BackColor = System.Drawing.Color.Teal;
            this.panel37.Controls.Add(this.cityvillage);
            this.panel37.Location = new System.Drawing.Point(20, 749);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(503, 60);
            this.panel37.TabIndex = 81;
            // 
            // panel38
            // 
            this.panel38.BackColor = System.Drawing.Color.Teal;
            this.panel38.Controls.Add(this.txtemail);
            this.panel38.Location = new System.Drawing.Point(20, 347);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(503, 60);
            this.panel38.TabIndex = 75;
            // 
            // panel39
            // 
            this.panel39.BackColor = System.Drawing.Color.Teal;
            this.panel39.Controls.Add(this.txtstate);
            this.panel39.Location = new System.Drawing.Point(20, 548);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(503, 60);
            this.panel39.TabIndex = 78;
            // 
            // panel40
            // 
            this.panel40.BackColor = System.Drawing.Color.Teal;
            this.panel40.Controls.Add(this.txtlastname);
            this.panel40.Location = new System.Drawing.Point(20, 146);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(503, 60);
            this.panel40.TabIndex = 72;
            // 
            // panel41
            // 
            this.panel41.BackColor = System.Drawing.Color.Teal;
            this.panel41.Controls.Add(this.txtdistric);
            this.panel41.Location = new System.Drawing.Point(20, 615);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(503, 61);
            this.panel41.TabIndex = 79;
            // 
            // panel42
            // 
            this.panel42.BackColor = System.Drawing.Color.Teal;
            this.panel42.Controls.Add(this.txtdob);
            this.panel42.Location = new System.Drawing.Point(20, 213);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(503, 61);
            this.panel42.TabIndex = 73;
            // 
            // panel43
            // 
            this.panel43.BackColor = System.Drawing.Color.Teal;
            this.panel43.Controls.Add(this.selectgender);
            this.panel43.Location = new System.Drawing.Point(20, 414);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(503, 61);
            this.panel43.TabIndex = 76;
            // 
            // panel44
            // 
            this.panel44.BackColor = System.Drawing.Color.Teal;
            this.panel44.Controls.Add(this.txttaluka);
            this.panel44.Location = new System.Drawing.Point(20, 683);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(503, 60);
            this.panel44.TabIndex = 80;
            // 
            // panel45
            // 
            this.panel45.BackColor = System.Drawing.Color.Teal;
            this.panel45.Controls.Add(this.txtfirstname);
            this.panel45.Location = new System.Drawing.Point(20, 12);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(503, 61);
            this.panel45.TabIndex = 70;
            // 
            // panel46
            // 
            this.panel46.BackColor = System.Drawing.Color.Teal;
            this.panel46.Controls.Add(this.selectcontry);
            this.panel46.Location = new System.Drawing.Point(20, 482);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(503, 60);
            this.panel46.TabIndex = 77;
            // 
            // panel47
            // 
            this.panel47.BackColor = System.Drawing.Color.Teal;
            this.panel47.Controls.Add(this.txtmobile);
            this.panel47.Location = new System.Drawing.Point(20, 281);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(503, 60);
            this.panel47.TabIndex = 74;
            // 
            // panel48
            // 
            this.panel48.BackColor = System.Drawing.Color.Teal;
            this.panel48.Controls.Add(this.txtmiddlename);
            this.panel48.Location = new System.Drawing.Point(20, 80);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(503, 60);
            this.panel48.TabIndex = 71;
            // 
            // lblfirstname
            // 
            this.lblfirstname.AutoSize = true;
            this.lblfirstname.BackColor = System.Drawing.Color.Teal;
            this.lblfirstname.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfirstname.ForeColor = System.Drawing.Color.OldLace;
            this.lblfirstname.Location = new System.Drawing.Point(54, 16);
            this.lblfirstname.Name = "lblfirstname";
            this.lblfirstname.Size = new System.Drawing.Size(37, 32);
            this.lblfirstname.TabIndex = 23;
            this.lblfirstname.Text = "--";
            // 
            // lblmiddlename
            // 
            this.lblmiddlename.AutoSize = true;
            this.lblmiddlename.BackColor = System.Drawing.Color.Teal;
            this.lblmiddlename.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmiddlename.ForeColor = System.Drawing.Color.OldLace;
            this.lblmiddlename.Location = new System.Drawing.Point(54, 14);
            this.lblmiddlename.Name = "lblmiddlename";
            this.lblmiddlename.Size = new System.Drawing.Size(37, 32);
            this.lblmiddlename.TabIndex = 25;
            this.lblmiddlename.Text = "--";
            // 
            // lblMobilenumber
            // 
            this.lblMobilenumber.AutoSize = true;
            this.lblMobilenumber.BackColor = System.Drawing.Color.Teal;
            this.lblMobilenumber.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMobilenumber.ForeColor = System.Drawing.Color.OldLace;
            this.lblMobilenumber.Location = new System.Drawing.Point(54, 15);
            this.lblMobilenumber.Name = "lblMobilenumber";
            this.lblMobilenumber.Size = new System.Drawing.Size(37, 32);
            this.lblMobilenumber.TabIndex = 26;
            this.lblMobilenumber.Text = "--";
            // 
            // lblDatOfBirth
            // 
            this.lblDatOfBirth.AutoSize = true;
            this.lblDatOfBirth.BackColor = System.Drawing.Color.Teal;
            this.lblDatOfBirth.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDatOfBirth.ForeColor = System.Drawing.Color.OldLace;
            this.lblDatOfBirth.Location = new System.Drawing.Point(54, 17);
            this.lblDatOfBirth.Name = "lblDatOfBirth";
            this.lblDatOfBirth.Size = new System.Drawing.Size(37, 32);
            this.lblDatOfBirth.TabIndex = 27;
            this.lblDatOfBirth.Text = "--";
            // 
            // lbllastname
            // 
            this.lbllastname.AutoSize = true;
            this.lbllastname.BackColor = System.Drawing.Color.Teal;
            this.lbllastname.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbllastname.ForeColor = System.Drawing.Color.OldLace;
            this.lbllastname.Location = new System.Drawing.Point(54, 17);
            this.lbllastname.Name = "lbllastname";
            this.lbllastname.Size = new System.Drawing.Size(37, 32);
            this.lbllastname.TabIndex = 28;
            this.lbllastname.Text = "--";
            // 
            // lblgender
            // 
            this.lblgender.AutoSize = true;
            this.lblgender.BackColor = System.Drawing.Color.Teal;
            this.lblgender.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgender.ForeColor = System.Drawing.Color.OldLace;
            this.lblgender.Location = new System.Drawing.Point(54, 14);
            this.lblgender.Name = "lblgender";
            this.lblgender.Size = new System.Drawing.Size(37, 32);
            this.lblgender.TabIndex = 29;
            this.lblgender.Text = "--";
            // 
            // lblcontry
            // 
            this.lblcontry.AutoSize = true;
            this.lblcontry.BackColor = System.Drawing.Color.Teal;
            this.lblcontry.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcontry.ForeColor = System.Drawing.Color.OldLace;
            this.lblcontry.Location = new System.Drawing.Point(54, 7);
            this.lblcontry.Name = "lblcontry";
            this.lblcontry.Size = new System.Drawing.Size(37, 32);
            this.lblcontry.TabIndex = 30;
            this.lblcontry.Text = "--";
            // 
            // lbldistric
            // 
            this.lbldistric.AutoSize = true;
            this.lbldistric.BackColor = System.Drawing.Color.Teal;
            this.lbldistric.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldistric.ForeColor = System.Drawing.Color.OldLace;
            this.lbldistric.Location = new System.Drawing.Point(54, 16);
            this.lbldistric.Name = "lbldistric";
            this.lbldistric.Size = new System.Drawing.Size(37, 32);
            this.lbldistric.TabIndex = 33;
            this.lbldistric.Text = "--";
            // 
            // lblemailid
            // 
            this.lblemailid.AutoSize = true;
            this.lblemailid.BackColor = System.Drawing.Color.Teal;
            this.lblemailid.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblemailid.ForeColor = System.Drawing.Color.OldLace;
            this.lblemailid.Location = new System.Drawing.Point(54, 14);
            this.lblemailid.Name = "lblemailid";
            this.lblemailid.Size = new System.Drawing.Size(37, 32);
            this.lblemailid.TabIndex = 32;
            this.lblemailid.Text = "--";
            // 
            // lblstate
            // 
            this.lblstate.AutoSize = true;
            this.lblstate.BackColor = System.Drawing.Color.Teal;
            this.lblstate.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblstate.ForeColor = System.Drawing.Color.OldLace;
            this.lblstate.Location = new System.Drawing.Point(54, 14);
            this.lblstate.Name = "lblstate";
            this.lblstate.Size = new System.Drawing.Size(37, 32);
            this.lblstate.TabIndex = 31;
            this.lblstate.Text = "--";
            // 
            // lbltaluka
            // 
            this.lbltaluka.AutoSize = true;
            this.lbltaluka.BackColor = System.Drawing.Color.Teal;
            this.lbltaluka.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltaluka.ForeColor = System.Drawing.Color.OldLace;
            this.lbltaluka.Location = new System.Drawing.Point(54, 8);
            this.lbltaluka.Name = "lbltaluka";
            this.lbltaluka.Size = new System.Drawing.Size(37, 32);
            this.lbltaluka.TabIndex = 34;
            this.lbltaluka.Text = "--";
            // 
            // lblaccounttype
            // 
            this.lblaccounttype.AutoSize = true;
            this.lblaccounttype.BackColor = System.Drawing.Color.Teal;
            this.lblaccounttype.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblaccounttype.ForeColor = System.Drawing.Color.OldLace;
            this.lblaccounttype.Location = new System.Drawing.Point(54, 15);
            this.lblaccounttype.Name = "lblaccounttype";
            this.lblaccounttype.Size = new System.Drawing.Size(37, 32);
            this.lblaccounttype.TabIndex = 35;
            this.lblaccounttype.Text = "--";
            // 
            // lblcityvillage
            // 
            this.lblcityvillage.AutoSize = true;
            this.lblcityvillage.BackColor = System.Drawing.Color.Teal;
            this.lblcityvillage.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcityvillage.ForeColor = System.Drawing.Color.OldLace;
            this.lblcityvillage.Location = new System.Drawing.Point(54, 19);
            this.lblcityvillage.Name = "lblcityvillage";
            this.lblcityvillage.Size = new System.Drawing.Size(37, 32);
            this.lblcityvillage.TabIndex = 36;
            this.lblcityvillage.Text = "--";
            // 
            // txtfirstname
            // 
            this.txtfirstname.BackColor = System.Drawing.Color.CadetBlue;
            this.txtfirstname.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtfirstname.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfirstname.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtfirstname.Location = new System.Drawing.Point(42, 9);
            this.txtfirstname.MaxLength = 15;
            this.txtfirstname.Name = "txtfirstname";
            this.txtfirstname.Size = new System.Drawing.Size(434, 43);
            this.txtfirstname.TabIndex = 21;
            this.txtfirstname.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtfirstname_KeyDown);
            // 
            // txtmiddlename
            // 
            this.txtmiddlename.BackColor = System.Drawing.Color.CadetBlue;
            this.txtmiddlename.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtmiddlename.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmiddlename.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtmiddlename.Location = new System.Drawing.Point(42, 7);
            this.txtmiddlename.MaxLength = 15;
            this.txtmiddlename.Name = "txtmiddlename";
            this.txtmiddlename.Size = new System.Drawing.Size(434, 43);
            this.txtmiddlename.TabIndex = 22;
            this.txtmiddlename.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtfirstname_KeyDown);
            // 
            // txtlastname
            // 
            this.txtlastname.BackColor = System.Drawing.Color.CadetBlue;
            this.txtlastname.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtlastname.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtlastname.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtlastname.Location = new System.Drawing.Point(42, 10);
            this.txtlastname.MaxLength = 15;
            this.txtlastname.Name = "txtlastname";
            this.txtlastname.Size = new System.Drawing.Size(434, 43);
            this.txtlastname.TabIndex = 23;
            this.txtlastname.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtfirstname_KeyDown);
            // 
            // txtmobile
            // 
            this.txtmobile.BackColor = System.Drawing.Color.CadetBlue;
            this.txtmobile.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtmobile.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmobile.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtmobile.Location = new System.Drawing.Point(42, 8);
            this.txtmobile.MaxLength = 15;
            this.txtmobile.Name = "txtmobile";
            this.txtmobile.Size = new System.Drawing.Size(434, 43);
            this.txtmobile.TabIndex = 24;
            this.txtmobile.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtfirstname_KeyDown);
            // 
            // txtdob
            // 
            this.txtdob.BackColor = System.Drawing.Color.CadetBlue;
            this.txtdob.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtdob.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdob.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtdob.Location = new System.Drawing.Point(42, 10);
            this.txtdob.MaxLength = 15;
            this.txtdob.Name = "txtdob";
            this.txtdob.Size = new System.Drawing.Size(434, 43);
            this.txtdob.TabIndex = 25;
            this.txtdob.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtfirstname_KeyDown);
            // 
            // txtemail
            // 
            this.txtemail.BackColor = System.Drawing.Color.CadetBlue;
            this.txtemail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtemail.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtemail.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtemail.Location = new System.Drawing.Point(42, 7);
            this.txtemail.MaxLength = 15;
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(434, 43);
            this.txtemail.TabIndex = 27;
            this.txtemail.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtfirstname_KeyDown);
            // 
            // txtstate
            // 
            this.txtstate.BackColor = System.Drawing.Color.CadetBlue;
            this.txtstate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtstate.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtstate.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtstate.Location = new System.Drawing.Point(42, 7);
            this.txtstate.MaxLength = 15;
            this.txtstate.Name = "txtstate";
            this.txtstate.Size = new System.Drawing.Size(434, 43);
            this.txtstate.TabIndex = 26;
            this.txtstate.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtfirstname_KeyDown);
            // 
            // txtdistric
            // 
            this.txtdistric.BackColor = System.Drawing.Color.CadetBlue;
            this.txtdistric.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtdistric.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdistric.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtdistric.Location = new System.Drawing.Point(42, 9);
            this.txtdistric.MaxLength = 15;
            this.txtdistric.Name = "txtdistric";
            this.txtdistric.Size = new System.Drawing.Size(434, 43);
            this.txtdistric.TabIndex = 27;
            this.txtdistric.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtfirstname_KeyDown);
            // 
            // txttaluka
            // 
            this.txttaluka.BackColor = System.Drawing.Color.CadetBlue;
            this.txttaluka.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txttaluka.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttaluka.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txttaluka.Location = new System.Drawing.Point(42, 8);
            this.txttaluka.MaxLength = 15;
            this.txttaluka.Name = "txttaluka";
            this.txttaluka.Size = new System.Drawing.Size(434, 43);
            this.txttaluka.TabIndex = 28;
            this.txttaluka.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtfirstname_KeyDown);
            // 
            // cityvillage
            // 
            this.cityvillage.BackColor = System.Drawing.Color.CadetBlue;
            this.cityvillage.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.cityvillage.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cityvillage.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.cityvillage.Location = new System.Drawing.Point(42, 6);
            this.cityvillage.MaxLength = 15;
            this.cityvillage.Name = "cityvillage";
            this.cityvillage.Size = new System.Drawing.Size(434, 43);
            this.cityvillage.TabIndex = 30;
            this.cityvillage.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtfirstname_KeyDown);
            // 
            // selectcontry
            // 
            this.selectcontry.BackColor = System.Drawing.Color.CadetBlue;
            this.selectcontry.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.selectcontry.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.selectcontry.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectcontry.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.selectcontry.FormattingEnabled = true;
            this.selectcontry.Items.AddRange(new object[] {
            "India",
            "Japan",
            "Autrailia",
            "Bangladesh",
            "Malasiya",
            "USA",
            "China",
            "Myanmar",
            "Shree Lanka",
            "Afghanistan"});
            this.selectcontry.Location = new System.Drawing.Point(42, 8);
            this.selectcontry.Name = "selectcontry";
            this.selectcontry.Size = new System.Drawing.Size(434, 45);
            this.selectcontry.TabIndex = 28;
            this.selectcontry.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtfirstname_KeyDown);
            // 
            // selectactype
            // 
            this.selectactype.BackColor = System.Drawing.Color.CadetBlue;
            this.selectactype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.selectactype.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.selectactype.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectactype.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.selectactype.FormattingEnabled = true;
            this.selectactype.Items.AddRange(new object[] {
            "Saving",
            "Current",
            "Fix Deposit"});
            this.selectactype.Location = new System.Drawing.Point(42, 11);
            this.selectactype.Name = "selectactype";
            this.selectactype.Size = new System.Drawing.Size(434, 45);
            this.selectactype.TabIndex = 29;
            this.selectactype.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtfirstname_KeyDown);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Teal;
            this.label12.Font = new System.Drawing.Font("Calisto MT", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.OldLace;
            this.label12.Location = new System.Drawing.Point(91, 21);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(172, 32);
            this.label12.TabIndex = 32;
            this.label12.Text = "10. Distric  :";
            // 
            // selectgender
            // 
            this.selectgender.BackColor = System.Drawing.Color.CadetBlue;
            this.selectgender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.selectgender.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.selectgender.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectgender.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.selectgender.FormattingEnabled = true;
            this.selectgender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.selectgender.Location = new System.Drawing.Point(42, 7);
            this.selectgender.Name = "selectgender";
            this.selectgender.Size = new System.Drawing.Size(434, 45);
            this.selectgender.TabIndex = 29;
            this.selectgender.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtfirstname_KeyDown);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.White;
            this.label19.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Red;
            this.label19.Location = new System.Drawing.Point(10, 9);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(244, 28);
            this.label19.TabIndex = 23;
            this.label19.Text = "Set Value - (Ctrl + S)";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.White;
            this.label20.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Red;
            this.label20.Location = new System.Drawing.Point(10, 49);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(220, 28);
            this.label20.TabIndex = 24;
            this.label20.Text = "Update - (Ctrl + U)";
            // 
            // Edit_Customer_Data
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(1924, 1100);
            this.Controls.Add(this.newvaluepanel);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.oddvaluepanel);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.categorypael);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Edit_Customer_Data";
            this.Text = "Edit_Customer_Data";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Edit_Customer_Data_Load);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.categorypael.ResumeLayout(false);
            this.oddvaluepanel.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.panel29.ResumeLayout(false);
            this.panel29.PerformLayout();
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.panel33.ResumeLayout(false);
            this.panel33.PerformLayout();
            this.panel34.ResumeLayout(false);
            this.panel34.PerformLayout();
            this.panel35.ResumeLayout(false);
            this.panel35.PerformLayout();
            this.newvaluepanel.ResumeLayout(false);
            this.panel36.ResumeLayout(false);
            this.panel37.ResumeLayout(false);
            this.panel37.PerformLayout();
            this.panel38.ResumeLayout(false);
            this.panel38.PerformLayout();
            this.panel39.ResumeLayout(false);
            this.panel39.PerformLayout();
            this.panel40.ResumeLayout(false);
            this.panel40.PerformLayout();
            this.panel41.ResumeLayout(false);
            this.panel41.PerformLayout();
            this.panel42.ResumeLayout(false);
            this.panel42.PerformLayout();
            this.panel43.ResumeLayout(false);
            this.panel44.ResumeLayout(false);
            this.panel44.PerformLayout();
            this.panel45.ResumeLayout(false);
            this.panel45.PerformLayout();
            this.panel46.ResumeLayout(false);
            this.panel47.ResumeLayout(false);
            this.panel47.PerformLayout();
            this.panel48.ResumeLayout(false);
            this.panel48.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        public System.Windows.Forms.TextBox CheckAcBalance;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel categorypael;
        private System.Windows.Forms.Panel oddvaluepanel;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label dcddcdscsdcscdsd;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Label lblcityvillage;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Label lblaccounttype;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Label lblemailid;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Label lblstate;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Label lbllastname;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Label lbldistric;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Label lblDatOfBirth;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Label lblgender;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Label lbltaluka;
        private System.Windows.Forms.Label lblfirstname;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Label lblcontry;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Label lblMobilenumber;
        private System.Windows.Forms.Label lblmiddlename;
        private System.Windows.Forms.Panel newvaluepanel;
        private System.Windows.Forms.Panel panel36;
        public System.Windows.Forms.TextBox cityvillage;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Panel panel38;
        public System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Panel panel39;
        public System.Windows.Forms.TextBox txtstate;
        private System.Windows.Forms.Panel panel40;
        public System.Windows.Forms.TextBox txtlastname;
        private System.Windows.Forms.Panel panel41;
        public System.Windows.Forms.TextBox txtdistric;
        private System.Windows.Forms.Panel panel42;
        public System.Windows.Forms.TextBox txtdob;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.Panel panel44;
        public System.Windows.Forms.TextBox txttaluka;
        private System.Windows.Forms.Panel panel45;
        public System.Windows.Forms.TextBox txtfirstname;
        private System.Windows.Forms.Panel panel46;
        private System.Windows.Forms.Panel panel47;
        public System.Windows.Forms.TextBox txtmobile;
        private System.Windows.Forms.Panel panel48;
        public System.Windows.Forms.TextBox txtmiddlename;
        private System.Windows.Forms.ComboBox selectcontry;
        private System.Windows.Forms.ComboBox selectactype;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox selectgender;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
    }
}