﻿namespace Bank_Management_System
{
    partial class Cash_Deposite
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel5 = new System.Windows.Forms.Panel();
            this.AcNumber = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.Trasaction_Proceed = new System.Windows.Forms.Label();
            this.Pleasewaitlbl = new System.Windows.Forms.Label();
            this.T_Complete = new System.Windows.Forms.Label();
            this.Main_Panel = new System.Windows.Forms.Panel();
            this.Balance_Panel = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.CheckAcBalance = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.Cancel_lbl = new System.Windows.Forms.Label();
            this.Cancel_Panel = new System.Windows.Forms.Panel();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.Main_Panel.SuspendLayout();
            this.Balance_Panel.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.Cancel_Panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Teal;
            this.panel5.Controls.Add(this.AcNumber);
            this.panel5.Location = new System.Drawing.Point(868, 23);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(398, 61);
            this.panel5.TabIndex = 18;
            // 
            // AcNumber
            // 
            this.AcNumber.AutoSize = true;
            this.AcNumber.BackColor = System.Drawing.Color.Teal;
            this.AcNumber.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AcNumber.ForeColor = System.Drawing.Color.OldLace;
            this.AcNumber.Location = new System.Drawing.Point(3, 9);
            this.AcNumber.Name = "AcNumber";
            this.AcNumber.Size = new System.Drawing.Size(31, 43);
            this.AcNumber.TabIndex = 2;
            this.AcNumber.Text = "-";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.label44);
            this.panel1.Controls.Add(this.label45);
            this.panel1.Location = new System.Drawing.Point(40, 23);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(822, 61);
            this.panel1.TabIndex = 17;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.Teal;
            this.label44.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.Chartreuse;
            this.label44.Location = new System.Drawing.Point(122, 9);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(270, 43);
            this.label44.TabIndex = 3;
            this.label44.Text = "GIR BANK  - ";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Teal;
            this.label45.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.OldLace;
            this.label45.Location = new System.Drawing.Point(409, 9);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(296, 43);
            this.label45.TabIndex = 2;
            this.label45.Text = "Cash Deposite\r\n";
            // 
            // timer1
            // 
            this.timer1.Interval = 50;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Teal;
            this.panel2.Controls.Add(this.Cancel_Panel);
            this.panel2.Controls.Add(this.Main_Panel);
            this.panel2.Controls.Add(this.Trasaction_Proceed);
            this.panel2.Controls.Add(this.Pleasewaitlbl);
            this.panel2.Controls.Add(this.T_Complete);
            this.panel2.Location = new System.Drawing.Point(40, 112);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1226, 563);
            this.panel2.TabIndex = 20;
            // 
            // Trasaction_Proceed
            // 
            this.Trasaction_Proceed.AutoSize = true;
            this.Trasaction_Proceed.BackColor = System.Drawing.Color.Teal;
            this.Trasaction_Proceed.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Trasaction_Proceed.ForeColor = System.Drawing.Color.OldLace;
            this.Trasaction_Proceed.Location = new System.Drawing.Point(282, 260);
            this.Trasaction_Proceed.Name = "Trasaction_Proceed";
            this.Trasaction_Proceed.Size = new System.Drawing.Size(750, 43);
            this.Trasaction_Proceed.TabIndex = 23;
            this.Trasaction_Proceed.Text = "Trasaction Is Proceed Please Wait.......";
            // 
            // Pleasewaitlbl
            // 
            this.Pleasewaitlbl.AutoSize = true;
            this.Pleasewaitlbl.BackColor = System.Drawing.Color.Teal;
            this.Pleasewaitlbl.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pleasewaitlbl.ForeColor = System.Drawing.Color.OldLace;
            this.Pleasewaitlbl.Location = new System.Drawing.Point(475, 260);
            this.Pleasewaitlbl.Name = "Pleasewaitlbl";
            this.Pleasewaitlbl.Size = new System.Drawing.Size(294, 43);
            this.Pleasewaitlbl.TabIndex = 5;
            this.Pleasewaitlbl.Text = "Please Wait.....";
            // 
            // T_Complete
            // 
            this.T_Complete.AutoSize = true;
            this.T_Complete.BackColor = System.Drawing.Color.Teal;
            this.T_Complete.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.T_Complete.ForeColor = System.Drawing.Color.OldLace;
            this.T_Complete.Location = new System.Drawing.Point(342, 260);
            this.T_Complete.Name = "T_Complete";
            this.T_Complete.Size = new System.Drawing.Size(554, 43);
            this.T_Complete.TabIndex = 5;
            this.T_Complete.Text = "Trasaction Complete.............";
            // 
            // Main_Panel
            // 
            this.Main_Panel.BackColor = System.Drawing.Color.DarkCyan;
            this.Main_Panel.Controls.Add(this.Balance_Panel);
            this.Main_Panel.Location = new System.Drawing.Point(78, 51);
            this.Main_Panel.Name = "Main_Panel";
            this.Main_Panel.Size = new System.Drawing.Size(1121, 450);
            this.Main_Panel.TabIndex = 25;
            // 
            // Balance_Panel
            // 
            this.Balance_Panel.BackColor = System.Drawing.Color.Teal;
            this.Balance_Panel.Controls.Add(this.panel4);
            this.Balance_Panel.Location = new System.Drawing.Point(38, 33);
            this.Balance_Panel.Name = "Balance_Panel";
            this.Balance_Panel.Size = new System.Drawing.Size(1045, 385);
            this.Balance_Panel.TabIndex = 21;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkCyan;
            this.panel4.Controls.Add(this.panel10);
            this.panel4.Controls.Add(this.panel8);
            this.panel4.Controls.Add(this.panel9);
            this.panel4.Controls.Add(this.panel7);
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Location = new System.Drawing.Point(45, 56);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(955, 273);
            this.panel4.TabIndex = 26;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Teal;
            this.panel10.Controls.Add(this.label3);
            this.panel10.Location = new System.Drawing.Point(38, 141);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(289, 94);
            this.panel10.TabIndex = 22;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(15, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(257, 33);
            this.label3.TabIndex = 58;
            this.label3.Text = "Cancel - (Ctrl + c)";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Teal;
            this.panel8.Controls.Add(this.label7);
            this.panel8.Location = new System.Drawing.Point(600, 141);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(312, 94);
            this.panel8.TabIndex = 20;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(42, 33);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(236, 33);
            this.label7.TabIndex = 22;
            this.label7.Text = "Enter - (Ctrl + e)\r\n";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Teal;
            this.panel9.Controls.Add(this.label2);
            this.panel9.Location = new System.Drawing.Point(623, 312);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(255, 109);
            this.panel9.TabIndex = 57;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(21, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(212, 33);
            this.label2.TabIndex = 22;
            this.label2.Text = "Exit - (Ctrl + X)";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Teal;
            this.panel7.Controls.Add(this.CheckAcBalance);
            this.panel7.Location = new System.Drawing.Point(345, 141);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(238, 94);
            this.panel7.TabIndex = 19;
            // 
            // CheckAcBalance
            // 
            this.CheckAcBalance.BackColor = System.Drawing.Color.CadetBlue;
            this.CheckAcBalance.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CheckAcBalance.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckAcBalance.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.CheckAcBalance.Location = new System.Drawing.Point(35, 25);
            this.CheckAcBalance.MaxLength = 15;
            this.CheckAcBalance.Name = "CheckAcBalance";
            this.CheckAcBalance.Size = new System.Drawing.Size(159, 45);
            this.CheckAcBalance.TabIndex = 21;
            this.CheckAcBalance.KeyDown += new System.Windows.Forms.KeyEventHandler(this.CheckAcBalance_KeyDown);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Teal;
            this.panel6.Controls.Add(this.label1);
            this.panel6.Location = new System.Drawing.Point(38, 33);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(874, 62);
            this.panel6.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Teal;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.OldLace;
            this.label1.Location = new System.Drawing.Point(200, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(473, 43);
            this.label1.TabIndex = 22;
            this.label1.Text = "Enter Deposite Amount\r\n";
            // 
            // timer2
            // 
            this.timer2.Interval = 50;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // Cancel_lbl
            // 
            this.Cancel_lbl.AutoSize = true;
            this.Cancel_lbl.BackColor = System.Drawing.Color.Teal;
            this.Cancel_lbl.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cancel_lbl.ForeColor = System.Drawing.Color.OldLace;
            this.Cancel_lbl.Location = new System.Drawing.Point(51, 15);
            this.Cancel_lbl.Name = "Cancel_lbl";
            this.Cancel_lbl.Size = new System.Drawing.Size(625, 43);
            this.Cancel_lbl.TabIndex = 26;
            this.Cancel_lbl.Text = "Last Trasaction  Canceled..........";
            // 
            // Cancel_Panel
            // 
            this.Cancel_Panel.BackColor = System.Drawing.Color.Teal;
            this.Cancel_Panel.Controls.Add(this.Cancel_lbl);
            this.Cancel_Panel.Location = new System.Drawing.Point(262, 233);
            this.Cancel_Panel.Name = "Cancel_Panel";
            this.Cancel_Panel.Size = new System.Drawing.Size(770, 70);
            this.Cancel_Panel.TabIndex = 19;
            // 
            // Cash_Deposite
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(1316, 738);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Cash_Deposite";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cash_Deposite";
            this.Load += new System.EventHandler(this.Cash_Deposite_Load);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.Main_Panel.ResumeLayout(false);
            this.Balance_Panel.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.Cancel_Panel.ResumeLayout(false);
            this.Cancel_Panel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel5;
        public System.Windows.Forms.Label AcNumber;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel Main_Panel;
        private System.Windows.Forms.Panel Balance_Panel;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel7;
        public System.Windows.Forms.TextBox CheckAcBalance;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Trasaction_Proceed;
        private System.Windows.Forms.Label Pleasewaitlbl;
        private System.Windows.Forms.Label T_Complete;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label Cancel_lbl;
        private System.Windows.Forms.Panel Cancel_Panel;
    }
}