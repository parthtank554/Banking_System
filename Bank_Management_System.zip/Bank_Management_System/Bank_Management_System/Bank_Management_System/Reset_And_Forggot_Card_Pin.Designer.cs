﻿namespace Bank_Management_System
{
    partial class Reset_And_Forggot_Card_Pin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.ChkOperations = new System.Windows.Forms.ComboBox();
            this.Exit_Panel = new System.Windows.Forms.Panel();
            this.lblexit = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.Exit_Panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Teal;
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Location = new System.Drawing.Point(566, 241);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(792, 413);
            this.panel2.TabIndex = 65;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkCyan;
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.label44);
            this.panel3.Location = new System.Drawing.Point(75, 31);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(663, 89);
            this.panel3.TabIndex = 67;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Yellow;
            this.label1.Location = new System.Drawing.Point(329, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(272, 36);
            this.label1.TabIndex = 31;
            this.label1.Text = "Pin Management";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.DarkCyan;
            this.label44.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.Chartreuse;
            this.label44.Location = new System.Drawing.Point(39, 31);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(270, 43);
            this.label44.TabIndex = 4;
            this.label44.Text = "GIR BANK  - ";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkCyan;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.ChkOperations);
            this.panel1.Location = new System.Drawing.Point(135, 217);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(532, 134);
            this.panel1.TabIndex = 66;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(244, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 28);
            this.label2.TabIndex = 79;
            this.label2.Text = "*";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Yellow;
            this.label10.Location = new System.Drawing.Point(87, 29);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(162, 24);
            this.label10.TabIndex = 30;
            this.label10.Text = "Select Operation";
            // 
            // ChkOperations
            // 
            this.ChkOperations.BackColor = System.Drawing.Color.Teal;
            this.ChkOperations.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ChkOperations.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ChkOperations.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChkOperations.ForeColor = System.Drawing.Color.Yellow;
            this.ChkOperations.FormattingEnabled = true;
            this.ChkOperations.Items.AddRange(new object[] {
            "Generate New Pin",
            "Reset Pin"});
            this.ChkOperations.Location = new System.Drawing.Point(91, 56);
            this.ChkOperations.Name = "ChkOperations";
            this.ChkOperations.Size = new System.Drawing.Size(348, 45);
            this.ChkOperations.TabIndex = 29;
            this.ChkOperations.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ComboContry_KeyDown);
            // 
            // Exit_Panel
            // 
            this.Exit_Panel.BackColor = System.Drawing.Color.Teal;
            this.Exit_Panel.Controls.Add(this.lblexit);
            this.Exit_Panel.Location = new System.Drawing.Point(792, 162);
            this.Exit_Panel.Name = "Exit_Panel";
            this.Exit_Panel.Size = new System.Drawing.Size(369, 73);
            this.Exit_Panel.TabIndex = 66;
            // 
            // lblexit
            // 
            this.lblexit.AutoSize = true;
            this.lblexit.BackColor = System.Drawing.Color.White;
            this.lblexit.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblexit.ForeColor = System.Drawing.Color.Red;
            this.lblexit.Location = new System.Drawing.Point(81, 20);
            this.lblexit.Name = "lblexit";
            this.lblexit.Size = new System.Drawing.Size(191, 29);
            this.lblexit.TabIndex = 25;
            this.lblexit.Text = "Exit  - (Ctrl + X)";
            // 
            // Reset_And_Forggot_Card_Pin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(1893, 914);
            this.Controls.Add(this.Exit_Panel);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Reset_And_Forggot_Card_Pin";
            this.Text = "Reset_And_Forggot_Card_Pin";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Reset_And_Forggot_Card_Pin_Load);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.Exit_Panel.ResumeLayout(false);
            this.Exit_Panel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox ChkOperations;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel Exit_Panel;
        private System.Windows.Forms.Label lblexit;
    }
}