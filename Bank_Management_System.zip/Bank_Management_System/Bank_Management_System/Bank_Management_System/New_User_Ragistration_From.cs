﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;

namespace Bank_Management_System
{
    public partial class New_User_Ragistration_From : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        public void exit()
        {
            this.Close();
            Form1 obj = new Form1();
            obj.Show();
        }

        public void resetdata()
        {
                txtLastname.Clear();
                txtFirstname.Clear();
                txtMiddlename.Clear();
                txtDateOfBirth.Clear();
                ComboGender.Text = "";
                txtMobileNumber.Clear();
                txtEmailId.Clear();
                ComboContry.Text = "";
                txtState.Clear();
                txtDistric.Clear();
                txtTaluka.Clear();
                txtTawonCity.Clear();
                txtPincode.Clear();
                AltenateMobileNumber.Clear();
                TenthPercentage.Clear();
                TwelvePercentage.Clear();
                GrajuationPercentage.Clear();
                text_Captcha.Clear();
                txtLastname.Focus();
        }
        public New_User_Ragistration_From()
        {
            InitializeComponent();
        }

        private void New_User_Ragistration_From_Load(object sender, EventArgs e)
        {
            Random rand = new Random();
            int num = rand.Next(6, 7);
            int total = 0;
            string captcha = "";

            do
            {
                int chr = rand.Next(100, 123);
                if ((chr >= 48 && chr <= 57) || (chr >= 65 && chr <= 90) || (chr >= 97 && chr <= 122))
                {
                    captcha = captcha + (char)chr;
                    total++;
                    if (total == num)
                        break;
                    {

                    }
                }
            } while (true);
            Captcha.Text = captcha;
        }
        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 obj = new Form1();
            obj.Show();
        }
        private void txtLastname_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (e.KeyChar >= 48 && e.KeyChar <= 57)
            {
                e.Handled = true;
            }
        }

        private void txtFirstname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 48 && e.KeyChar <= 57)
            {
                e.Handled = true;
            }
        }

        private void txtMiddlename_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 48 && e.KeyChar <= 57)
            {
                e.Handled = true;
            }
        }

        private void txtDateOfBirth_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122)
            {
                e.Handled = true;
            }
        }

        private void txtMobileNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122)
            {
                e.Handled = true;
            }
        }

        private void txtState_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 48 && e.KeyChar <= 57)
            {
                e.Handled = true;
            }
        }

        private void txtDistric_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 48 && e.KeyChar <= 57)
            {
                e.Handled = true;
            }
        }

        private void txtTaluka_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 48 && e.KeyChar <= 57)
            {
                e.Handled = true;
            }
        }

        private void txtTawonCity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 48 && e.KeyChar <= 57)
            {
                e.Handled = true;
            }
        }

        private void txtPincode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122)
            {
                e.Handled = true;
            }
        }

        private void AltenateMobileNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122)
            {
                e.Handled = true;
            }
        }

        private void TenthPercentage_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122)
            {
                e.Handled = true;
            }
        }

        private void TwelvePercentage_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122)
            {
                e.Handled = true;
            }
        }

        private void GrajuationPercentage_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122)
            {
                e.Handled = true;
            }
        }

        private void text_Captcha_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 48 && e.KeyChar <= 57)
            {
                e.Handled = true;
            }
        }

        private void text_Captcha_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt32(text_Captcha.Text.Length) == 6)
            {
                Random rm = new Random();
                int ran = rm.Next(8000000, 16000000);
                string pass = ran.ToString();


                if (txtLastname.Text == "" || txtFirstname.Text == "" || txtMiddlename.Text == "" || txtDateOfBirth.Text == "" || ComboGender.SelectedItem == "" || txtMobileNumber.Text == "" || txtEmailId.Text == "" || ComboContry.SelectedItem == "" || txtState.Text == "" || txtDistric.Text == "" || txtTaluka.Text == "" || txtTawonCity.Text == "" || txtPincode.Text == "" || TenthPercentage.Text == "" || TwelvePercentage.Text == "" || GrajuationPercentage.Text == "")
                {
                    MessageBox.Show("Please Fill Out All Madatory Fields", "Blank Records", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    text_Captcha.Clear();
                    text_Captcha.Focus();
                    this.OnLoad(e);
                }
                else
                {
                    if (text_Captcha.Text == "")
                    {
                        MessageBox.Show("Please Enter Captcha Code", "Captcha Code", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        text_Captcha.Focus();
                    }
                    if (Captcha.Text == text_Captcha.Text)
                    {
                        con = new SqlConnection(Con_Class.cnn);
                        con.Open();
                        SqlCommand com;
                        com = new SqlCommand("insert into Employee_Password values('" + pass + "')", con);
                        com.ExecuteNonQuery();
                        cmd = new SqlCommand("insert into Employee_Ragistration  values('" + txtLastname.Text + "','" + txtFirstname.Text + "','" + txtMiddlename.Text + "','" + txtDateOfBirth.Text + "','" + ComboGender.SelectedItem + "','" + txtMobileNumber.Text + "','" + txtEmailId.Text + "','" + ComboContry.SelectedItem + "','" + txtState.Text + "','" + txtDistric.Text + "','" + txtTaluka.Text + "','" + txtTawonCity.Text + "','" + txtPincode.Text + "','" + AltenateMobileNumber.Text + "','" + TenthPercentage.Text + "','" + TwelvePercentage.Text + "','" + GrajuationPercentage.Text + "','" + pass + "')", con);
                        int res = cmd.ExecuteNonQuery();
                        if (res > 0)
                        {

                            MailMessage mail = new MailMessage();
                            string from = "talalagirbankgirsomnath@gmail.com";
                            mail.Subject = "Gir Bank User Varification...!";
                            mail.From = new MailAddress(from);
                            mail.Body = "Hiii ! Dear Applicant Your Varification Code Is : " + pass;
                            mail.To.Add(new MailAddress(txtEmailId.Text));

                            SmtpClient smtp = new SmtpClient();
                            smtp.Host = "smtp.gmail.com";
                            smtp.Port = 587;
                            smtp.UseDefaultCredentials = false;
                            smtp.EnableSsl = true;

                            NetworkCredential nec = new NetworkCredential(from, "feikqmgyuycvlpev");

                            smtp.Credentials = nec;

                            smtp.Send(mail);

                            MessageBox.Show("Detail Submited Successfully", "Detail Submited", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            text_Captcha.Clear();
                            txtLastname.Clear();
                            txtFirstname.Clear();
                            txtMiddlename.Clear();
                            txtDateOfBirth.Clear();
                            ComboGender.Text = "";
                            txtMobileNumber.Clear();
                            txtEmailId.Clear();
                            ComboContry.Text = "";
                            txtState.Clear();
                            txtDistric.Clear();
                            txtTaluka.Clear();
                            txtTawonCity.Clear();
                            txtPincode.Clear();
                            AltenateMobileNumber.Clear();
                            TenthPercentage.Clear();
                            TwelvePercentage.Clear();
                            GrajuationPercentage.Clear();
                            text_Captcha.Clear();
                            txtLastname.Focus();
                            this.OnLoad(e);
                            Display_Random_Password obj = new Display_Random_Password();
                            this.Hide();
                            obj.Show();
                        }
                        else
                        {
                            MessageBox.Show("Somthing Went Wronh Please Try Again", "404", MessageBoxButtons.OK, MessageBoxIcon.Error);

                        }
                    }
                    else
                    {
                        MessageBox.Show(" !! Invalid  Captcha ", "Captcha Code", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        text_Captcha.Clear();
                        text_Captcha.Focus();
                        this.OnLoad(e);
                    }
                }   
            }
        }

        private void txtLastname_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                resetdata();
                this.OnLoad(e);
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                exit();
            }
        }

        private void txtTaluka_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                resetdata();
                this.OnLoad(e);
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                exit();
            }
        }

        private void txtTawonCity_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                resetdata();
                this.OnLoad(e);
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                exit();
            }
        }

        private void txtPincode_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                resetdata();
                this.OnLoad(e);
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                exit();
            }
        }

        private void AltenateMobileNumber_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                resetdata();
                this.OnLoad(e);
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                exit();
            }
        }

        private void TenthPercentage_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                resetdata();
                this.OnLoad(e);
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                exit();
            }
        }

        private void TwelvePercentage_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                resetdata();
                this.OnLoad(e);
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                exit();
            }
        }

        private void GrajuationPercentage_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                resetdata();
                this.OnLoad(e);
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                exit();
            }
        }

        private void text_Captcha_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                resetdata();
                this.OnLoad(e);
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                exit();
            }
        }

        private void txtEmailId_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                resetdata();
                this.OnLoad(e);
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                exit();
            }
        }

        private void txtMobileNumber_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                resetdata();
                this.OnLoad(e);
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                exit();
            }
        }

        private void txtDateOfBirth_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                resetdata();
                this.OnLoad(e);
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                exit();
            }
        }

        private void txtMiddlename_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                resetdata();
                this.OnLoad(e);
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                exit();
            }
        }

        private void txtFirstname_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                resetdata();
                this.OnLoad(e);
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                exit();
            }
        }

        private void ComboGender_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                resetdata();
                this.OnLoad(e);
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                exit();
            }
        }

        private void ComboContry_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                resetdata();
                this.OnLoad(e);
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                exit();
            }
        }

        private void gunaButton1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }

}
