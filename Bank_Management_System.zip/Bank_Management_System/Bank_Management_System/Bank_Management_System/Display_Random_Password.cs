﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Bank_Management_System
{
    public partial class Display_Random_Password : Form
    {
        SqlCommand cmd,cmd2;
        SqlConnection con;
        SqlDataAdapter oda;
        DataTable dt;
        string pass = "";


        public Display_Random_Password()
        {
            InitializeComponent();
        }
        public void getpass()
        {
                con = new SqlConnection(Con_Class.cnn);
                con.Open();

                cmd = new SqlCommand("select ps from Employee_Ragistration where ps='" + LoginPassword.Text + "'", con);
                oda = new SqlDataAdapter(cmd);
                dt = new DataTable();
                oda.Fill(dt);

                foreach (DataRow dr in dt.Rows)
                {
                    pass = dr["ps"].ToString();
                }
            
        }
        private void LoginPassword_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.S)
            {
                getpass();
                if (pass == LoginPassword.Text)
                {
                       MessageBox.Show("Varification Complete....", "Sucess..!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Hide();
                        Reset_Password_From obj = new Reset_Password_From();
                        obj.Random_Number.Text = pass.ToString();
                        obj.Show();
                  
                }
                else
                {
                    MessageBox.Show("Invalid Varification Code.....", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    LoginPassword.Clear();
                    LoginPassword.Focus();
                }
            }
        }

        private void Display_Random_Password_Load_1(object sender, EventArgs e)
        {

        }
}
}
