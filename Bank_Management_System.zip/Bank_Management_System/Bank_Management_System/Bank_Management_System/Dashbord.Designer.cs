﻿namespace Bank_Management_System
{
    partial class Dashbord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel7 = new System.Windows.Forms.Panel();
            this.Card_Number = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Card_Number_Panel = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.txtxpin = new System.Windows.Forms.TextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.Card_Pin_Panel = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.AccountNumber = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.Reset_Password_Link = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel7.SuspendLayout();
            this.Card_Number_Panel.SuspendLayout();
            this.panel8.SuspendLayout();
            this.Card_Pin_Panel.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Teal;
            this.panel7.Controls.Add(this.Card_Number);
            this.panel7.Location = new System.Drawing.Point(12, 52);
            this.panel7.Margin = new System.Windows.Forms.Padding(4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(636, 94);
            this.panel7.TabIndex = 41;
            // 
            // Card_Number
            // 
            this.Card_Number.BackColor = System.Drawing.Color.CadetBlue;
            this.Card_Number.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Card_Number.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Card_Number.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.Card_Number.Location = new System.Drawing.Point(21, 28);
            this.Card_Number.Margin = new System.Windows.Forms.Padding(4);
            this.Card_Number.MaxLength = 16;
            this.Card_Number.Name = "Card_Number";
            this.Card_Number.Size = new System.Drawing.Size(593, 49);
            this.Card_Number.TabIndex = 22;
            this.Card_Number.TextChanged += new System.EventHandler(this.Card_Number_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.DarkCyan;
            this.label6.Font = new System.Drawing.Font("Century Schoolbook", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.OldLace;
            this.label6.Location = new System.Drawing.Point(4, 9);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(389, 40);
            this.label6.TabIndex = 21;
            this.label6.Text = "Enter Card Number :";
            // 
            // Card_Number_Panel
            // 
            this.Card_Number_Panel.BackColor = System.Drawing.Color.DarkCyan;
            this.Card_Number_Panel.Controls.Add(this.panel7);
            this.Card_Number_Panel.Controls.Add(this.label6);
            this.Card_Number_Panel.Location = new System.Drawing.Point(43, 47);
            this.Card_Number_Panel.Margin = new System.Windows.Forms.Padding(4);
            this.Card_Number_Panel.Name = "Card_Number_Panel";
            this.Card_Number_Panel.Size = new System.Drawing.Size(663, 161);
            this.Card_Number_Panel.TabIndex = 38;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.DarkCyan;
            this.label7.Font = new System.Drawing.Font("Century Schoolbook", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.OldLace;
            this.label7.Location = new System.Drawing.Point(79, 12);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(436, 40);
            this.label7.TabIndex = 21;
            this.label7.Text = "Enter Card 4 Digit Pin :\r\n";
            // 
            // txtxpin
            // 
            this.txtxpin.BackColor = System.Drawing.Color.CadetBlue;
            this.txtxpin.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtxpin.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtxpin.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtxpin.Location = new System.Drawing.Point(64, 22);
            this.txtxpin.Margin = new System.Windows.Forms.Padding(4);
            this.txtxpin.MaxLength = 4;
            this.txtxpin.Name = "txtxpin";
            this.txtxpin.Size = new System.Drawing.Size(232, 53);
            this.txtxpin.TabIndex = 22;
            this.txtxpin.TextChanged += new System.EventHandler(this.txtxpin_TextChanged);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Teal;
            this.panel8.Controls.Add(this.txtxpin);
            this.panel8.Location = new System.Drawing.Point(125, 75);
            this.panel8.Margin = new System.Windows.Forms.Padding(4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(364, 94);
            this.panel8.TabIndex = 40;
            // 
            // Card_Pin_Panel
            // 
            this.Card_Pin_Panel.BackColor = System.Drawing.Color.DarkCyan;
            this.Card_Pin_Panel.Controls.Add(this.panel8);
            this.Card_Pin_Panel.Controls.Add(this.label7);
            this.Card_Pin_Panel.Location = new System.Drawing.Point(43, 255);
            this.Card_Pin_Panel.Margin = new System.Windows.Forms.Padding(4);
            this.Card_Pin_Panel.Name = "Card_Pin_Panel";
            this.Card_Pin_Panel.Size = new System.Drawing.Size(648, 187);
            this.Card_Pin_Panel.TabIndex = 39;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Teal;
            this.panel4.Controls.Add(this.Card_Pin_Panel);
            this.panel4.Controls.Add(this.Card_Number_Panel);
            this.panel4.Location = new System.Drawing.Point(28, 37);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(744, 492);
            this.panel4.TabIndex = 37;
            // 
            // AccountNumber
            // 
            this.AccountNumber.AutoSize = true;
            this.AccountNumber.BackColor = System.Drawing.Color.DarkCyan;
            this.AccountNumber.Font = new System.Drawing.Font("Calisto MT", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AccountNumber.ForeColor = System.Drawing.Color.Lime;
            this.AccountNumber.Location = new System.Drawing.Point(241, 39);
            this.AccountNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.AccountNumber.Name = "AccountNumber";
            this.AccountNumber.Size = new System.Drawing.Size(372, 69);
            this.AccountNumber.TabIndex = 24;
            this.AccountNumber.Text = "GIR - BANK";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkCyan;
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(44, 138);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(807, 576);
            this.panel3.TabIndex = 36;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkCyan;
            this.panel5.Controls.Add(this.panel2);
            this.panel5.Location = new System.Drawing.Point(525, 71);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(981, 935);
            this.panel5.TabIndex = 36;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Teal;
            this.panel2.Controls.Add(this.AccountNumber);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(48, 91);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(889, 798);
            this.panel2.TabIndex = 35;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Edwardian Script ITC", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label5.Location = new System.Drawing.Point(260, 976);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(182, 72);
            this.label5.TabIndex = 5;
            this.label5.Text = "Parth Tank\r\nMilan Makvana\r\n";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Edwardian Script ITC", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label4.Location = new System.Drawing.Point(265, 921);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(155, 36);
            this.label4.TabIndex = 4;
            this.label4.Text = "Developed By";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label3.Location = new System.Drawing.Point(280, 602);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(152, 43);
            this.label3.TabIndex = 3;
            this.label3.Text = "System";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label2.Location = new System.Drawing.Point(35, 535);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(408, 102);
            this.label2.TabIndex = 2;
            this.label2.Text = "ATM Management\r\n\r\n";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label1.Location = new System.Drawing.Point(133, 469);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(315, 43);
            this.label1.TabIndex = 1;
            this.label1.Text = "Welcome To The";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.AliceBlue;
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.Reset_Password_Link);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(1, 2);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(477, 1083);
            this.panel1.TabIndex = 35;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label8.Font = new System.Drawing.Font("Century", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label8.Location = new System.Drawing.Point(71, 785);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(377, 44);
            this.label8.TabIndex = 11;
            this.label8.Text = "Go To  Login Page...!";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // Reset_Password_Link
            // 
            this.Reset_Password_Link.AutoSize = true;
            this.Reset_Password_Link.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Reset_Password_Link.Font = new System.Drawing.Font("Century", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Reset_Password_Link.ForeColor = System.Drawing.Color.DodgerBlue;
            this.Reset_Password_Link.Location = new System.Drawing.Point(160, 716);
            this.Reset_Password_Link.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Reset_Password_Link.Name = "Reset_Password_Link";
            this.Reset_Password_Link.Size = new System.Drawing.Size(290, 44);
            this.Reset_Password_Link.TabIndex = 10;
            this.Reset_Password_Link.Text = "Set New Pin....?";
            this.Reset_Password_Link.Click += new System.EventHandler(this.Reset_Password_Link_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Bank_Management_System.Properties.Resources.download__1_;
            this.pictureBox2.Location = new System.Drawing.Point(108, 39);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(279, 305);
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // Dashbord
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(1564, 1084);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Dashbord";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dashbord";
            this.Load += new System.EventHandler(this.Dashbord_Load);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.Card_Number_Panel.ResumeLayout(false);
            this.Card_Number_Panel.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.Card_Pin_Panel.ResumeLayout(false);
            this.Card_Pin_Panel.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel7;
        public System.Windows.Forms.TextBox Card_Number;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel Card_Number_Panel;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.TextBox txtxpin;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel Card_Pin_Panel;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label AccountNumber;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label Reset_Password_Link;
        private System.Windows.Forms.Label label8;
    }
}