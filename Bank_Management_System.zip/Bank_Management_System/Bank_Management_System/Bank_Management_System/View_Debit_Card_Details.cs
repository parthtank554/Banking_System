﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Bank_Management_System
{
    public partial class View_Debit_Card_Details : Form
    {
        SqlCommand cmd,cmd2;
        SqlConnection con;
        SqlDataAdapter oda,oda2;
        DataTable dt,dt2;
        string blocklist;

        public View_Debit_Card_Details()
        {
            InitializeComponent();
        }

        private void View_Debit_Card_Details_Load(object sender, EventArgs e)
        {
            AcDetailPanel.Enabled = false;
        }
        public void Block_List()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();

            cmd2 = new SqlCommand("select * from Block_Unblock_Status where Debit_Number='" + CheckAcBalance.Text + "'", con);
            oda2 = new SqlDataAdapter(cmd2);
            dt2 = new DataTable();
            oda2.Fill(dt2);

            foreach (DataRow dr in dt2.Rows)
            {
                blocklist = dr["Debit_Number"].ToString();
            }
        }
        private void CheckAcBalance_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt32(CheckAcBalance.Text.Length) == 16)
            {
                Block_List();
                if (blocklist == CheckAcBalance.Text)
                {
                    MessageBox.Show("Account Is Blocked...", "DeActivated", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    CheckAcBalance.Enabled = true;
                    CheckAcBalance.Clear();
                    CheckAcBalance.Focus();
                }
                else
                {
                    CheckAcBalance.Enabled = false;
                    con = new SqlConnection(Con_Class.cnn);
                    con.Open();

                    cmd = new SqlCommand("select * from Debit_Card_Apply where DebitNumber='" + CheckAcBalance.Text + "'", con);
                    oda = new SqlDataAdapter(cmd);
                    dt = new DataTable();
                    oda.Fill(dt);

                    foreach (DataRow dr in dt.Rows)
                    {
                        AcDetailPanel.Enabled = true;
                        lblfirstname.Text = dr["Firstname"].ToString();
                        Lastname.Text = dr["Lastname"].ToString();
                        DebitNumber.Text = dr["DebitNumber"].ToString();
                        Accountnumber.Text = dr["AcNumber"].ToString();
                        ValidUpto.Text = dr["ValidUpto"].ToString();
                        CardStatus.Text = dr["Status"].ToString();
                        CardType.Text = dr["CardType"].ToString();
                        CvvNumber.Text = dr["CvvNumber"].ToString();
                    }
                    if (lblfirstname.Text == "-")
                    {
                        MessageBox.Show("Account Not Found....", "Invalid A/c", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        AcDetailPanel.Enabled = false;
                        CheckAcBalance.Enabled = true;
                        CheckAcBalance.Clear();
                        CheckAcBalance.Focus();
                    }
                }
            }
        }
        
        private void Temper_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                lblfirstname.Text = "-";
                Lastname.Text = "-";
                DebitNumber.Text = "-";
                Accountnumber.Text = "-";
                CvvNumber.Text = "-";
                ValidUpto.Text = "-";
                CardType.Text = "-";
                CardStatus.Text = "-";
                AcDetailPanel.Enabled = false;
                CheckAcBalance.Enabled = true;
                CheckAcBalance.Clear();
                CheckAcBalance.Focus();
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                MessageBox.Show("Please Logout First......", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }

        private void CheckAcBalance_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                this.Close();
                Next_Page_Dashbord obj = new Next_Page_Dashbord();
                obj.Show();

            }
        }

        private void CheckAcBalance_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122)
            {
                e.Handled = true;
            }
        }
    }
}
