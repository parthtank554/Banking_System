﻿namespace Bank_Management_System
{
    partial class Reset_Password_From
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.NewPasswordPanel = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNewPassword = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtConfirmPassword = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.nklcdnkcnk = new System.Windows.Forms.Panel();
            this.Exit_Panel = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.Reset_Panel = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.Submit_Panel = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Random_Number = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.NewPasswordPanel.SuspendLayout();
            this.panel3.SuspendLayout();
            this.nklcdnkcnk.SuspendLayout();
            this.Exit_Panel.SuspendLayout();
            this.Reset_Panel.SuspendLayout();
            this.Submit_Panel.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkCyan;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(576, 172);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(672, 61);
            this.panel2.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.DarkCyan;
            this.label2.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Chartreuse;
            this.label2.Location = new System.Drawing.Point(34, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(270, 43);
            this.label2.TabIndex = 3;
            this.label2.Text = "GIR BANK  - ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkCyan;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.OldLace;
            this.label1.Location = new System.Drawing.Point(310, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(326, 43);
            this.label1.TabIndex = 2;
            this.label1.Text = "Reset Password";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkCyan;
            this.panel1.Controls.Add(this.NewPasswordPanel);
            this.panel1.Location = new System.Drawing.Point(127, 261);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1522, 502);
            this.panel1.TabIndex = 3;
            // 
            // NewPasswordPanel
            // 
            this.NewPasswordPanel.BackColor = System.Drawing.Color.Teal;
            this.NewPasswordPanel.Controls.Add(this.panel3);
            this.NewPasswordPanel.Controls.Add(this.nklcdnkcnk);
            this.NewPasswordPanel.Location = new System.Drawing.Point(74, 31);
            this.NewPasswordPanel.Name = "NewPasswordPanel";
            this.NewPasswordPanel.Size = new System.Drawing.Size(1379, 417);
            this.NewPasswordPanel.TabIndex = 4;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkCyan;
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.txtNewPassword);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.txtConfirmPassword);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Location = new System.Drawing.Point(197, 55);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1004, 203);
            this.panel3.TabIndex = 29;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(63, 108);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(23, 28);
            this.label3.TabIndex = 33;
            this.label3.Text = "*";
            // 
            // txtNewPassword
            // 
            this.txtNewPassword.BackColor = System.Drawing.Color.CadetBlue;
            this.txtNewPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNewPassword.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNewPassword.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtNewPassword.Location = new System.Drawing.Point(471, 21);
            this.txtNewPassword.Name = "txtNewPassword";
            this.txtNewPassword.Size = new System.Drawing.Size(448, 39);
            this.txtNewPassword.TabIndex = 29;
            this.txtNewPassword.UseSystemPasswordChar = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(115, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 28);
            this.label4.TabIndex = 28;
            this.label4.Text = "*";
            // 
            // txtConfirmPassword
            // 
            this.txtConfirmPassword.BackColor = System.Drawing.Color.CadetBlue;
            this.txtConfirmPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtConfirmPassword.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConfirmPassword.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtConfirmPassword.Location = new System.Drawing.Point(471, 117);
            this.txtConfirmPassword.Name = "txtConfirmPassword";
            this.txtConfirmPassword.Size = new System.Drawing.Size(448, 39);
            this.txtConfirmPassword.TabIndex = 32;
            this.txtConfirmPassword.UseSystemPasswordChar = true;
            this.txtConfirmPassword.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtConfirmPassword_KeyDown);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Schoolbook", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Yellow;
            this.label7.Location = new System.Drawing.Point(144, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(301, 30);
            this.label7.TabIndex = 27;
            this.label7.Text = "Enter New  Password : ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(-107, 99);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(23, 28);
            this.label8.TabIndex = 31;
            this.label8.Text = "*";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Schoolbook", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Yellow;
            this.label9.Location = new System.Drawing.Point(79, 122);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(390, 30);
            this.label9.TabIndex = 30;
            this.label9.Text = "Re - Type Confirm Password : ";
            // 
            // nklcdnkcnk
            // 
            this.nklcdnkcnk.BackColor = System.Drawing.Color.DarkCyan;
            this.nklcdnkcnk.Controls.Add(this.Exit_Panel);
            this.nklcdnkcnk.Controls.Add(this.Reset_Panel);
            this.nklcdnkcnk.Controls.Add(this.Submit_Panel);
            this.nklcdnkcnk.Controls.Add(this.label37);
            this.nklcdnkcnk.Location = new System.Drawing.Point(22, 315);
            this.nklcdnkcnk.Name = "nklcdnkcnk";
            this.nklcdnkcnk.Size = new System.Drawing.Size(1336, 78);
            this.nklcdnkcnk.TabIndex = 5;
            // 
            // Exit_Panel
            // 
            this.Exit_Panel.BackColor = System.Drawing.Color.Teal;
            this.Exit_Panel.Controls.Add(this.label10);
            this.Exit_Panel.Location = new System.Drawing.Point(925, 7);
            this.Exit_Panel.Name = "Exit_Panel";
            this.Exit_Panel.Size = new System.Drawing.Size(395, 62);
            this.Exit_Panel.TabIndex = 29;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(109, 17);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(185, 29);
            this.label10.TabIndex = 27;
            this.label10.Text = "Exit - (Ctrl + X)";
            // 
            // Reset_Panel
            // 
            this.Reset_Panel.BackColor = System.Drawing.Color.Teal;
            this.Reset_Panel.Controls.Add(this.label12);
            this.Reset_Panel.Location = new System.Drawing.Point(468, 7);
            this.Reset_Panel.Name = "Reset_Panel";
            this.Reset_Panel.Size = new System.Drawing.Size(433, 62);
            this.Reset_Panel.TabIndex = 29;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(99, 17);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(213, 29);
            this.label12.TabIndex = 27;
            this.label12.Text = "Reset - (Ctrl + R)";
            // 
            // Submit_Panel
            // 
            this.Submit_Panel.BackColor = System.Drawing.Color.Teal;
            this.Submit_Panel.Controls.Add(this.label11);
            this.Submit_Panel.Location = new System.Drawing.Point(15, 7);
            this.Submit_Panel.Name = "Submit_Panel";
            this.Submit_Panel.Size = new System.Drawing.Size(433, 62);
            this.Submit_Panel.TabIndex = 28;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(98, 17);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(227, 29);
            this.label11.TabIndex = 27;
            this.label11.Text = "Submit - (Ctrl + S)";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Calisto MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.Color.Yellow;
            this.label37.Location = new System.Drawing.Point(-95, -2);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(77, 22);
            this.label37.TabIndex = 41;
            this.label37.Text = "Captcha";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.DarkCyan;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.DarkCyan;
            this.textBox1.Location = new System.Drawing.Point(925, 1082);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(10, 39);
            this.textBox1.TabIndex = 33;
            this.textBox1.UseSystemPasswordChar = true;
            this.textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyDown);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkCyan;
            this.panel4.Controls.Add(this.Random_Number);
            this.panel4.Location = new System.Drawing.Point(1276, 172);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(373, 62);
            this.panel4.TabIndex = 34;
            // 
            // Random_Number
            // 
            this.Random_Number.AutoSize = true;
            this.Random_Number.BackColor = System.Drawing.Color.White;
            this.Random_Number.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Random_Number.ForeColor = System.Drawing.Color.Red;
            this.Random_Number.Location = new System.Drawing.Point(40, 20);
            this.Random_Number.Name = "Random_Number";
            this.Random_Number.Size = new System.Drawing.Size(21, 29);
            this.Random_Number.TabIndex = 27;
            this.Random_Number.Text = "-\r\n";
            // 
            // Reset_Password_From
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(1870, 1100);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Reset_Password_From";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reset_Password_From";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.NewPasswordPanel.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.nklcdnkcnk.ResumeLayout(false);
            this.nklcdnkcnk.PerformLayout();
            this.Exit_Panel.ResumeLayout(false);
            this.Exit_Panel.PerformLayout();
            this.Reset_Panel.ResumeLayout(false);
            this.Reset_Panel.PerformLayout();
            this.Submit_Panel.ResumeLayout(false);
            this.Submit_Panel.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel NewPasswordPanel;
        private System.Windows.Forms.Panel nklcdnkcnk;
        private System.Windows.Forms.Label label37;
        public System.Windows.Forms.TextBox txtConfirmPassword;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        public System.Windows.Forms.TextBox txtNewPassword;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel Submit_Panel;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel Exit_Panel;
        private System.Windows.Forms.Panel Reset_Panel;
        public System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel4;
        public System.Windows.Forms.Label Random_Number;
    }
}