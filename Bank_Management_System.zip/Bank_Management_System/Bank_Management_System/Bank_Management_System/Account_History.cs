﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Bank_Management_System
{
        
    public partial class Account_History : Form
    {
        SqlConnection con;
        SqlCommand cmd, comm;
        SqlDataAdapter da;
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();

        public Account_History()
        {
            InitializeComponent();
        }
        private void Account_History_Load(object sender, EventArgs e)
        {
            Random rand = new Random();
            int num = rand.Next(6, 8);
            int total = 0;
            string captcha = "";

            do
            {
                int chr = rand.Next(100, 123);
                if ((chr >= 48 && chr <= 57) || (chr >= 65 && chr <= 90) || (chr >= 97 && chr <= 122))
                {
                    captcha = captcha + (char)chr;
                    total++;
                    if (total == num)
                        break;
                    {

                    }
                }
            } while (true);
            Captcha.Text = captcha;
            dataGridView1.Enabled = false;
            Sorted_Panel.Enabled = false;
            Logout_Panel.Visible = false;
            text_Captcha.Focus();
        }
        private void Cancel_Button_Click(object sender, EventArgs e)
        {
            this.Close();
            Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
            obj.Show();
        }
        private void sortedlist_TextChanged(object sender, EventArgs e)
        {
            string qry = "select * from Ac_History where Date like '%" + sortedlist.Text + "%'";
            qry += "OR  Time like '%" + sortedlist.Text + "%'";
            qry += "OR  Name like '%" + sortedlist.Text + "%'";
            qry += "OR  Acnumber like '%" + sortedlist.Text + "%'";
            qry += "OR  Trasaction like '%" + sortedlist.Text + "%'";
            qry += "OR  Amount like '%" + sortedlist.Text + "%'";

            SqlCommand search = new SqlCommand(qry, con);
            SqlDataAdapter adapt = new SqlDataAdapter(search);
            DataTable table = new DataTable();
            adapt.Fill(table);
            dataGridView1.DataSource = table;
            Logout_Panel.Visible  = true;
        }
        private void text_Captcha_KeyDown(object sender, KeyEventArgs e)
        {
           
            if (e.KeyCode == Keys.Enter)
            {
                if (text_Captcha.Text == "")
                {
                    MessageBox.Show("Please Enter Captcha Code !", "Blank Captcha", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.OnLoad(e);
                    dataGridView1.Enabled = false;
                    Logout_Panel.Visible = false;
                    Sorted_Panel.Enabled = false;
                    text_Captcha.Clear();
                    text_Captcha.Focus();

                }
                else
                {
                    if (text_Captcha.Text != Captcha.Text)
                    {
                        MessageBox.Show("Incorrect Captcha Code Try Again !", "Invalid !!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        this.OnLoad(e);
                        dataGridView1.Enabled = false;
                        Sorted_Panel.Enabled = false;
                        Logout_Panel.Enabled = false;
                        text_Captcha.Clear();
                        text_Captcha.Focus();
                    }
                    else
                    {
                        dataGridView1.Enabled = true;
                        Sorted_Panel.Enabled = true;
                        text_Captcha.Clear();
                        Captcha_Panel.Enabled = false;
                        con = new SqlConnection(Con_Class.cnn);
                        con.Open();
                        string str = "select * from Ac_History";
                        cmd = new SqlCommand(str, con);
                        SqlDataReader dr = cmd.ExecuteReader();
                        dt.Load(dr);
                        dataGridView1.DataSource = dt;
                        Logout_Panel.Visible = true;
                        sortedlist.Clear();
                        sortedlist.Focus();
                    }
                }
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                this.Close();
                Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
                obj.Show();
            }
        }

        private void sortedlist_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                if (dataGridView1.DataSource != "")
                {
                    MessageBox.Show("Please Logout First", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Logout_Panel.Visible = true;
                }
                else
                {

                    this.Close();
                    Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
                    obj.Show();
                }
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {

                dataGridView1.Enabled = false;
                sortedlist.Clear();
                Captcha_Panel.Enabled = true;
                text_Captcha.Focus();
                Logout_Panel.Visible = false;
                dataGridView1.DataSource = "";
                this.OnLoad(e);
            }
        }
    }
}
