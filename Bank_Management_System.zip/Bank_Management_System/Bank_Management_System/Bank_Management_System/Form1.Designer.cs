﻿namespace Bank_Management_System
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.checkshowhidepass = new System.Windows.Forms.CheckBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.cps = new System.Windows.Forms.Label();
            this.cp = new System.Windows.Forms.Label();
            this.Captcha = new System.Windows.Forms.Label();
            this.text_Captcha = new System.Windows.Forms.TextBox();
            this.HumanLogo = new System.Windows.Forms.PictureBox();
            this.txtusername = new System.Windows.Forms.TextBox();
            this.UIDLOGO = new System.Windows.Forms.PictureBox();
            this.PASSLOGO = new System.Windows.Forms.PictureBox();
            this.forggotpass = new System.Windows.Forms.LinkLabel();
            this.txtpassword = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.OTP_PANEL = new System.Windows.Forms.Panel();
            this.Reset_Label = new System.Windows.Forms.Label();
            this.ToAcHoldername = new System.Windows.Forms.Label();
            this.OTP = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Reset_Password_Link = new System.Windows.Forms.Label();
            this.New_User_Link = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HumanLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UIDLOGO)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PASSLOGO)).BeginInit();
            this.panel3.SuspendLayout();
            this.OTP_PANEL.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // checkshowhidepass
            // 
            this.checkshowhidepass.AutoSize = true;
            this.checkshowhidepass.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.checkshowhidepass.Font = new System.Drawing.Font("Calisto MT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkshowhidepass.ForeColor = System.Drawing.Color.Yellow;
            this.checkshowhidepass.Location = new System.Drawing.Point(400, 444);
            this.checkshowhidepass.Name = "checkshowhidepass";
            this.checkshowhidepass.Size = new System.Drawing.Size(137, 23);
            this.checkshowhidepass.TabIndex = 37;
            this.checkshowhidepass.Text = "Show Password";
            this.checkshowhidepass.UseVisualStyleBackColor = true;
            this.checkshowhidepass.CheckedChanged += new System.EventHandler(this.checkshowhidepass_CheckedChanged);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkCyan;
            this.panel4.Controls.Add(this.checkshowhidepass);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.cps);
            this.panel4.Controls.Add(this.cp);
            this.panel4.Controls.Add(this.Captcha);
            this.panel4.Controls.Add(this.text_Captcha);
            this.panel4.Controls.Add(this.HumanLogo);
            this.panel4.Controls.Add(this.txtusername);
            this.panel4.Controls.Add(this.UIDLOGO);
            this.panel4.Controls.Add(this.PASSLOGO);
            this.panel4.Controls.Add(this.forggotpass);
            this.panel4.Controls.Add(this.txtpassword);
            this.panel4.Location = new System.Drawing.Point(0, 8);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(810, 626);
            this.panel4.TabIndex = 34;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Calisto MT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Yellow;
            this.label9.Location = new System.Drawing.Point(196, 373);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(68, 17);
            this.label9.TabIndex = 35;
            this.label9.Text = "Password";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Calisto MT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Yellow;
            this.label8.Location = new System.Drawing.Point(196, 279);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 17);
            this.label8.TabIndex = 34;
            this.label8.Text = "Username";
            // 
            // cps
            // 
            this.cps.AutoSize = true;
            this.cps.Font = new System.Drawing.Font("Calisto MT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cps.ForeColor = System.Drawing.Color.Yellow;
            this.cps.Location = new System.Drawing.Point(416, 512);
            this.cps.Name = "cps";
            this.cps.Size = new System.Drawing.Size(99, 17);
            this.cps.TabIndex = 33;
            this.cps.Text = "Captcha Code";
            // 
            // cp
            // 
            this.cp.AutoSize = true;
            this.cp.Font = new System.Drawing.Font("Calisto MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cp.ForeColor = System.Drawing.Color.Yellow;
            this.cp.Location = new System.Drawing.Point(195, 511);
            this.cp.Name = "cp";
            this.cp.Size = new System.Drawing.Size(77, 22);
            this.cp.TabIndex = 7;
            this.cp.Text = "Captcha";
            // 
            // Captcha
            // 
            this.Captcha.AutoSize = true;
            this.Captcha.BackColor = System.Drawing.Color.LightSkyBlue;
            this.Captcha.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Captcha.Font = new System.Drawing.Font("Buxton Sketch", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Captcha.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.Captcha.Location = new System.Drawing.Point(419, 529);
            this.Captcha.Name = "Captcha";
            this.Captcha.Size = new System.Drawing.Size(118, 45);
            this.Captcha.TabIndex = 7;
            this.Captcha.Text = "Captcha";
            // 
            // text_Captcha
            // 
            this.text_Captcha.BackColor = System.Drawing.Color.CadetBlue;
            this.text_Captcha.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.text_Captcha.Font = new System.Drawing.Font("Calisto MT", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_Captcha.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.text_Captcha.Location = new System.Drawing.Point(199, 536);
            this.text_Captcha.Name = "text_Captcha";
            this.text_Captcha.Size = new System.Drawing.Size(174, 38);
            this.text_Captcha.TabIndex = 32;
            this.text_Captcha.TextChanged += new System.EventHandler(this.text_Captcha_TextChanged);
            // 
            // HumanLogo
            // 
            this.HumanLogo.BackColor = System.Drawing.Color.DarkCyan;
            this.HumanLogo.Image = global::Bank_Management_System.Properties.Resources.username_icon_241;
            this.HumanLogo.Location = new System.Drawing.Point(258, 15);
            this.HumanLogo.Name = "HumanLogo";
            this.HumanLogo.Size = new System.Drawing.Size(196, 205);
            this.HumanLogo.TabIndex = 23;
            this.HumanLogo.TabStop = false;
            // 
            // txtusername
            // 
            this.txtusername.BackColor = System.Drawing.Color.CadetBlue;
            this.txtusername.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtusername.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtusername.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtusername.Location = new System.Drawing.Point(199, 299);
            this.txtusername.Name = "txtusername";
            this.txtusername.Size = new System.Drawing.Size(338, 39);
            this.txtusername.TabIndex = 19;
            this.txtusername.TextChanged += new System.EventHandler(this.txtusername_TextChanged);
            this.txtusername.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtusername_KeyDown);
            // 
            // UIDLOGO
            // 
            this.UIDLOGO.BackColor = System.Drawing.Color.Teal;
            this.UIDLOGO.Image = global::Bank_Management_System.Properties.Resources._lock;
            this.UIDLOGO.Location = new System.Drawing.Point(130, 294);
            this.UIDLOGO.Name = "UIDLOGO";
            this.UIDLOGO.Size = new System.Drawing.Size(48, 47);
            this.UIDLOGO.TabIndex = 18;
            this.UIDLOGO.TabStop = false;
            // 
            // PASSLOGO
            // 
            this.PASSLOGO.BackColor = System.Drawing.Color.Teal;
            this.PASSLOGO.Image = global::Bank_Management_System.Properties.Resources.login;
            this.PASSLOGO.Location = new System.Drawing.Point(130, 391);
            this.PASSLOGO.Name = "PASSLOGO";
            this.PASSLOGO.Size = new System.Drawing.Size(48, 47);
            this.PASSLOGO.TabIndex = 21;
            this.PASSLOGO.TabStop = false;
            // 
            // forggotpass
            // 
            this.forggotpass.AutoSize = true;
            this.forggotpass.BackColor = System.Drawing.Color.White;
            this.forggotpass.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.forggotpass.Location = new System.Drawing.Point(320, 721);
            this.forggotpass.Name = "forggotpass";
            this.forggotpass.Size = new System.Drawing.Size(0, 20);
            this.forggotpass.TabIndex = 26;
            // 
            // txtpassword
            // 
            this.txtpassword.BackColor = System.Drawing.Color.CadetBlue;
            this.txtpassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtpassword.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpassword.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtpassword.Location = new System.Drawing.Point(199, 396);
            this.txtpassword.Name = "txtpassword";
            this.txtpassword.Size = new System.Drawing.Size(338, 39);
            this.txtpassword.TabIndex = 22;
            this.txtpassword.UseSystemPasswordChar = true;
            this.txtpassword.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtpassword_KeyDown);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Teal;
            this.panel3.Controls.Add(this.OTP_PANEL);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(360, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(810, 850);
            this.panel3.TabIndex = 34;
            // 
            // OTP_PANEL
            // 
            this.OTP_PANEL.BackColor = System.Drawing.Color.DarkCyan;
            this.OTP_PANEL.Controls.Add(this.Reset_Label);
            this.OTP_PANEL.Controls.Add(this.ToAcHoldername);
            this.OTP_PANEL.Controls.Add(this.OTP);
            this.OTP_PANEL.Location = new System.Drawing.Point(0, 640);
            this.OTP_PANEL.Name = "OTP_PANEL";
            this.OTP_PANEL.Size = new System.Drawing.Size(800, 228);
            this.OTP_PANEL.TabIndex = 35;
            // 
            // Reset_Label
            // 
            this.Reset_Label.AutoSize = true;
            this.Reset_Label.BackColor = System.Drawing.Color.DarkCyan;
            this.Reset_Label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Reset_Label.ForeColor = System.Drawing.Color.AliceBlue;
            this.Reset_Label.Location = new System.Drawing.Point(12, 54);
            this.Reset_Label.Name = "Reset_Label";
            this.Reset_Label.Size = new System.Drawing.Size(223, 33);
            this.Reset_Label.TabIndex = 38;
            this.Reset_Label.Text = "Reset- (Ctrl+R)";
            this.Reset_Label.Click += new System.EventHandler(this.label6_Click_1);
            // 
            // ToAcHoldername
            // 
            this.ToAcHoldername.AutoSize = true;
            this.ToAcHoldername.BackColor = System.Drawing.Color.DarkCyan;
            this.ToAcHoldername.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ToAcHoldername.ForeColor = System.Drawing.Color.Transparent;
            this.ToAcHoldername.Location = new System.Drawing.Point(13, 19);
            this.ToAcHoldername.Name = "ToAcHoldername";
            this.ToAcHoldername.Size = new System.Drawing.Size(197, 33);
            this.ToAcHoldername.TabIndex = 22;
            this.ToAcHoldername.Text = "ENTER OTP :";
            // 
            // OTP
            // 
            this.OTP.BackColor = System.Drawing.Color.CadetBlue;
            this.OTP.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.OTP.Font = new System.Drawing.Font("Calisto MT", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OTP.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.OTP.Location = new System.Drawing.Point(232, 19);
            this.OTP.MaxLength = 4;
            this.OTP.Name = "OTP";
            this.OTP.Size = new System.Drawing.Size(205, 38);
            this.OTP.TabIndex = 36;
            this.OTP.TextChanged += new System.EventHandler(this.OTP_TextChanged);
            // 
            // timer1
            // 
            this.timer1.Interval = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label1.Location = new System.Drawing.Point(98, 340);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(248, 33);
            this.label1.TabIndex = 1;
            this.label1.Text = "Welcome To The";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.AliceBlue;
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.Reset_Password_Link);
            this.panel1.Controls.Add(this.New_User_Link);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(358, 889);
            this.panel1.TabIndex = 32;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label7.Font = new System.Drawing.Font("Century", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label7.Location = new System.Drawing.Point(22, 680);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(326, 34);
            this.label7.TabIndex = 10;
            this.label7.Text = "Go To E - Cornor.........!\r\n";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Bank_Management_System.Properties.Resources.images3;
            this.pictureBox2.Location = new System.Drawing.Point(84, 56);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(188, 176);
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // Reset_Password_Link
            // 
            this.Reset_Password_Link.AutoSize = true;
            this.Reset_Password_Link.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Reset_Password_Link.Font = new System.Drawing.Font("Century", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Reset_Password_Link.ForeColor = System.Drawing.Color.DodgerBlue;
            this.Reset_Password_Link.Location = new System.Drawing.Point(76, 632);
            this.Reset_Password_Link.Name = "Reset_Password_Link";
            this.Reset_Password_Link.Size = new System.Drawing.Size(272, 34);
            this.Reset_Password_Link.TabIndex = 8;
            this.Reset_Password_Link.Text = "Reset Password....?";
            this.Reset_Password_Link.Click += new System.EventHandler(this.Reset_Password_Link_Click);
            // 
            // New_User_Link
            // 
            this.New_User_Link.AutoSize = true;
            this.New_User_Link.Cursor = System.Windows.Forms.Cursors.Hand;
            this.New_User_Link.Font = new System.Drawing.Font("Century", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.New_User_Link.ForeColor = System.Drawing.Color.DodgerBlue;
            this.New_User_Link.Location = new System.Drawing.Point(143, 582);
            this.New_User_Link.Name = "New_User_Link";
            this.New_User_Link.Size = new System.Drawing.Size(203, 34);
            this.New_User_Link.TabIndex = 7;
            this.New_User_Link.Text = "New User.... ?";
            this.New_User_Link.Click += new System.EventHandler(this.New_User_Link_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Edwardian Script ITC", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label5.Location = new System.Drawing.Point(140, 792);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(157, 58);
            this.label5.TabIndex = 5;
            this.label5.Text = "Milan Makavana\r\nParth Tank\r\n";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Edwardian Script ITC", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label4.Location = new System.Drawing.Point(164, 756);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 29);
            this.label4.TabIndex = 4;
            this.label4.Text = "Developed By";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label3.Location = new System.Drawing.Point(229, 441);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 33);
            this.label3.TabIndex = 3;
            this.label3.Text = "System";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label2.Location = new System.Drawing.Point(15, 387);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(333, 40);
            this.label2.TabIndex = 2;
            this.label2.Text = "Bank Management";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = global::Bank_Management_System.Properties.Resources.close;
            this.pictureBox1.Location = new System.Drawing.Point(1388, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(25, 29);
            this.pictureBox1.TabIndex = 35;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox5.Location = new System.Drawing.Point(1450, 0);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(25, 29);
            this.pictureBox5.TabIndex = 33;
            this.pictureBox5.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(1167, 879);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HumanLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UIDLOGO)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PASSLOGO)).EndInit();
            this.panel3.ResumeLayout(false);
            this.OTP_PANEL.ResumeLayout(false);
            this.OTP_PANEL.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.CheckBox checkshowhidepass;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label cps;
        private System.Windows.Forms.Label cp;
        private System.Windows.Forms.Label Captcha;
        public System.Windows.Forms.TextBox text_Captcha;
        private System.Windows.Forms.PictureBox HumanLogo;
        public System.Windows.Forms.TextBox txtusername;
        private System.Windows.Forms.PictureBox UIDLOGO;
        private System.Windows.Forms.PictureBox PASSLOGO;
        private System.Windows.Forms.LinkLabel forggotpass;
        public System.Windows.Forms.TextBox txtpassword;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label Reset_Password_Link;
        private System.Windows.Forms.Label New_User_Link;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label Reset_Label;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.TextBox OTP;
        private System.Windows.Forms.Panel OTP_PANEL;
        private System.Windows.Forms.Label ToAcHoldername;
    }
}

