﻿namespace Bank_Management_System
{
    partial class New_User_Ragistration_From
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label39 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label38 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.Captcha = new System.Windows.Forms.Label();
            this.text_Captcha = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.GrajuationPercentage = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.TwelvePercentage = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.TenthPercentage = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.AltenateMobileNumber = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txtEmailId = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.txtPincode = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.txtTawonCity = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txtTaluka = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtDistric = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtState = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtMobileNumber = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.ComboGender = new System.Windows.Forms.ComboBox();
            this.txtDateOfBirth = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.ComboContry = new System.Windows.Forms.ComboBox();
            this.txtMiddlename = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtFirstname = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtLastname = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.gunaButton1 = new Guna.UI.WinForms.GunaButton();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.panel1.Location = new System.Drawing.Point(12, 72);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1668, 958);
            this.panel1.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkCyan;
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.label36);
            this.panel3.Controls.Add(this.label37);
            this.panel3.Controls.Add(this.Captcha);
            this.panel3.Controls.Add(this.text_Captcha);
            this.panel3.Location = new System.Drawing.Point(348, 863);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1250, 99);
            this.panel3.TabIndex = 2;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Teal;
            this.panel5.Controls.Add(this.label39);
            this.panel5.Location = new System.Drawing.Point(475, 16);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(356, 70);
            this.panel5.TabIndex = 57;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.Color.White;
            this.label39.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.Red;
            this.label39.Location = new System.Drawing.Point(50, 22);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(251, 33);
            this.label39.TabIndex = 22;
            this.label39.Text = "Reset  - (Ctrl + R)";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Teal;
            this.panel4.Controls.Add(this.label38);
            this.panel4.Location = new System.Drawing.Point(871, 16);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(341, 70);
            this.panel4.TabIndex = 56;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.Color.White;
            this.label38.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.Red;
            this.label38.Location = new System.Drawing.Point(74, 19);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(212, 33);
            this.label38.TabIndex = 22;
            this.label38.Text = "Exit - (Ctrl + X)";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Calisto MT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.Yellow;
            this.label36.Location = new System.Drawing.Point(239, 16);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(99, 17);
            this.label36.TabIndex = 37;
            this.label36.Text = "Captcha Code";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Calisto MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.Color.Yellow;
            this.label37.Location = new System.Drawing.Point(23, 12);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(77, 22);
            this.label37.TabIndex = 34;
            this.label37.Text = "Captcha";
            // 
            // Captcha
            // 
            this.Captcha.AutoSize = true;
            this.Captcha.BackColor = System.Drawing.Color.LightSkyBlue;
            this.Captcha.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Captcha.Font = new System.Drawing.Font("Buxton Sketch", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Captcha.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.Captcha.Location = new System.Drawing.Point(242, 33);
            this.Captcha.Name = "Captcha";
            this.Captcha.Size = new System.Drawing.Size(118, 45);
            this.Captcha.TabIndex = 35;
            this.Captcha.Text = "Captcha";
            // 
            // text_Captcha
            // 
            this.text_Captcha.BackColor = System.Drawing.Color.CadetBlue;
            this.text_Captcha.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.text_Captcha.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_Captcha.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.text_Captcha.Location = new System.Drawing.Point(27, 37);
            this.text_Captcha.Name = "text_Captcha";
            this.text_Captcha.Size = new System.Drawing.Size(174, 39);
            this.text_Captcha.TabIndex = 36;
            this.text_Captcha.TextChanged += new System.EventHandler(this.text_Captcha_TextChanged);
            this.text_Captcha.KeyDown += new System.Windows.Forms.KeyEventHandler(this.text_Captcha_KeyDown);
            this.text_Captcha.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.text_Captcha_KeyPress);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.DarkCyan;
            this.groupBox2.Controls.Add(this.GrajuationPercentage);
            this.groupBox2.Controls.Add(this.label35);
            this.groupBox2.Controls.Add(this.label34);
            this.groupBox2.Controls.Add(this.label33);
            this.groupBox2.Controls.Add(this.label32);
            this.groupBox2.Controls.Add(this.TwelvePercentage);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.TenthPercentage);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Yellow;
            this.groupBox2.Location = new System.Drawing.Point(7, 677);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1663, 115);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Qulifications";
            // 
            // GrajuationPercentage
            // 
            this.GrajuationPercentage.BackColor = System.Drawing.Color.CadetBlue;
            this.GrajuationPercentage.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.GrajuationPercentage.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GrajuationPercentage.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.GrajuationPercentage.Location = new System.Drawing.Point(1385, 59);
            this.GrajuationPercentage.MaxLength = 5;
            this.GrajuationPercentage.Name = "GrajuationPercentage";
            this.GrajuationPercentage.Size = new System.Drawing.Size(98, 39);
            this.GrajuationPercentage.TabIndex = 65;
            this.GrajuationPercentage.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GrajuationPercentage_KeyDown);
            this.GrajuationPercentage.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.GrajuationPercentage_KeyPress);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.Red;
            this.label35.Location = new System.Drawing.Point(1356, 59);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(23, 28);
            this.label35.TabIndex = 67;
            this.label35.Text = "*";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.Red;
            this.label34.Location = new System.Drawing.Point(754, 59);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(23, 28);
            this.label34.TabIndex = 66;
            this.label34.Text = "*";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.Red;
            this.label33.Location = new System.Drawing.Point(237, 59);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(23, 28);
            this.label33.TabIndex = 60;
            this.label33.Text = "*";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.Yellow;
            this.label32.Location = new System.Drawing.Point(1069, 70);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(303, 24);
            this.label32.TabIndex = 64;
            this.label32.Text = "Enter Graduation Percentage : ";
            // 
            // TwelvePercentage
            // 
            this.TwelvePercentage.BackColor = System.Drawing.Color.CadetBlue;
            this.TwelvePercentage.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TwelvePercentage.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TwelvePercentage.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.TwelvePercentage.Location = new System.Drawing.Point(783, 59);
            this.TwelvePercentage.MaxLength = 3;
            this.TwelvePercentage.Name = "TwelvePercentage";
            this.TwelvePercentage.Size = new System.Drawing.Size(106, 39);
            this.TwelvePercentage.TabIndex = 63;
            this.TwelvePercentage.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TwelvePercentage_KeyDown);
            this.TwelvePercentage.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TwelvePercentage_KeyPress);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.Yellow;
            this.label31.Location = new System.Drawing.Point(529, 70);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(239, 24);
            this.label31.TabIndex = 62;
            this.label31.Text = "Enter 12th Percentage : ";
            // 
            // TenthPercentage
            // 
            this.TenthPercentage.BackColor = System.Drawing.Color.CadetBlue;
            this.TenthPercentage.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TenthPercentage.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TenthPercentage.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.TenthPercentage.Location = new System.Drawing.Point(277, 59);
            this.TenthPercentage.MaxLength = 3;
            this.TenthPercentage.Name = "TenthPercentage";
            this.TenthPercentage.Size = new System.Drawing.Size(113, 39);
            this.TenthPercentage.TabIndex = 61;
            this.TenthPercentage.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TenthPercentage_KeyDown);
            this.TenthPercentage.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TenthPercentage_KeyPress);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.Yellow;
            this.label29.Location = new System.Drawing.Point(11, 70);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(232, 24);
            this.label29.TabIndex = 60;
            this.label29.Text = "Enter 10th Percentage :";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.DarkCyan;
            this.groupBox1.Controls.Add(this.AltenateMobileNumber);
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.txtEmailId);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.txtPincode);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.txtTawonCity);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.txtTaluka);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.txtDistric);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.txtState);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.txtMobileNumber);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.ComboGender);
            this.groupBox1.Controls.Add(this.txtDateOfBirth);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.ComboContry);
            this.groupBox1.Controls.Add(this.txtMiddlename);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtFirstname);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtLastname);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Yellow;
            this.groupBox1.Location = new System.Drawing.Point(0, 10);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1640, 659);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Personal Information";
            // 
            // AltenateMobileNumber
            // 
            this.AltenateMobileNumber.BackColor = System.Drawing.Color.CadetBlue;
            this.AltenateMobileNumber.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AltenateMobileNumber.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AltenateMobileNumber.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.AltenateMobileNumber.Location = new System.Drawing.Point(578, 601);
            this.AltenateMobileNumber.MaxLength = 10;
            this.AltenateMobileNumber.Name = "AltenateMobileNumber";
            this.AltenateMobileNumber.Size = new System.Drawing.Size(348, 39);
            this.AltenateMobileNumber.TabIndex = 59;
            this.AltenateMobileNumber.KeyDown += new System.Windows.Forms.KeyEventHandler(this.AltenateMobileNumber_KeyDown);
            this.AltenateMobileNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AltenateMobileNumber_KeyPress);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.Yellow;
            this.label30.Location = new System.Drawing.Point(574, 569);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(178, 24);
            this.label30.TabIndex = 57;
            this.label30.Text = "Alternate Number";
            // 
            // txtEmailId
            // 
            this.txtEmailId.BackColor = System.Drawing.Color.CadetBlue;
            this.txtEmailId.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEmailId.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmailId.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtEmailId.Location = new System.Drawing.Point(23, 338);
            this.txtEmailId.Name = "txtEmailId";
            this.txtEmailId.Size = new System.Drawing.Size(341, 39);
            this.txtEmailId.TabIndex = 56;
            this.txtEmailId.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtEmailId_KeyDown);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Red;
            this.label27.Location = new System.Drawing.Point(119, 297);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(23, 28);
            this.label27.TabIndex = 55;
            this.label27.Text = "*";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.Yellow;
            this.label28.Location = new System.Drawing.Point(19, 306);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(99, 24);
            this.label28.TabIndex = 54;
            this.label28.Text = "Email-Id";
            // 
            // txtPincode
            // 
            this.txtPincode.BackColor = System.Drawing.Color.CadetBlue;
            this.txtPincode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPincode.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPincode.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtPincode.Location = new System.Drawing.Point(23, 601);
            this.txtPincode.MaxLength = 6;
            this.txtPincode.Name = "txtPincode";
            this.txtPincode.Size = new System.Drawing.Size(341, 39);
            this.txtPincode.TabIndex = 53;
            this.txtPincode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPincode_KeyDown);
            this.txtPincode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPincode_KeyPress);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Red;
            this.label25.Location = new System.Drawing.Point(201, 565);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(23, 28);
            this.label25.TabIndex = 52;
            this.label25.Text = "*";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Yellow;
            this.label26.Location = new System.Drawing.Point(19, 569);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(188, 24);
            this.label26.TabIndex = 51;
            this.label26.Text = "Pincode (Zip Code)";
            // 
            // txtTawonCity
            // 
            this.txtTawonCity.BackColor = System.Drawing.Color.CadetBlue;
            this.txtTawonCity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTawonCity.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTawonCity.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtTawonCity.Location = new System.Drawing.Point(1118, 477);
            this.txtTawonCity.Name = "txtTawonCity";
            this.txtTawonCity.Size = new System.Drawing.Size(348, 39);
            this.txtTawonCity.TabIndex = 50;
            this.txtTawonCity.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtTawonCity_KeyDown);
            this.txtTawonCity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTawonCity_KeyPress);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Red;
            this.label23.Location = new System.Drawing.Point(1227, 435);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(23, 28);
            this.label23.TabIndex = 49;
            this.label23.Text = "*";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Yellow;
            this.label24.Location = new System.Drawing.Point(1114, 445);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(114, 24);
            this.label24.TabIndex = 48;
            this.label24.Text = "Tawon/City";
            // 
            // txtTaluka
            // 
            this.txtTaluka.BackColor = System.Drawing.Color.CadetBlue;
            this.txtTaluka.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTaluka.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTaluka.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtTaluka.Location = new System.Drawing.Point(578, 465);
            this.txtTaluka.Name = "txtTaluka";
            this.txtTaluka.Size = new System.Drawing.Size(348, 39);
            this.txtTaluka.TabIndex = 47;
            this.txtTaluka.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtTaluka_KeyDown);
            this.txtTaluka.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTaluka_KeyPress);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Red;
            this.label21.Location = new System.Drawing.Point(647, 429);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(23, 28);
            this.label21.TabIndex = 46;
            this.label21.Text = "*";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Yellow;
            this.label22.Location = new System.Drawing.Point(574, 433);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(78, 24);
            this.label22.TabIndex = 45;
            this.label22.Text = "Taluka";
            // 
            // txtDistric
            // 
            this.txtDistric.BackColor = System.Drawing.Color.CadetBlue;
            this.txtDistric.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDistric.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDistric.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtDistric.Location = new System.Drawing.Point(23, 465);
            this.txtDistric.Name = "txtDistric";
            this.txtDistric.Size = new System.Drawing.Size(341, 39);
            this.txtDistric.TabIndex = 44;
            this.txtDistric.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDistric_KeyPress);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Red;
            this.label19.Location = new System.Drawing.Point(100, 422);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(23, 28);
            this.label19.TabIndex = 43;
            this.label19.Text = "*";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Yellow;
            this.label20.Location = new System.Drawing.Point(19, 433);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(75, 24);
            this.label20.TabIndex = 42;
            this.label20.Text = "Distric";
            // 
            // txtState
            // 
            this.txtState.BackColor = System.Drawing.Color.CadetBlue;
            this.txtState.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtState.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtState.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtState.Location = new System.Drawing.Point(1118, 338);
            this.txtState.Name = "txtState";
            this.txtState.Size = new System.Drawing.Size(348, 39);
            this.txtState.TabIndex = 41;
            this.txtState.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtState_KeyPress);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Red;
            this.label17.Location = new System.Drawing.Point(1182, 308);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(23, 28);
            this.label17.TabIndex = 40;
            this.label17.Text = "*";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Yellow;
            this.label18.Location = new System.Drawing.Point(1114, 309);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(56, 24);
            this.label18.TabIndex = 39;
            this.label18.Text = "State";
            // 
            // txtMobileNumber
            // 
            this.txtMobileNumber.BackColor = System.Drawing.Color.CadetBlue;
            this.txtMobileNumber.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMobileNumber.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMobileNumber.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtMobileNumber.Location = new System.Drawing.Point(1118, 204);
            this.txtMobileNumber.MaxLength = 10;
            this.txtMobileNumber.Name = "txtMobileNumber";
            this.txtMobileNumber.Size = new System.Drawing.Size(341, 39);
            this.txtMobileNumber.TabIndex = 38;
            this.txtMobileNumber.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMobileNumber_KeyDown);
            this.txtMobileNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMobileNumber_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(1276, 164);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(23, 28);
            this.label12.TabIndex = 37;
            this.label12.Text = "*";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Yellow;
            this.label16.Location = new System.Drawing.Point(1114, 172);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(156, 24);
            this.label16.TabIndex = 36;
            this.label16.Text = "Mobile Number";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(707, 163);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(23, 28);
            this.label13.TabIndex = 35;
            this.label13.Text = "*";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Yellow;
            this.label14.Location = new System.Drawing.Point(574, 171);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(136, 24);
            this.label14.TabIndex = 34;
            this.label14.Text = "Select Gender";
            // 
            // ComboGender
            // 
            this.ComboGender.BackColor = System.Drawing.Color.CadetBlue;
            this.ComboGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboGender.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ComboGender.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboGender.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.ComboGender.FormattingEnabled = true;
            this.ComboGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.ComboGender.Location = new System.Drawing.Point(578, 204);
            this.ComboGender.Name = "ComboGender";
            this.ComboGender.Size = new System.Drawing.Size(348, 45);
            this.ComboGender.TabIndex = 33;
            this.ComboGender.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ComboGender_KeyDown);
            // 
            // txtDateOfBirth
            // 
            this.txtDateOfBirth.BackColor = System.Drawing.Color.CadetBlue;
            this.txtDateOfBirth.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDateOfBirth.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDateOfBirth.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtDateOfBirth.Location = new System.Drawing.Point(23, 204);
            this.txtDateOfBirth.Name = "txtDateOfBirth";
            this.txtDateOfBirth.Size = new System.Drawing.Size(341, 39);
            this.txtDateOfBirth.TabIndex = 32;
            this.txtDateOfBirth.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtDateOfBirth_KeyDown);
            this.txtDateOfBirth.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDateOfBirth_KeyPress);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(237, 168);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(21, 24);
            this.label11.TabIndex = 31;
            this.label11.Text = "*";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Yellow;
            this.label15.Location = new System.Drawing.Point(19, 177);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(223, 24);
            this.label15.TabIndex = 30;
            this.label15.Text = "DOB (DD/MM/YYYY)";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(702, 297);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(23, 28);
            this.label9.TabIndex = 29;
            this.label9.Text = "*";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Yellow;
            this.label10.Location = new System.Drawing.Point(574, 305);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(131, 24);
            this.label10.TabIndex = 28;
            this.label10.Text = "Select Contry";
            // 
            // ComboContry
            // 
            this.ComboContry.BackColor = System.Drawing.Color.CadetBlue;
            this.ComboContry.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboContry.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ComboContry.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboContry.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.ComboContry.FormattingEnabled = true;
            this.ComboContry.Items.AddRange(new object[] {
            "India",
            "Japan",
            "Autrailia",
            "Bangladesh",
            "Malasiya",
            "USA",
            "China",
            "Myanmar",
            "Shree Lanka",
            "Afghanistan"});
            this.ComboContry.Location = new System.Drawing.Point(578, 338);
            this.ComboContry.Name = "ComboContry";
            this.ComboContry.Size = new System.Drawing.Size(348, 45);
            this.ComboContry.TabIndex = 27;
            this.ComboContry.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ComboContry_KeyDown);
            // 
            // txtMiddlename
            // 
            this.txtMiddlename.BackColor = System.Drawing.Color.CadetBlue;
            this.txtMiddlename.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMiddlename.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMiddlename.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtMiddlename.Location = new System.Drawing.Point(1118, 83);
            this.txtMiddlename.Name = "txtMiddlename";
            this.txtMiddlename.Size = new System.Drawing.Size(341, 39);
            this.txtMiddlename.TabIndex = 26;
            this.txtMiddlename.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtMiddlename_KeyDown);
            this.txtMiddlename.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMiddlename_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(1235, 47);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(23, 28);
            this.label7.TabIndex = 25;
            this.label7.Text = "*";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Yellow;
            this.label8.Location = new System.Drawing.Point(1114, 51);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(125, 24);
            this.label8.TabIndex = 24;
            this.label8.Text = "Middlename";
            // 
            // txtFirstname
            // 
            this.txtFirstname.BackColor = System.Drawing.Color.CadetBlue;
            this.txtFirstname.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtFirstname.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFirstname.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtFirstname.Location = new System.Drawing.Point(578, 83);
            this.txtFirstname.Name = "txtFirstname";
            this.txtFirstname.Size = new System.Drawing.Size(348, 39);
            this.txtFirstname.TabIndex = 23;
            this.txtFirstname.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtFirstname_KeyDown);
            this.txtFirstname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFirstname_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(674, 47);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 28);
            this.label5.TabIndex = 22;
            this.label5.Text = "*";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Yellow;
            this.label6.Location = new System.Drawing.Point(574, 51);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 24);
            this.label6.TabIndex = 21;
            this.label6.Text = "Firstname";
            // 
            // txtLastname
            // 
            this.txtLastname.BackColor = System.Drawing.Color.CadetBlue;
            this.txtLastname.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtLastname.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLastname.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtLastname.Location = new System.Drawing.Point(23, 83);
            this.txtLastname.Name = "txtLastname";
            this.txtLastname.Size = new System.Drawing.Size(341, 39);
            this.txtLastname.TabIndex = 20;
            this.txtLastname.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLastname_KeyDown);
            this.txtLastname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLastname_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(219, 47);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 28);
            this.label4.TabIndex = 2;
            this.label4.Text = "*";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Yellow;
            this.label3.Location = new System.Drawing.Point(19, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(205, 24);
            this.label3.TabIndex = 0;
            this.label3.Text = "Lastname (Surname)";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Teal;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(326, 5);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(820, 61);
            this.panel2.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Teal;
            this.label2.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Chartreuse;
            this.label2.Location = new System.Drawing.Point(57, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(270, 43);
            this.label2.TabIndex = 3;
            this.label2.Text = "GIR BANK  - ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Teal;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.OldLace;
            this.label1.Location = new System.Drawing.Point(322, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(465, 43);
            this.label1.TabIndex = 2;
            this.label1.Text = "Employee Ragistration";
            // 
            // gunaButton1
            // 
            this.gunaButton1.AnimationHoverSpeed = 0.07F;
            this.gunaButton1.AnimationSpeed = 0.03F;
            this.gunaButton1.BaseColor = System.Drawing.Color.Transparent;
            this.gunaButton1.BorderColor = System.Drawing.Color.Black;
            this.gunaButton1.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.gunaButton1.ForeColor = System.Drawing.Color.Red;
            this.gunaButton1.Image = null;
            this.gunaButton1.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaButton1.Location = new System.Drawing.Point(1464, 12);
            this.gunaButton1.Name = "gunaButton1";
            this.gunaButton1.OnHoverBaseColor = System.Drawing.Color.Transparent;
            this.gunaButton1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaButton1.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaButton1.OnHoverImage = null;
            this.gunaButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaButton1.Size = new System.Drawing.Size(160, 42);
            this.gunaButton1.TabIndex = 2;
            this.gunaButton1.Text = "X";
            this.gunaButton1.Click += new System.EventHandler(this.gunaButton1_Click);
            // 
            // New_User_Ragistration_From
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(1455, 894);
            this.Controls.Add(this.gunaButton1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "New_User_Ragistration_From";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "New_User_Ragistration_From";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.New_User_Ragistration_From_Load);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox ComboContry;
        public System.Windows.Forms.TextBox txtMiddlename;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        public System.Windows.Forms.TextBox txtFirstname;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.TextBox txtLastname;
        public System.Windows.Forms.TextBox txtDateOfBirth;
        private System.Windows.Forms.Label label11;
        public System.Windows.Forms.TextBox txtPincode;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        public System.Windows.Forms.TextBox txtTawonCity;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        public System.Windows.Forms.TextBox txtTaluka;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        public System.Windows.Forms.TextBox txtDistric;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        public System.Windows.Forms.TextBox txtState;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        public System.Windows.Forms.TextBox txtMobileNumber;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox ComboGender;
        private System.Windows.Forms.Label label15;
        public System.Windows.Forms.TextBox txtEmailId;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        public System.Windows.Forms.TextBox GrajuationPercentage;
        private System.Windows.Forms.Label label32;
        public System.Windows.Forms.TextBox TwelvePercentage;
        private System.Windows.Forms.Label label31;
        public System.Windows.Forms.TextBox TenthPercentage;
        private System.Windows.Forms.Label label29;
        public System.Windows.Forms.TextBox AltenateMobileNumber;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label Captcha;
        public System.Windows.Forms.TextBox text_Captcha;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label38;
        private Guna.UI.WinForms.GunaButton gunaButton1;
    }
}