﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Bank_Management_System
{
    public partial class Gir_Bank_Atm : Form
    {
        int i = 0;
        public Gir_Bank_Atm()
        {
            InitializeComponent();
        }

        private void Gir_Bank_Atm_Load(object sender, EventArgs e)
        {
            Atm_Label.Visible = false;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            i++;
            if (i == 50) { Atm_Label.Visible = true; }
            if (i == 100) { this.Hide(); timer1.Stop(); Dashbord obj = new Dashbord(); obj.Show(); }
        }
    }
}
