﻿namespace Bank_Management_System
{
    partial class Block_And_Unblock_Ac
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.CheckAcBalance = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.AcHoldername = new System.Windows.Forms.Label();
            this.Lastname = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Reset_Panel = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.Block_Unblock_Panel = new System.Windows.Forms.Panel();
            this.Unlock_Button1 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.Block_Button1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.Captcha_Panel = new System.Windows.Forms.Panel();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.Captcha = new System.Windows.Forms.Label();
            this.text_Captcha = new System.Windows.Forms.TextBox();
            this.AcDetail_Panel = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Balance = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel2.SuspendLayout();
            this.Reset_Panel.SuspendLayout();
            this.Block_Unblock_Panel.SuspendLayout();
            this.Unlock_Button1.SuspendLayout();
            this.Block_Button1.SuspendLayout();
            this.Captcha_Panel.SuspendLayout();
            this.AcDetail_Panel.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkCyan;
            this.panel1.Controls.Add(this.label44);
            this.panel1.Controls.Add(this.label45);
            this.panel1.Location = new System.Drawing.Point(683, 167);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1260, 75);
            this.panel1.TabIndex = 16;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.DarkCyan;
            this.label44.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.Chartreuse;
            this.label44.Location = new System.Drawing.Point(75, 11);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(340, 56);
            this.label44.TabIndex = 3;
            this.label44.Text = "GIR BANK  - ";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.DarkCyan;
            this.label45.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.OldLace;
            this.label45.Location = new System.Drawing.Point(443, 11);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(707, 56);
            this.label45.TabIndex = 2;
            this.label45.Text = "Block And Unblock Account";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Teal;
            this.panel3.Controls.Add(this.CheckAcBalance);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(115, 66);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1955, 106);
            this.panel3.TabIndex = 17;
            // 
            // CheckAcBalance
            // 
            this.CheckAcBalance.BackColor = System.Drawing.Color.CadetBlue;
            this.CheckAcBalance.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CheckAcBalance.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckAcBalance.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.CheckAcBalance.Location = new System.Drawing.Point(849, 25);
            this.CheckAcBalance.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CheckAcBalance.MaxLength = 15;
            this.CheckAcBalance.Name = "CheckAcBalance";
            this.CheckAcBalance.Size = new System.Drawing.Size(680, 53);
            this.CheckAcBalance.TabIndex = 20;
            this.CheckAcBalance.TextChanged += new System.EventHandler(this.CheckAcBalance_TextChanged);
            this.CheckAcBalance.KeyDown += new System.Windows.Forms.KeyEventHandler(this.CheckAcBalance_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Teal;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.OldLace;
            this.label1.Location = new System.Drawing.Point(156, 22);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(626, 56);
            this.label1.TabIndex = 4;
            this.label1.Text = "Enter Account Number : ";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DarkCyan;
            this.panel6.Controls.Add(this.AcHoldername);
            this.panel6.Controls.Add(this.Lastname);
            this.panel6.Location = new System.Drawing.Point(464, 44);
            this.panel6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(496, 69);
            this.panel6.TabIndex = 27;
            // 
            // AcHoldername
            // 
            this.AcHoldername.AutoSize = true;
            this.AcHoldername.BackColor = System.Drawing.Color.DarkCyan;
            this.AcHoldername.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AcHoldername.ForeColor = System.Drawing.Color.White;
            this.AcHoldername.Location = new System.Drawing.Point(23, 17);
            this.AcHoldername.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.AcHoldername.Name = "AcHoldername";
            this.AcHoldername.Size = new System.Drawing.Size(31, 43);
            this.AcHoldername.TabIndex = 22;
            this.AcHoldername.Text = "-";
            // 
            // Lastname
            // 
            this.Lastname.AutoSize = true;
            this.Lastname.BackColor = System.Drawing.Color.DarkCyan;
            this.Lastname.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lastname.ForeColor = System.Drawing.Color.White;
            this.Lastname.Location = new System.Drawing.Point(225, 18);
            this.Lastname.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lastname.Name = "Lastname";
            this.Lastname.Size = new System.Drawing.Size(31, 43);
            this.Lastname.TabIndex = 25;
            this.Lastname.Text = "-";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Teal;
            this.label2.Font = new System.Drawing.Font("Century Schoolbook", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.OldLace;
            this.label2.Location = new System.Drawing.Point(47, 66);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(386, 35);
            this.label2.TabIndex = 26;
            this.label2.Text = "Account Holder Name : ";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkCyan;
            this.panel2.Controls.Add(this.Reset_Panel);
            this.panel2.Controls.Add(this.Block_Unblock_Panel);
            this.panel2.Controls.Add(this.Captcha_Panel);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.AcDetail_Panel);
            this.panel2.Location = new System.Drawing.Point(249, 289);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(2165, 757);
            this.panel2.TabIndex = 21;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // Reset_Panel
            // 
            this.Reset_Panel.BackColor = System.Drawing.Color.Teal;
            this.Reset_Panel.Controls.Add(this.label4);
            this.Reset_Panel.Location = new System.Drawing.Point(812, 650);
            this.Reset_Panel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Reset_Panel.Name = "Reset_Panel";
            this.Reset_Panel.Size = new System.Drawing.Size(412, 85);
            this.Reset_Panel.TabIndex = 48;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(39, 27);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(314, 43);
            this.label4.TabIndex = 22;
            this.label4.Text = "Logout - (Ctrl+R)";
            // 
            // Block_Unblock_Panel
            // 
            this.Block_Unblock_Panel.BackColor = System.Drawing.Color.Teal;
            this.Block_Unblock_Panel.Controls.Add(this.Unlock_Button1);
            this.Block_Unblock_Panel.Controls.Add(this.Block_Button1);
            this.Block_Unblock_Panel.Location = new System.Drawing.Point(733, 482);
            this.Block_Unblock_Panel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Block_Unblock_Panel.Name = "Block_Unblock_Panel";
            this.Block_Unblock_Panel.Size = new System.Drawing.Size(1336, 134);
            this.Block_Unblock_Panel.TabIndex = 47;
            // 
            // Unlock_Button1
            // 
            this.Unlock_Button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Unlock_Button1.Controls.Add(this.label6);
            this.Unlock_Button1.Location = new System.Drawing.Point(731, 22);
            this.Unlock_Button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Unlock_Button1.Name = "Unlock_Button1";
            this.Unlock_Button1.Size = new System.Drawing.Size(568, 85);
            this.Unlock_Button1.TabIndex = 50;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Yellow;
            this.label6.Location = new System.Drawing.Point(116, 21);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(339, 43);
            this.label6.TabIndex = 22;
            this.label6.Text = "Unblock - (Ctrl+U)";
            // 
            // Block_Button1
            // 
            this.Block_Button1.BackColor = System.Drawing.Color.Red;
            this.Block_Button1.Controls.Add(this.label5);
            this.Block_Button1.Location = new System.Drawing.Point(79, 22);
            this.Block_Button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Block_Button1.Name = "Block_Button1";
            this.Block_Button1.Size = new System.Drawing.Size(580, 85);
            this.Block_Button1.TabIndex = 49;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Red;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Yellow;
            this.label5.Location = new System.Drawing.Point(125, 25);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(292, 43);
            this.label5.TabIndex = 22;
            this.label5.Text = "Block - (Ctrl+B)";
            // 
            // Captcha_Panel
            // 
            this.Captcha_Panel.BackColor = System.Drawing.Color.Teal;
            this.Captcha_Panel.Controls.Add(this.label39);
            this.Captcha_Panel.Controls.Add(this.label40);
            this.Captcha_Panel.Controls.Add(this.Captcha);
            this.Captcha_Panel.Controls.Add(this.text_Captcha);
            this.Captcha_Panel.Location = new System.Drawing.Point(115, 482);
            this.Captcha_Panel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Captcha_Panel.Name = "Captcha_Panel";
            this.Captcha_Panel.Size = new System.Drawing.Size(579, 134);
            this.Captcha_Panel.TabIndex = 22;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Calisto MT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.Yellow;
            this.label39.Location = new System.Drawing.Point(359, 22);
            this.label39.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(125, 22);
            this.label39.TabIndex = 46;
            this.label39.Text = "Captcha Code";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Calisto MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.Color.Yellow;
            this.label40.Location = new System.Drawing.Point(48, 20);
            this.label40.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(97, 28);
            this.label40.TabIndex = 43;
            this.label40.Text = "Captcha";
            // 
            // Captcha
            // 
            this.Captcha.AutoSize = true;
            this.Captcha.BackColor = System.Drawing.Color.LightSkyBlue;
            this.Captcha.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Captcha.Font = new System.Drawing.Font("Buxton Sketch", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Captcha.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.Captcha.Location = new System.Drawing.Point(363, 43);
            this.Captcha.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Captcha.Name = "Captcha";
            this.Captcha.Size = new System.Drawing.Size(148, 56);
            this.Captcha.TabIndex = 44;
            this.Captcha.Text = "Captcha";
            // 
            // text_Captcha
            // 
            this.text_Captcha.BackColor = System.Drawing.Color.CadetBlue;
            this.text_Captcha.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.text_Captcha.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_Captcha.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.text_Captcha.Location = new System.Drawing.Point(53, 50);
            this.text_Captcha.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.text_Captcha.Name = "text_Captcha";
            this.text_Captcha.Size = new System.Drawing.Size(232, 49);
            this.text_Captcha.TabIndex = 45;
            this.text_Captcha.KeyDown += new System.Windows.Forms.KeyEventHandler(this.text_Captcha_KeyDown);
            // 
            // AcDetail_Panel
            // 
            this.AcDetail_Panel.BackColor = System.Drawing.Color.Teal;
            this.AcDetail_Panel.Controls.Add(this.label2);
            this.AcDetail_Panel.Controls.Add(this.label3);
            this.AcDetail_Panel.Controls.Add(this.panel4);
            this.AcDetail_Panel.Controls.Add(this.panel6);
            this.AcDetail_Panel.Location = new System.Drawing.Point(115, 239);
            this.AcDetail_Panel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AcDetail_Panel.Name = "AcDetail_Panel";
            this.AcDetail_Panel.Size = new System.Drawing.Size(1955, 161);
            this.AcDetail_Panel.TabIndex = 21;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Teal;
            this.label3.Font = new System.Drawing.Font("Century Schoolbook", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.OldLace;
            this.label3.Location = new System.Drawing.Point(1245, 55);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(289, 35);
            this.label3.TabIndex = 28;
            this.label3.Text = "Account Status  : ";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkCyan;
            this.panel4.Controls.Add(this.Balance);
            this.panel4.Location = new System.Drawing.Point(1591, 44);
            this.panel4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(327, 69);
            this.panel4.TabIndex = 28;
            // 
            // Balance
            // 
            this.Balance.AutoSize = true;
            this.Balance.BackColor = System.Drawing.Color.DarkCyan;
            this.Balance.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Balance.ForeColor = System.Drawing.Color.White;
            this.Balance.Location = new System.Drawing.Point(29, 11);
            this.Balance.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Balance.Name = "Balance";
            this.Balance.Size = new System.Drawing.Size(31, 43);
            this.Balance.TabIndex = 22;
            this.Balance.Text = "-";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkCyan;
            this.panel5.Controls.Add(this.label7);
            this.panel5.Location = new System.Drawing.Point(2052, 167);
            this.panel5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(363, 75);
            this.panel5.TabIndex = 49;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(41, 21);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(270, 43);
            this.label7.TabIndex = 22;
            this.label7.Text = "Exit - (Ctrl + X)";
            // 
            // Block_And_Unblock_Ac
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(1942, 1102);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Block_And_Unblock_Ac";
            this.Text = "Block_And_Unblock_Ac";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Block_And_Unblock_Ac_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.Reset_Panel.ResumeLayout(false);
            this.Reset_Panel.PerformLayout();
            this.Block_Unblock_Panel.ResumeLayout(false);
            this.Unlock_Button1.ResumeLayout(false);
            this.Unlock_Button1.PerformLayout();
            this.Block_Button1.ResumeLayout(false);
            this.Block_Button1.PerformLayout();
            this.Captcha_Panel.ResumeLayout(false);
            this.Captcha_Panel.PerformLayout();
            this.AcDetail_Panel.ResumeLayout(false);
            this.AcDetail_Panel.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Panel panel3;
        public System.Windows.Forms.TextBox CheckAcBalance;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label Lastname;
        private System.Windows.Forms.Label AcHoldername;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel AcDetail_Panel;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label Balance;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel Captcha_Panel;
        private System.Windows.Forms.Panel Block_Unblock_Panel;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label Captcha;
        public System.Windows.Forms.TextBox text_Captcha;
        private System.Windows.Forms.Panel Reset_Panel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel Block_Button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel Unlock_Button1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label7;
    }
}