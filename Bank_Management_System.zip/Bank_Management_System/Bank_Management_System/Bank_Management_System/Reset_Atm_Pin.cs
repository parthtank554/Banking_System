﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Bank_Management_System
{
    public partial class Reset_Atm_Pin : Form
    {
        SqlCommand cmd, cmd2, cmd3;
        SqlConnection con;
        SqlDataAdapter oda;
        DataTable dt;
        string pinnum = "";
        int t = 0, i = 0, a = 0;

        public Reset_Atm_Pin()
        {
            InitializeComponent();
        }

        private void Reset_Atm_Pin_Load(object sender, EventArgs e)
        {
            timer1.Start();
            wait_lbl.Visible = false;
            Set_New_Pin_Panel.Enabled = false;
            Last_Trasaction.Visible = false;
            Gir_lbl_panel.Visible = false;
            Cancel_Panel.Visible = false;
            Main_Pin_Panel.Visible = false;
            Set_New_Pin_Panel.Visible = false;
            Pin_Number.Focus();
        }

        private void Pin_Number_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt32(Pin_Number.Text.Length) == 4)
            {
                Pin_Number.Enabled = false;
                con = new SqlConnection(Con_Class.cnn);
                con.Open();

                cmd = new SqlCommand("select * from Debit_Card_Apply where Pin='" + Pin_Number.Text + "'", con);
                oda = new SqlDataAdapter(cmd);
                dt = new DataTable();
                oda.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    pinnum = dr["Pin"].ToString();
                    t = 1;
                }
                if (t == 0)
                {
                    MessageBox.Show("Pin Number Not Found.....", "Invalid");
                    this.Close();
                    Dashbord obj = new Dashbord();
                    obj.Show();

                }
                else
                {
                    Set_New_Pin_Panel.Enabled = true;
                    New_Pin_Text_Box.Focus();
                }

            }
        }

        private void Confirm_Pin_Text_Box_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt32(Confirm_Pin_Text_Box.Text.Length) == 4)
            {
                if (New_Pin_Text_Box.Text == Confirm_Pin_Text_Box.Text)
                {
                    con = new SqlConnection(Con_Class.cnn);
                    con.Open();

                    cmd2 = new SqlCommand("update Debit_Card_Apply set Pin='" + Confirm_Pin_Text_Box.Text + "' where Pin='" + Pin_Number.Text + "'", con);
                    int res = cmd2.ExecuteNonQuery();
                    if (res > 0)
                    {
                        MessageBox.Show("New Pin Updated Sucessfully.....", "Suceess !");
                        this.Close();
                        Dashbord obj = new Dashbord();
                        obj.Show();
                    }
                    else
                    {
                        MessageBox.Show("Error");
                    }

                }
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            a++;
            if (a == 40)
            {
                this.Close();
                Dashbord obj = new Dashbord();
                obj.Show();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            i++;
            if (i == 50)
            {
                timer1.Stop();
                wait_lbl.Visible = false;
                Set_New_Pin_Panel.Enabled = true;
                Gir_lbl_panel.Visible = true;
                Cancel_Panel.Visible = true;
                Main_Pin_Panel.Visible = true;
                Set_New_Pin_Panel.Visible = true;
                Pin_Number.Focus();
            }
            if (i == 10)
            {
                wait_lbl.Visible = true;
            }
        }

        private void Confirm_Pin_Text_Box_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                timer2.Start();
                wait_lbl.Visible = false;
                Set_New_Pin_Panel.Enabled = false;
                Last_Trasaction.Visible = true;
                Gir_lbl_panel.Visible = false;
                Cancel_Panel.Visible = false;
                Main_Pin_Panel.Visible = false;
                Set_New_Pin_Panel.Visible = false;
            }
        }
    }
}
