﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Bank_Management_System
{
    public partial class Reset_Password_From : Form
    {
        SqlConnection con;
        SqlCommand cmd, cmd2;
        SqlDataAdapter oda;
        DataTable dt;
        string pass = "";
        public Reset_Password_From()
        {
            InitializeComponent();
        }
        public void getpass()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();

            cmd = new SqlCommand("select ps from Employee_Ragistration where ps='" + Random_Number.Text + "'", con);
            oda = new SqlDataAdapter(cmd);
            dt = new DataTable();
            oda.Fill(dt);

            foreach (DataRow dr in dt.Rows)
            {
                pass = dr["ps"].ToString();
            }

        }
        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                DialogResult di = MessageBox.Show("Are Sure Logout....", "Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (di == DialogResult.Yes)
                {
                    Reset_Panel.Enabled = false;
                    Submit_Panel.Enabled = false;
                    Exit_Panel.Enabled = false;
                    txtNewPassword.Clear();
                    txtConfirmPassword.Clear();
                    NewPasswordPanel.Enabled = false;
                }

            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                MessageBox.Show("Logout First....", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

        }

        private void txtConfirmPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.S)
            {
                getpass();
                con = new SqlConnection(Con_Class.cnn);
                con.Open();
                if (txtNewPassword.Text == "")
                {
                    MessageBox.Show("Enter New Password..", "Blank Record", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    if (txtConfirmPassword.Text == "")
                    {
                        MessageBox.Show("Enter New Password..", "Blank Record", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    else
                    {
                        if (txtNewPassword.Text != txtConfirmPassword.Text)
                        {
                            MessageBox.Show("Both Password Does Not Match Please Try Again...", "Not Match", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            txtConfirmPassword.Clear();
                            txtNewPassword.Clear();
                            txtNewPassword.Focus();
                        }
                        else
                        {
                            cmd2 = new SqlCommand("update Employee_Ragistration set ps='" + txtConfirmPassword.Text + "' where ps='" + Random_Number.Text + "'", con);
                            int res = cmd2.ExecuteNonQuery();
                            if (res > 0)
                            {
                                MessageBox.Show("Password Changed Successfully....", "Success..!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                this.Close();
                                Form1 obj = new Form1();
                                obj.Show();
                            }
                            else
                            {
                                MessageBox.Show("505 http Error");
                            }
                        }
                    }
                }
            }

        }
    }
}
 