﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Bank_Management_System
{
    public partial class Block_And_Unblock_Ac : Form
    {
        SqlConnection con;
        SqlCommand cmd, comm,blockins,blockdelete;
        SqlDataAdapter da;
        DataSet ds = new DataSet();
        string BlockList = "";

        public Block_And_Unblock_Ac()
        {
            InitializeComponent();
        }
        private void Block_And_Unblock_Ac_Load(object sender, EventArgs e)
        {
            Random rand = new Random();
            int num = rand.Next(6, 8);
            int total = 0;
            string captcha = "";

            do
            {
                int chr = rand.Next(100, 123);
                if ((chr >= 48 && chr <= 57) || (chr >= 65 && chr <= 90) || (chr >= 97 && chr <= 122))
                {
                    captcha = captcha + (char)chr;
                    total++;
                    if (total == num)
                        break;
                    {

                    }
                }
            } while (true);
            Captcha.Text = captcha;

            AcDetail_Panel.Enabled = false;
            Reset_Panel.Visible = false;
            Captcha_Panel.Enabled = false;
            Block_Unblock_Panel.Enabled = false;
        }

        private void Reset_Button_Click(object sender, EventArgs e)
        {
            
        }
        public void Block_List()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();
            string qry = "select * from Blocke_Ac where BalockAcNumber='" + CheckAcBalance.Text + "'";
            comm = new SqlCommand(qry, con);
            DataTable dt = new DataTable();
            SqlDataAdapter oda = new SqlDataAdapter(comm);
            oda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                BlockList = dr["BalockAcNumber"].ToString();
               
            }
            Balance.Text = "Activated";

        }
        private void Cancel_Button_Click(object sender, EventArgs e)
        {
            this.Close();
            Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
            obj.Show();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void CheckAcBalance_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt16(CheckAcBalance.Text.Length) == 15)
            {

                CheckAcBalance.Enabled = false;
                AcDetail_Panel.Enabled = true;
                Captcha_Panel.Enabled = true;
                Block_Unblock_Panel.Enabled = true;
                con = new SqlConnection(Con_Class.cnn);
                con.Open();
                string qry = "select * from Customer_Table where AcNumber='" + CheckAcBalance.Text + "'";
                cmd = new SqlCommand(qry, con);
                DataTable dt = new DataTable();
                SqlDataAdapter oda = new SqlDataAdapter(cmd);
                oda.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {

                    AcHoldername.Text = dr["Firstname"].ToString();
                    Lastname.Text = dr["Lastname"].ToString();
                }
                Block_List();
                
                text_Captcha.Focus();
                Reset_Panel.Visible = true;
                
                if (BlockList == CheckAcBalance.Text)
                {
                    Balance.Text = "DeActivated";
                    Block_Button1.Enabled = false;
                    Unlock_Button1.Enabled = true;
                    Reset_Panel.Visible = true;
                    
                }
                else
                {
                    Block_Button1.Enabled = true;
                    Unlock_Button1.Enabled = false;
                    Reset_Panel.Visible = true;
                }

                if (AcHoldername.Text == "-")
                {
                    AcDetail_Panel.Enabled = false;
                    Captcha_Panel.Enabled = false;
                    MessageBox.Show("Account Not Found !", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    AcDetail_Panel.Enabled = false;
                    Captcha_Panel.Enabled = false;
                    Block_Unblock_Panel.Enabled = false;
                    CheckAcBalance.Enabled = true;
                    CheckAcBalance.Clear();
                    CheckAcBalance.Focus();
                    this.OnLoad(e);
                    CheckAcBalance.Enabled = false;
                    AcDetail_Panel.Enabled = true;
                    Block_Unblock_Panel.Enabled = true;
                    CheckAcBalance.Enabled = true;
                    CheckAcBalance.Clear();
                    CheckAcBalance.Focus();
                    Captcha_Panel.Enabled = false;
                    Block_Unblock_Panel.Enabled = false;
                    Balance.Text = "-";
                    Reset_Panel.Visible = false;
                    Captcha_Panel.Enabled = true;
                }
            }

        }

        private void CheckAcBalance_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {

                this.Close();
                Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
                obj.Show();
            }
        }

        private void text_Captcha_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                if (AcHoldername.Text != "-")
                {
                    MessageBox.Show("Please Logout First !", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    this.Close();
                    Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
                    obj.Show();
                }
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                
                CheckAcBalance.Enabled = true;
                CheckAcBalance.Clear();
                CheckAcBalance.Focus();
                AcHoldername.Text = "-";
                Lastname.Text = "-";
                Balance.Text = "-";
                AcDetail_Panel.Enabled = false;
                Captcha_Panel.Enabled = false;
                Block_Unblock_Panel.Enabled = false;
                Reset_Panel.Visible = false;
                
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.B)
            {
                if (text_Captcha.Text == "")
                {
                    MessageBox.Show("Please Enter Captcha Code !", "Captcha ?", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.OnLoad(e);
                    text_Captcha.Clear();
                    text_Captcha.Focus();
                    CheckAcBalance.Enabled = false;
                    AcDetail_Panel.Enabled = true;
                    Block_Unblock_Panel.Enabled = true;
                    Captcha_Panel.Enabled = true;
                    Reset_Panel.Visible = true;
                    text_Captcha.Focus();
                }

                else
                {
                    if (text_Captcha.Text != Captcha.Text)
                    {
                        MessageBox.Show("Incorrect Captcha Code", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        this.OnLoad(e);
                        text_Captcha.Clear();
                        text_Captcha.Focus();
                        CheckAcBalance.Enabled = false;
                        AcDetail_Panel.Enabled = true;
                        Block_Unblock_Panel.Enabled = true;
                        Reset_Panel.Visible = true;
                        Captcha_Panel.Enabled = true;
                        text_Captcha.Focus();

                    }
                    else
                    {
                        con = new SqlConnection(Con_Class.cnn);
                        con.Open();
                        blockins = new SqlCommand("insert into Blocke_Ac(BalockAcNumber) values('" + CheckAcBalance.Text + "')", con);
                        int res = blockins.ExecuteNonQuery();
                        if (res > 0)
                        {
                            if (Unlock_Button1.Enabled == true)
                            {

                                MessageBox.Show("Account Is Alredy DeActivated", "DeActivated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                this.OnLoad(e);
                                text_Captcha.Clear();
                                text_Captcha.Focus();
                                CheckAcBalance.Enabled = false;
                                AcDetail_Panel.Enabled = true;
                                Block_Unblock_Panel.Enabled = true;
                                Reset_Panel.Visible = true;
                                Captcha_Panel.Enabled = true;
                                text_Captcha.Focus();

                            }
                            else
                            {
                                MessageBox.Show("Account Is  DeActivated", "DeActivated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                Block_Button1.Enabled = false;
                                Unlock_Button1.Enabled = true;
                                Balance.Text = "DeActivated";
                                this.OnLoad(e);
                                text_Captcha.Clear();
                                text_Captcha.Focus();
                                CheckAcBalance.Enabled = false;
                                AcDetail_Panel.Enabled = true;
                                Block_Unblock_Panel.Enabled = true;
                                Reset_Panel.Visible = true;
                                Captcha_Panel.Enabled = true;
                                text_Captcha.Focus();
                            }
                        }
                        else
                        {
                            MessageBox.Show("404 Error", "404", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }

                    }
                }
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.U)
            {
                if (text_Captcha.Text == "")
                {
                    MessageBox.Show("Please Enter Captcha Code !", "Captcha ?", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.OnLoad(e);
                    text_Captcha.Clear();
                    text_Captcha.Focus();
                    CheckAcBalance.Enabled = false;
                    AcDetail_Panel.Enabled = true;
                    Block_Unblock_Panel.Enabled = true;
                    Captcha_Panel.Enabled = true;
                    Reset_Panel.Visible = true;
                    text_Captcha.Focus();
                }
                else
                {
                    if (text_Captcha.Text != Captcha.Text)
                    {
                        MessageBox.Show("Incorrect Captcha Code", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        this.OnLoad(e);
                        text_Captcha.Clear();
                        text_Captcha.Focus();
                        CheckAcBalance.Enabled = false;
                        AcDetail_Panel.Enabled = true;
                        Block_Unblock_Panel.Enabled = true;
                        Captcha_Panel.Enabled = true;
                        Reset_Panel.Visible = true;
                        text_Captcha.Focus();

                    }
                    else
                    {
                        con = new SqlConnection(Con_Class.cnn);
                        con.Open();
                        blockdelete = new SqlCommand("delete from Blocke_Ac where BalockAcNumber='" + CheckAcBalance.Text + "'", con);
                        int res = blockdelete.ExecuteNonQuery();
                        if (res > 0)
                        {
                            
                                MessageBox.Show("Account Is Activated", "Activated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                Block_Button1.Enabled = true;
                                Unlock_Button1.Enabled = false;
                                Balance.Text = "Activated";
                                this.OnLoad(e);
                                text_Captcha.Clear();
                                text_Captcha.Focus();
                                CheckAcBalance.Enabled = false;
                                AcDetail_Panel.Enabled = true;
                                Block_Unblock_Panel.Enabled = true;
                                Captcha_Panel.Enabled = true;
                                Reset_Panel.Visible = true;
                                text_Captcha.Focus();
                         }
                        
                        else
                        {
                             MessageBox.Show("Account Is Alredy Activated", "Activated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                             this.OnLoad(e);
                             text_Captcha.Clear();
                             text_Captcha.Focus();
                             CheckAcBalance.Enabled = false;
                             AcDetail_Panel.Enabled = true;
                             Block_Unblock_Panel.Enabled = true;
                             Captcha_Panel.Enabled = true;
                             Reset_Panel.Visible = true;
                             text_Captcha.Focus();
                        }
                    }
                }
            }
        }
    }
}

