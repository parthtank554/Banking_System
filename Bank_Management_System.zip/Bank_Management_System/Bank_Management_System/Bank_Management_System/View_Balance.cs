﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Globalization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Bank_Management_System
{
    public partial class View_Balance : Form
    {
        SqlCommand cmd,cmd2;
        SqlConnection con;
        SqlDataAdapter oda,oda2;
        DataTable dt,dt2;
        string bal="",Acnum="";
        int i = 0;

        public View_Balance()
        {
            InitializeComponent();
        }
        public void getAcNumber()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();
            cmd = new SqlCommand("select * from Debit_Card_Apply where DebitNumber='" + AcNumber.Text + "'", con);
            oda = new SqlDataAdapter(cmd);
            dt = new DataTable();
            oda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                Acnum = dr["AcNumber"].ToString();
            }
        }
        private void View_Balance_Load(object sender, EventArgs e)
        {
            T_Complete.Visible = false;
            Balance_Panel.Visible = false;
            getAcNumber();
            con = new SqlConnection(Con_Class.cnn);
            con.Open();

            cmd2 = new SqlCommand("select * from Customer_Table where AcNumber='" + Acnum + "'", con);
            oda2 = new SqlDataAdapter(cmd2);
            dt2 = new DataTable();
            oda2.Fill(dt2);
            foreach (DataRow dr in dt2.Rows)
            {
                bal = dr["AcBalance"].ToString();
                bal = string.Format(CultureInfo.CreateSpecificCulture("hi-IN"), "{0:C}", double.Parse(bal));
                timer1.Start();
            }
            Balance.Text = bal;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            i++;
            if (i == 70) { Pleasewaitlbl.Visible = false; Balance_Panel.Visible = true; }
            if (i == 130) { Balance_Panel.Visible = false; Pleasewaitlbl.Visible = false; Check_Panel.Visible = false; T_Complete.Visible = true; }
            if (i == 150) { timer1.Stop(); i = 0; this.Close(); Dashbord obj = new Dashbord(); obj.Show(); }
        }
    }
}
