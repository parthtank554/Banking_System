﻿namespace Bank_Management_System
{
    partial class View_Account_Details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.AcDetailPanel = new System.Windows.Forms.Panel();
            this.AccountDetailPanel = new System.Windows.Forms.Panel();
            this.Balance = new System.Windows.Forms.Label();
            this.Occupation = new System.Windows.Forms.Label();
            this.AddharNumber = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.Pancard = new System.Windows.Forms.Label();
            this.AcNum = new System.Windows.Forms.Label();
            this.AcType = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.Pincode = new System.Windows.Forms.Label();
            this.CityTown = new System.Windows.Forms.Label();
            this.Taluka = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.Distric = new System.Windows.Forms.Label();
            this.State = new System.Windows.Forms.Label();
            this.Contry = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.Statedscsc = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.Qulification = new System.Windows.Forms.Label();
            this.AlternateNumber = new System.Windows.Forms.Label();
            this.Email = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.MobileNumber = new System.Windows.Forms.Label();
            this.Gender = new System.Windows.Forms.Label();
            this.DateOfBirth = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.xccd = new System.Windows.Forms.Label();
            this.lastname = new System.Windows.Forms.Label();
            this.Middlename = new System.Windows.Forms.Label();
            this.lblfirstname = new System.Windows.Forms.Label();
            this.fddcs = new System.Windows.Forms.Label();
            this.dcd = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.CheckAcBalance = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Logout_Panel = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.Temper = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.AcDetailPanel.SuspendLayout();
            this.AccountDetailPanel.SuspendLayout();
            this.panel3.SuspendLayout();
            this.Logout_Panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.label44);
            this.panel1.Controls.Add(this.label45);
            this.panel1.Location = new System.Drawing.Point(499, 21);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(948, 61);
            this.panel1.TabIndex = 14;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.Teal;
            this.label44.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.Chartreuse;
            this.label44.Location = new System.Drawing.Point(122, 9);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(270, 43);
            this.label44.TabIndex = 3;
            this.label44.Text = "GIR BANK  - ";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Teal;
            this.label45.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.OldLace;
            this.label45.Location = new System.Drawing.Point(398, 9);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(382, 43);
            this.label45.TabIndex = 2;
            this.label45.Text = "Fetch Acount Data";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Teal;
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.AcDetailPanel);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(55, 88);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1833, 902);
            this.panel2.TabIndex = 15;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkCyan;
            this.panel4.Controls.Add(this.label3);
            this.panel4.Location = new System.Drawing.Point(1475, 33);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(272, 83);
            this.panel4.TabIndex = 54;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(31, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(212, 33);
            this.label3.TabIndex = 22;
            this.label3.Text = "Exit - (Ctrl + X)";
            // 
            // AcDetailPanel
            // 
            this.AcDetailPanel.BackColor = System.Drawing.Color.DarkCyan;
            this.AcDetailPanel.Controls.Add(this.AccountDetailPanel);
            this.AcDetailPanel.Location = new System.Drawing.Point(39, 144);
            this.AcDetailPanel.Name = "AcDetailPanel";
            this.AcDetailPanel.Size = new System.Drawing.Size(1765, 726);
            this.AcDetailPanel.TabIndex = 16;
            // 
            // AccountDetailPanel
            // 
            this.AccountDetailPanel.BackColor = System.Drawing.Color.White;
            this.AccountDetailPanel.Controls.Add(this.Balance);
            this.AccountDetailPanel.Controls.Add(this.Occupation);
            this.AccountDetailPanel.Controls.Add(this.AddharNumber);
            this.AccountDetailPanel.Controls.Add(this.label6);
            this.AccountDetailPanel.Controls.Add(this.label7);
            this.AccountDetailPanel.Controls.Add(this.label9);
            this.AccountDetailPanel.Controls.Add(this.Pancard);
            this.AccountDetailPanel.Controls.Add(this.AcNum);
            this.AccountDetailPanel.Controls.Add(this.AcType);
            this.AccountDetailPanel.Controls.Add(this.label35);
            this.AccountDetailPanel.Controls.Add(this.label36);
            this.AccountDetailPanel.Controls.Add(this.label37);
            this.AccountDetailPanel.Controls.Add(this.Pincode);
            this.AccountDetailPanel.Controls.Add(this.CityTown);
            this.AccountDetailPanel.Controls.Add(this.Taluka);
            this.AccountDetailPanel.Controls.Add(this.label29);
            this.AccountDetailPanel.Controls.Add(this.label30);
            this.AccountDetailPanel.Controls.Add(this.label31);
            this.AccountDetailPanel.Controls.Add(this.Distric);
            this.AccountDetailPanel.Controls.Add(this.State);
            this.AccountDetailPanel.Controls.Add(this.Contry);
            this.AccountDetailPanel.Controls.Add(this.label23);
            this.AccountDetailPanel.Controls.Add(this.Statedscsc);
            this.AccountDetailPanel.Controls.Add(this.label25);
            this.AccountDetailPanel.Controls.Add(this.Qulification);
            this.AccountDetailPanel.Controls.Add(this.AlternateNumber);
            this.AccountDetailPanel.Controls.Add(this.Email);
            this.AccountDetailPanel.Controls.Add(this.label17);
            this.AccountDetailPanel.Controls.Add(this.label18);
            this.AccountDetailPanel.Controls.Add(this.label19);
            this.AccountDetailPanel.Controls.Add(this.MobileNumber);
            this.AccountDetailPanel.Controls.Add(this.Gender);
            this.AccountDetailPanel.Controls.Add(this.DateOfBirth);
            this.AccountDetailPanel.Controls.Add(this.label11);
            this.AccountDetailPanel.Controls.Add(this.label12);
            this.AccountDetailPanel.Controls.Add(this.xccd);
            this.AccountDetailPanel.Controls.Add(this.lastname);
            this.AccountDetailPanel.Controls.Add(this.Middlename);
            this.AccountDetailPanel.Controls.Add(this.lblfirstname);
            this.AccountDetailPanel.Controls.Add(this.fddcs);
            this.AccountDetailPanel.Controls.Add(this.dcd);
            this.AccountDetailPanel.Controls.Add(this.label2);
            this.AccountDetailPanel.Location = new System.Drawing.Point(49, 20);
            this.AccountDetailPanel.Name = "AccountDetailPanel";
            this.AccountDetailPanel.Size = new System.Drawing.Size(1690, 681);
            this.AccountDetailPanel.TabIndex = 24;
            // 
            // Balance
            // 
            this.Balance.AutoSize = true;
            this.Balance.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Balance.Location = new System.Drawing.Point(1493, 617);
            this.Balance.Name = "Balance";
            this.Balance.Size = new System.Drawing.Size(17, 24);
            this.Balance.TabIndex = 41;
            this.Balance.Text = "-";
            // 
            // Occupation
            // 
            this.Occupation.AutoSize = true;
            this.Occupation.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Occupation.Location = new System.Drawing.Point(840, 617);
            this.Occupation.Name = "Occupation";
            this.Occupation.Size = new System.Drawing.Size(17, 24);
            this.Occupation.TabIndex = 40;
            this.Occupation.Text = "-";
            // 
            // AddharNumber
            // 
            this.AddharNumber.AutoSize = true;
            this.AddharNumber.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddharNumber.Location = new System.Drawing.Point(227, 617);
            this.AddharNumber.Name = "AddharNumber";
            this.AddharNumber.Size = new System.Drawing.Size(17, 24);
            this.AddharNumber.TabIndex = 39;
            this.AddharNumber.Text = "-";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(1293, 617);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(194, 24);
            this.label6.TabIndex = 38;
            this.label6.Text = "Account Balance :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(694, 617);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(140, 24);
            this.label7.TabIndex = 37;
            this.label7.Text = "Occupation :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(37, 617);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(184, 24);
            this.label9.TabIndex = 36;
            this.label9.Text = "Addhar Number :";
            // 
            // Pancard
            // 
            this.Pancard.AutoSize = true;
            this.Pancard.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pancard.Location = new System.Drawing.Point(1406, 519);
            this.Pancard.Name = "Pancard";
            this.Pancard.Size = new System.Drawing.Size(17, 24);
            this.Pancard.TabIndex = 35;
            this.Pancard.Text = "-";
            // 
            // AcNum
            // 
            this.AcNum.AutoSize = true;
            this.AcNum.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AcNum.Location = new System.Drawing.Point(894, 519);
            this.AcNum.Name = "AcNum";
            this.AcNum.Size = new System.Drawing.Size(17, 24);
            this.AcNum.TabIndex = 34;
            this.AcNum.Text = "-";
            // 
            // AcType
            // 
            this.AcType.AutoSize = true;
            this.AcType.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AcType.Location = new System.Drawing.Point(204, 519);
            this.AcType.Name = "AcType";
            this.AcType.Size = new System.Drawing.Size(17, 24);
            this.AcType.TabIndex = 33;
            this.AcType.Text = "-";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(1293, 519);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(107, 24);
            this.label35.TabIndex = 32;
            this.label35.Text = "Pancard :";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(694, 519);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(194, 24);
            this.label36.TabIndex = 31;
            this.label36.Text = "Account Number :";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(37, 519);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(161, 24);
            this.label37.TabIndex = 30;
            this.label37.Text = "Account Type :";
            // 
            // Pincode
            // 
            this.Pincode.AutoSize = true;
            this.Pincode.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pincode.Location = new System.Drawing.Point(1404, 434);
            this.Pincode.Name = "Pincode";
            this.Pincode.Size = new System.Drawing.Size(17, 24);
            this.Pincode.TabIndex = 29;
            this.Pincode.Text = "-";
            // 
            // CityTown
            // 
            this.CityTown.AutoSize = true;
            this.CityTown.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CityTown.Location = new System.Drawing.Point(830, 434);
            this.CityTown.Name = "CityTown";
            this.CityTown.Size = new System.Drawing.Size(17, 24);
            this.CityTown.TabIndex = 28;
            this.CityTown.Text = "-";
            // 
            // Taluka
            // 
            this.Taluka.AutoSize = true;
            this.Taluka.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Taluka.Location = new System.Drawing.Point(155, 434);
            this.Taluka.Name = "Taluka";
            this.Taluka.Size = new System.Drawing.Size(17, 24);
            this.Taluka.TabIndex = 27;
            this.Taluka.Text = "-";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(1293, 434);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(105, 24);
            this.label29.TabIndex = 26;
            this.label29.Text = "Pincode :";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(694, 434);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(124, 24);
            this.label30.TabIndex = 25;
            this.label30.Text = "City/Town :";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(37, 434);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(95, 24);
            this.label31.TabIndex = 24;
            this.label31.Text = "Taluka  :";
            // 
            // Distric
            // 
            this.Distric.AutoSize = true;
            this.Distric.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Distric.Location = new System.Drawing.Point(1400, 338);
            this.Distric.Name = "Distric";
            this.Distric.Size = new System.Drawing.Size(17, 24);
            this.Distric.TabIndex = 23;
            this.Distric.Text = "-";
            // 
            // State
            // 
            this.State.AutoSize = true;
            this.State.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.State.Location = new System.Drawing.Point(775, 338);
            this.State.Name = "State";
            this.State.Size = new System.Drawing.Size(17, 24);
            this.State.TabIndex = 22;
            this.State.Text = "-";
            // 
            // Contry
            // 
            this.Contry.AutoSize = true;
            this.Contry.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Contry.Location = new System.Drawing.Point(136, 338);
            this.Contry.Name = "Contry";
            this.Contry.Size = new System.Drawing.Size(17, 24);
            this.Contry.TabIndex = 21;
            this.Contry.Text = "-";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(1293, 338);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(94, 24);
            this.label23.TabIndex = 20;
            this.label23.Text = "Distric  :";
            // 
            // Statedscsc
            // 
            this.Statedscsc.AutoSize = true;
            this.Statedscsc.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Statedscsc.Location = new System.Drawing.Point(694, 338);
            this.Statedscsc.Name = "Statedscsc";
            this.Statedscsc.Size = new System.Drawing.Size(74, 24);
            this.Statedscsc.TabIndex = 19;
            this.Statedscsc.Text = "State :";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(37, 338);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(91, 24);
            this.label25.TabIndex = 18;
            this.label25.Text = "Contry :";
            // 
            // Qulification
            // 
            this.Qulification.AutoSize = true;
            this.Qulification.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Qulification.Location = new System.Drawing.Point(1452, 242);
            this.Qulification.Name = "Qulification";
            this.Qulification.Size = new System.Drawing.Size(17, 24);
            this.Qulification.TabIndex = 17;
            this.Qulification.Text = "-";
            // 
            // AlternateNumber
            // 
            this.AlternateNumber.AutoSize = true;
            this.AlternateNumber.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AlternateNumber.Location = new System.Drawing.Point(902, 242);
            this.AlternateNumber.Name = "AlternateNumber";
            this.AlternateNumber.Size = new System.Drawing.Size(17, 24);
            this.AlternateNumber.TabIndex = 16;
            this.AlternateNumber.Text = "-";
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Email.Location = new System.Drawing.Point(167, 242);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(17, 24);
            this.Email.TabIndex = 15;
            this.Email.Text = "-";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(1292, 242);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(145, 24);
            this.label17.TabIndex = 14;
            this.label17.Text = "Qulification  :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(694, 242);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(202, 24);
            this.label18.TabIndex = 13;
            this.label18.Text = "Alternate Number :";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(37, 242);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(116, 24);
            this.label19.TabIndex = 12;
            this.label19.Text = "Email - Id :";
            // 
            // MobileNumber
            // 
            this.MobileNumber.AutoSize = true;
            this.MobileNumber.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MobileNumber.Location = new System.Drawing.Point(1475, 142);
            this.MobileNumber.Name = "MobileNumber";
            this.MobileNumber.Size = new System.Drawing.Size(17, 24);
            this.MobileNumber.TabIndex = 11;
            this.MobileNumber.Text = "-";
            // 
            // Gender
            // 
            this.Gender.AutoSize = true;
            this.Gender.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Gender.Location = new System.Drawing.Point(801, 142);
            this.Gender.Name = "Gender";
            this.Gender.Size = new System.Drawing.Size(17, 24);
            this.Gender.TabIndex = 10;
            this.Gender.Text = "-";
            // 
            // DateOfBirth
            // 
            this.DateOfBirth.AutoSize = true;
            this.DateOfBirth.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DateOfBirth.Location = new System.Drawing.Point(196, 142);
            this.DateOfBirth.Name = "DateOfBirth";
            this.DateOfBirth.Size = new System.Drawing.Size(17, 24);
            this.DateOfBirth.TabIndex = 9;
            this.DateOfBirth.Text = "-";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(1293, 142);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(176, 24);
            this.label11.TabIndex = 8;
            this.label11.Text = "Mobile Number :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(694, 142);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(98, 24);
            this.label12.TabIndex = 7;
            this.label12.Text = "Gender :";
            // 
            // xccd
            // 
            this.xccd.AutoSize = true;
            this.xccd.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xccd.Location = new System.Drawing.Point(37, 142);
            this.xccd.Name = "xccd";
            this.xccd.Size = new System.Drawing.Size(153, 24);
            this.xccd.TabIndex = 6;
            this.xccd.Text = "Date Of Birth :";
            // 
            // lastname
            // 
            this.lastname.AutoSize = true;
            this.lastname.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastname.Location = new System.Drawing.Point(1420, 43);
            this.lastname.Name = "lastname";
            this.lastname.Size = new System.Drawing.Size(17, 24);
            this.lastname.TabIndex = 5;
            this.lastname.Text = "-";
            // 
            // Middlename
            // 
            this.Middlename.AutoSize = true;
            this.Middlename.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Middlename.Location = new System.Drawing.Point(845, 43);
            this.Middlename.Name = "Middlename";
            this.Middlename.Size = new System.Drawing.Size(17, 24);
            this.Middlename.TabIndex = 4;
            this.Middlename.Text = "-";
            // 
            // lblfirstname
            // 
            this.lblfirstname.AutoSize = true;
            this.lblfirstname.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfirstname.Location = new System.Drawing.Point(167, 43);
            this.lblfirstname.Name = "lblfirstname";
            this.lblfirstname.Size = new System.Drawing.Size(17, 24);
            this.lblfirstname.TabIndex = 3;
            this.lblfirstname.Text = "-";
            // 
            // fddcs
            // 
            this.fddcs.AutoSize = true;
            this.fddcs.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fddcs.Location = new System.Drawing.Point(1293, 43);
            this.fddcs.Name = "fddcs";
            this.fddcs.Size = new System.Drawing.Size(121, 24);
            this.fddcs.TabIndex = 2;
            this.fddcs.Text = "Lastname :";
            // 
            // dcd
            // 
            this.dcd.AutoSize = true;
            this.dcd.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dcd.Location = new System.Drawing.Point(694, 43);
            this.dcd.Name = "dcd";
            this.dcd.Size = new System.Drawing.Size(145, 24);
            this.dcd.TabIndex = 1;
            this.dcd.Text = "Middlename :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(37, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 24);
            this.label2.TabIndex = 0;
            this.label2.Text = "Firstname :";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkCyan;
            this.panel3.Controls.Add(this.CheckAcBalance);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(335, 33);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1108, 83);
            this.panel3.TabIndex = 16;
            // 
            // CheckAcBalance
            // 
            this.CheckAcBalance.BackColor = System.Drawing.Color.CadetBlue;
            this.CheckAcBalance.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CheckAcBalance.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckAcBalance.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.CheckAcBalance.Location = new System.Drawing.Point(547, 22);
            this.CheckAcBalance.MaxLength = 15;
            this.CheckAcBalance.Name = "CheckAcBalance";
            this.CheckAcBalance.Size = new System.Drawing.Size(510, 43);
            this.CheckAcBalance.TabIndex = 22;
            this.CheckAcBalance.TextChanged += new System.EventHandler(this.CheckAcBalance_TextChanged);
            this.CheckAcBalance.KeyDown += new System.Windows.Forms.KeyEventHandler(this.CheckAcBalance_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkCyan;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.OldLace;
            this.label1.Location = new System.Drawing.Point(44, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(497, 43);
            this.label1.TabIndex = 21;
            this.label1.Text = "Enter Account Number : ";
            // 
            // Logout_Panel
            // 
            this.Logout_Panel.BackColor = System.Drawing.Color.Teal;
            this.Logout_Panel.Controls.Add(this.label4);
            this.Logout_Panel.Location = new System.Drawing.Point(711, 996);
            this.Logout_Panel.Name = "Logout_Panel";
            this.Logout_Panel.Size = new System.Drawing.Size(495, 71);
            this.Logout_Panel.TabIndex = 41;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(133, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(249, 33);
            this.label4.TabIndex = 22;
            this.label4.Text = "Logout - (Ctrl+R)";
            // 
            // Temper
            // 
            this.Temper.BackColor = System.Drawing.Color.DarkCyan;
            this.Temper.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Temper.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Temper.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.Temper.Location = new System.Drawing.Point(673, 1066);
            this.Temper.MaxLength = 15;
            this.Temper.Name = "Temper";
            this.Temper.Size = new System.Drawing.Size(10, 43);
            this.Temper.TabIndex = 42;
            this.Temper.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Temper_KeyDown);
            // 
            // View_Account_Details
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(1900, 1079);
            this.Controls.Add(this.Temper);
            this.Controls.Add(this.Logout_Panel);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "View_Account_Details";
            this.Text = "View_Account_Details";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.View_Account_Details_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.AcDetailPanel.ResumeLayout(false);
            this.AccountDetailPanel.ResumeLayout(false);
            this.AccountDetailPanel.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.Logout_Panel.ResumeLayout(false);
            this.Logout_Panel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        public System.Windows.Forms.TextBox CheckAcBalance;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel AcDetailPanel;
        private System.Windows.Forms.Panel AccountDetailPanel;
        private System.Windows.Forms.Label Balance;
        private System.Windows.Forms.Label Occupation;
        private System.Windows.Forms.Label AddharNumber;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label Pancard;
        private System.Windows.Forms.Label AcNum;
        private System.Windows.Forms.Label AcType;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label Pincode;
        private System.Windows.Forms.Label CityTown;
        private System.Windows.Forms.Label Taluka;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label Distric;
        private System.Windows.Forms.Label State;
        private System.Windows.Forms.Label Contry;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label Statedscsc;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label Qulification;
        private System.Windows.Forms.Label AlternateNumber;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label MobileNumber;
        private System.Windows.Forms.Label Gender;
        private System.Windows.Forms.Label DateOfBirth;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label xccd;
        private System.Windows.Forms.Label lastname;
        private System.Windows.Forms.Label Middlename;
        private System.Windows.Forms.Label lblfirstname;
        private System.Windows.Forms.Label fddcs;
        private System.Windows.Forms.Label dcd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel Logout_Panel;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.TextBox Temper;
    }
}