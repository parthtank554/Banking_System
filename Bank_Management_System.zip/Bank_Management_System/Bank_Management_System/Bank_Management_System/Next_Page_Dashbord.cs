﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank_Management_System
{
    public partial class Next_Page_Dashbord : Form
    {
        public Next_Page_Dashbord()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
            Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
            obj.Show();
        }

        private void View_Ac_Details_Click(object sender, EventArgs e)
        {
            this.Close();
            View_Account_Passbook obj = new View_Account_Passbook();
            obj.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
            Edit_Customer_Data obj = new Edit_Customer_Data();
            obj.Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Close();
            Apply_Debit_Card obj = new Apply_Debit_Card();
            obj.Show();
        }
        private void label5_Click(object sender, EventArgs e)
        {
            this.Close();
            Block_Unblock_Debit_Card obj = new Block_Unblock_Debit_Card();
            obj.Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            this.Close();
            Reset_And_Forggot_Card_Pin obj = new Reset_And_Forggot_Card_Pin();
            obj.Show();
        }
        private void label9_Click(object sender, EventArgs e)
        {
            this.Close();
            Active_Debit_Card obj = new Active_Debit_Card();
            obj.Show();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            this.Close();
            View_Debit_Card obj = new View_Debit_Card();
            obj.Show();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            this.Close();
            View_Debit_Card_Details obj = new View_Debit_Card_Details();
            obj.Show();
        }

        private void label11_Click(object sender, EventArgs e)
        {
            this.Close();
            Cancel_Debit_Card obj = new Cancel_Debit_Card();
            obj.Show();
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 obj = new Form1();
            obj.Show();
        }

        private void Next_Page_Dashbord_Load(object sender, EventArgs e)
        {

        }
    }
}
