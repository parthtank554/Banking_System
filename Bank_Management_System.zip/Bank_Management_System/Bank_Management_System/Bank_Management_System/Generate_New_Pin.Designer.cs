﻿namespace Bank_Management_System
{
    partial class Generate_New_Pin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Reset_Panel = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.Exit_Panel = new System.Windows.Forms.Panel();
            this.lblexit = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Debit_Number_Panel = new System.Windows.Forms.Panel();
            this.Debit_Number_Label = new System.Windows.Forms.Label();
            this.Pin_Number = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Set_New_Pin_Panel = new System.Windows.Forms.Panel();
            this.Confirm_Pin_Text_Box = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.New_Pin_Text_Box = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Reset_Panel.SuspendLayout();
            this.Exit_Panel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.Debit_Number_Panel.SuspendLayout();
            this.Set_New_Pin_Panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // Reset_Panel
            // 
            this.Reset_Panel.BackColor = System.Drawing.Color.Teal;
            this.Reset_Panel.Controls.Add(this.label3);
            this.Reset_Panel.Location = new System.Drawing.Point(1494, 206);
            this.Reset_Panel.Name = "Reset_Panel";
            this.Reset_Panel.Size = new System.Drawing.Size(323, 73);
            this.Reset_Panel.TabIndex = 65;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(62, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(194, 29);
            this.label3.TabIndex = 25;
            this.label3.Text = "Exit  - (Ctrl + R)";
            // 
            // Exit_Panel
            // 
            this.Exit_Panel.BackColor = System.Drawing.Color.Teal;
            this.Exit_Panel.Controls.Add(this.lblexit);
            this.Exit_Panel.Location = new System.Drawing.Point(1119, 206);
            this.Exit_Panel.Name = "Exit_Panel";
            this.Exit_Panel.Size = new System.Drawing.Size(369, 73);
            this.Exit_Panel.TabIndex = 64;
            // 
            // lblexit
            // 
            this.lblexit.AutoSize = true;
            this.lblexit.BackColor = System.Drawing.Color.White;
            this.lblexit.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblexit.ForeColor = System.Drawing.Color.Red;
            this.lblexit.Location = new System.Drawing.Point(81, 20);
            this.lblexit.Name = "lblexit";
            this.lblexit.Size = new System.Drawing.Size(191, 29);
            this.lblexit.TabIndex = 25;
            this.lblexit.Text = "Exit  - (Ctrl + X)";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.label44);
            this.panel1.Controls.Add(this.label45);
            this.panel1.Location = new System.Drawing.Point(158, 206);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(948, 73);
            this.panel1.TabIndex = 63;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.Teal;
            this.label44.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.Chartreuse;
            this.label44.Location = new System.Drawing.Point(122, 9);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(270, 43);
            this.label44.TabIndex = 3;
            this.label44.Text = "GIR BANK  - ";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Teal;
            this.label45.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.OldLace;
            this.label45.Location = new System.Drawing.Point(398, 9);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(370, 43);
            this.label45.TabIndex = 2;
            this.label45.Text = "Generate New Pin\r\n";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Teal;
            this.panel3.Controls.Add(this.Debit_Number_Panel);
            this.panel3.Controls.Add(this.Pin_Number);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(158, 315);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1659, 98);
            this.panel3.TabIndex = 66;
            // 
            // Debit_Number_Panel
            // 
            this.Debit_Number_Panel.BackColor = System.Drawing.Color.DarkCyan;
            this.Debit_Number_Panel.Controls.Add(this.Debit_Number_Label);
            this.Debit_Number_Panel.Location = new System.Drawing.Point(1124, 13);
            this.Debit_Number_Panel.Name = "Debit_Number_Panel";
            this.Debit_Number_Panel.Size = new System.Drawing.Size(508, 73);
            this.Debit_Number_Panel.TabIndex = 65;
            // 
            // Debit_Number_Label
            // 
            this.Debit_Number_Label.AutoSize = true;
            this.Debit_Number_Label.BackColor = System.Drawing.Color.White;
            this.Debit_Number_Label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Debit_Number_Label.ForeColor = System.Drawing.Color.Red;
            this.Debit_Number_Label.Location = new System.Drawing.Point(78, 25);
            this.Debit_Number_Label.Name = "Debit_Number_Label";
            this.Debit_Number_Label.Size = new System.Drawing.Size(21, 29);
            this.Debit_Number_Label.TabIndex = 25;
            this.Debit_Number_Label.Text = "-";
            // 
            // Pin_Number
            // 
            this.Pin_Number.BackColor = System.Drawing.Color.CadetBlue;
            this.Pin_Number.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Pin_Number.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pin_Number.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.Pin_Number.Location = new System.Drawing.Point(802, 29);
            this.Pin_Number.MaxLength = 4;
            this.Pin_Number.Name = "Pin_Number";
            this.Pin_Number.Size = new System.Drawing.Size(250, 43);
            this.Pin_Number.TabIndex = 20;
            this.Pin_Number.TextChanged += new System.EventHandler(this.Pin_Number_TextChanged);
            this.Pin_Number.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Pin_Number_KeyDown);
            this.Pin_Number.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Pin_Number_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Teal;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.OldLace;
            this.label1.Location = new System.Drawing.Point(105, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(663, 43);
            this.label1.TabIndex = 4;
            this.label1.Text = "Enter Auto Genrated 4 Digit Pin :\r\n";
            // 
            // Set_New_Pin_Panel
            // 
            this.Set_New_Pin_Panel.BackColor = System.Drawing.Color.Teal;
            this.Set_New_Pin_Panel.Controls.Add(this.Confirm_Pin_Text_Box);
            this.Set_New_Pin_Panel.Controls.Add(this.label4);
            this.Set_New_Pin_Panel.Controls.Add(this.New_Pin_Text_Box);
            this.Set_New_Pin_Panel.Controls.Add(this.label2);
            this.Set_New_Pin_Panel.Location = new System.Drawing.Point(158, 444);
            this.Set_New_Pin_Panel.Name = "Set_New_Pin_Panel";
            this.Set_New_Pin_Panel.Size = new System.Drawing.Size(1659, 210);
            this.Set_New_Pin_Panel.TabIndex = 67;
            // 
            // Confirm_Pin_Text_Box
            // 
            this.Confirm_Pin_Text_Box.BackColor = System.Drawing.Color.CadetBlue;
            this.Confirm_Pin_Text_Box.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Confirm_Pin_Text_Box.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Confirm_Pin_Text_Box.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.Confirm_Pin_Text_Box.Location = new System.Drawing.Point(961, 126);
            this.Confirm_Pin_Text_Box.MaxLength = 4;
            this.Confirm_Pin_Text_Box.Name = "Confirm_Pin_Text_Box";
            this.Confirm_Pin_Text_Box.Size = new System.Drawing.Size(250, 43);
            this.Confirm_Pin_Text_Box.TabIndex = 22;
            this.Confirm_Pin_Text_Box.UseSystemPasswordChar = true;
            this.Confirm_Pin_Text_Box.TextChanged += new System.EventHandler(this.Confirm_Pin_Text_Box_TextChanged);
            this.Confirm_Pin_Text_Box.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Confirm_Pin_Text_Box_KeyDown);
            this.Confirm_Pin_Text_Box.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Pin_Number_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Teal;
            this.label4.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.OldLace;
            this.label4.Location = new System.Drawing.Point(336, 124);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(576, 43);
            this.label4.TabIndex = 21;
            this.label4.Text = "Enter Confirm  Pin Number :\r\n";
            // 
            // New_Pin_Text_Box
            // 
            this.New_Pin_Text_Box.BackColor = System.Drawing.Color.CadetBlue;
            this.New_Pin_Text_Box.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.New_Pin_Text_Box.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.New_Pin_Text_Box.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.New_Pin_Text_Box.Location = new System.Drawing.Point(961, 35);
            this.New_Pin_Text_Box.MaxLength = 4;
            this.New_Pin_Text_Box.Name = "New_Pin_Text_Box";
            this.New_Pin_Text_Box.Size = new System.Drawing.Size(250, 43);
            this.New_Pin_Text_Box.TabIndex = 20;
            this.New_Pin_Text_Box.UseSystemPasswordChar = true;
            this.New_Pin_Text_Box.KeyDown += new System.Windows.Forms.KeyEventHandler(this.New_Pin_Text_Box_KeyDown);
            this.New_Pin_Text_Box.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Pin_Number_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Teal;
            this.label2.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.OldLace;
            this.label2.Location = new System.Drawing.Point(422, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(490, 43);
            this.label2.TabIndex = 4;
            this.label2.Text = "Enter New Pin Number :\r\n";
            // 
            // Generate_New_Pin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(1853, 829);
            this.Controls.Add(this.Set_New_Pin_Panel);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.Reset_Panel);
            this.Controls.Add(this.Exit_Panel);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Generate_New_Pin";
            this.Text = "Generate_New_Pin";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Generate_New_Pin_Load);
            this.Reset_Panel.ResumeLayout(false);
            this.Reset_Panel.PerformLayout();
            this.Exit_Panel.ResumeLayout(false);
            this.Exit_Panel.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.Debit_Number_Panel.ResumeLayout(false);
            this.Debit_Number_Panel.PerformLayout();
            this.Set_New_Pin_Panel.ResumeLayout(false);
            this.Set_New_Pin_Panel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Reset_Panel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel Exit_Panel;
        private System.Windows.Forms.Label lblexit;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel Debit_Number_Panel;
        private System.Windows.Forms.Label Debit_Number_Label;
        public System.Windows.Forms.TextBox Pin_Number;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel Set_New_Pin_Panel;
        public System.Windows.Forms.TextBox Confirm_Pin_Text_Box;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.TextBox New_Pin_Text_Box;
        private System.Windows.Forms.Label label2;
    }
}