﻿namespace Bank_Management_System
{
    partial class Debit_Cash
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.panel6 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.CheckAcBalance = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.LastTrasactionlbl = new System.Windows.Forms.Label();
            this.Balance_Panel = new System.Windows.Forms.Panel();
            this.Trasaction_Proceed = new System.Windows.Forms.Label();
            this.Pleasewaitlbl = new System.Windows.Forms.Label();
            this.T_Complete = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Main_Panel = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.AcNumber = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel4.SuspendLayout();
            this.Balance_Panel.SuspendLayout();
            this.panel2.SuspendLayout();
            this.Main_Panel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer2
            // 
            this.timer2.Interval = 50;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Teal;
            this.panel6.Controls.Add(this.label1);
            this.panel6.Location = new System.Drawing.Point(51, 41);
            this.panel6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1165, 76);
            this.panel6.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Teal;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.OldLace;
            this.label1.Location = new System.Drawing.Point(275, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(516, 56);
            this.label1.TabIndex = 22;
            this.label1.Text = "Enter Debit Amount\r\n";
            // 
            // CheckAcBalance
            // 
            this.CheckAcBalance.BackColor = System.Drawing.Color.CadetBlue;
            this.CheckAcBalance.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CheckAcBalance.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckAcBalance.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.CheckAcBalance.Location = new System.Drawing.Point(47, 31);
            this.CheckAcBalance.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CheckAcBalance.MaxLength = 15;
            this.CheckAcBalance.Name = "CheckAcBalance";
            this.CheckAcBalance.Size = new System.Drawing.Size(212, 56);
            this.CheckAcBalance.TabIndex = 21;
            this.CheckAcBalance.TextChanged += new System.EventHandler(this.CheckAcBalance_TextChanged);
            this.CheckAcBalance.KeyDown += new System.Windows.Forms.KeyEventHandler(this.CheckAcBalance_KeyDown);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Teal;
            this.panel7.Controls.Add(this.CheckAcBalance);
            this.panel7.Location = new System.Drawing.Point(460, 174);
            this.panel7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(317, 116);
            this.panel7.TabIndex = 19;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(28, 53);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(270, 43);
            this.label2.TabIndex = 22;
            this.label2.Text = "Exit - (Ctrl + X)";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Teal;
            this.panel9.Controls.Add(this.label2);
            this.panel9.Location = new System.Drawing.Point(831, 384);
            this.panel9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(340, 134);
            this.panel9.TabIndex = 57;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(39, 46);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(301, 43);
            this.label7.TabIndex = 22;
            this.label7.Text = "Enter - (Ctrl + e)\r\n";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Teal;
            this.panel8.Controls.Add(this.label3);
            this.panel8.Location = new System.Drawing.Point(800, 174);
            this.panel8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(416, 116);
            this.panel8.TabIndex = 20;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(41, 41);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(328, 43);
            this.label3.TabIndex = 58;
            this.label3.Text = "Cancel - (Ctrl + c)";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Teal;
            this.panel10.Controls.Add(this.label7);
            this.panel10.Location = new System.Drawing.Point(51, 174);
            this.panel10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(385, 116);
            this.panel10.TabIndex = 22;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkCyan;
            this.panel4.Controls.Add(this.panel10);
            this.panel4.Controls.Add(this.panel8);
            this.panel4.Controls.Add(this.panel9);
            this.panel4.Controls.Add(this.panel7);
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Location = new System.Drawing.Point(60, 69);
            this.panel4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1273, 336);
            this.panel4.TabIndex = 26;
            // 
            // LastTrasactionlbl
            // 
            this.LastTrasactionlbl.AutoSize = true;
            this.LastTrasactionlbl.BackColor = System.Drawing.Color.Teal;
            this.LastTrasactionlbl.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LastTrasactionlbl.ForeColor = System.Drawing.Color.OldLace;
            this.LastTrasactionlbl.Location = new System.Drawing.Point(420, 320);
            this.LastTrasactionlbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LastTrasactionlbl.Name = "LastTrasactionlbl";
            this.LastTrasactionlbl.Size = new System.Drawing.Size(881, 56);
            this.LastTrasactionlbl.TabIndex = 26;
            this.LastTrasactionlbl.Text = "Last Trasaction Canceled..................";
            // 
            // Balance_Panel
            // 
            this.Balance_Panel.BackColor = System.Drawing.Color.Teal;
            this.Balance_Panel.Controls.Add(this.panel4);
            this.Balance_Panel.Location = new System.Drawing.Point(51, 41);
            this.Balance_Panel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Balance_Panel.Name = "Balance_Panel";
            this.Balance_Panel.Size = new System.Drawing.Size(1393, 474);
            this.Balance_Panel.TabIndex = 21;
            // 
            // Trasaction_Proceed
            // 
            this.Trasaction_Proceed.AutoSize = true;
            this.Trasaction_Proceed.BackColor = System.Drawing.Color.Teal;
            this.Trasaction_Proceed.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Trasaction_Proceed.ForeColor = System.Drawing.Color.OldLace;
            this.Trasaction_Proceed.Location = new System.Drawing.Point(375, 320);
            this.Trasaction_Proceed.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Trasaction_Proceed.Name = "Trasaction_Proceed";
            this.Trasaction_Proceed.Size = new System.Drawing.Size(948, 56);
            this.Trasaction_Proceed.TabIndex = 23;
            this.Trasaction_Proceed.Text = "Trasaction Is Proceed Please Wait.......";
            // 
            // Pleasewaitlbl
            // 
            this.Pleasewaitlbl.AutoSize = true;
            this.Pleasewaitlbl.BackColor = System.Drawing.Color.Teal;
            this.Pleasewaitlbl.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pleasewaitlbl.ForeColor = System.Drawing.Color.OldLace;
            this.Pleasewaitlbl.Location = new System.Drawing.Point(633, 320);
            this.Pleasewaitlbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Pleasewaitlbl.Name = "Pleasewaitlbl";
            this.Pleasewaitlbl.Size = new System.Drawing.Size(374, 56);
            this.Pleasewaitlbl.TabIndex = 5;
            this.Pleasewaitlbl.Text = "Please Wait.....";
            // 
            // T_Complete
            // 
            this.T_Complete.AutoSize = true;
            this.T_Complete.BackColor = System.Drawing.Color.Teal;
            this.T_Complete.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.T_Complete.ForeColor = System.Drawing.Color.OldLace;
            this.T_Complete.Location = new System.Drawing.Point(456, 320);
            this.T_Complete.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.T_Complete.Name = "T_Complete";
            this.T_Complete.Size = new System.Drawing.Size(703, 56);
            this.T_Complete.TabIndex = 5;
            this.T_Complete.Text = "Trasaction Complete.............";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Teal;
            this.panel2.Controls.Add(this.LastTrasactionlbl);
            this.panel2.Controls.Add(this.Main_Panel);
            this.panel2.Controls.Add(this.Trasaction_Proceed);
            this.panel2.Controls.Add(this.Pleasewaitlbl);
            this.panel2.Controls.Add(this.T_Complete);
            this.panel2.Location = new System.Drawing.Point(45, 114);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1635, 693);
            this.panel2.TabIndex = 23;
            // 
            // Main_Panel
            // 
            this.Main_Panel.BackColor = System.Drawing.Color.DarkCyan;
            this.Main_Panel.Controls.Add(this.Balance_Panel);
            this.Main_Panel.Location = new System.Drawing.Point(93, 71);
            this.Main_Panel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Main_Panel.Name = "Main_Panel";
            this.Main_Panel.Size = new System.Drawing.Size(1495, 554);
            this.Main_Panel.TabIndex = 25;
            // 
            // timer1
            // 
            this.timer1.Interval = 50;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.Teal;
            this.label44.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.Chartreuse;
            this.label44.Location = new System.Drawing.Point(83, 11);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(340, 56);
            this.label44.TabIndex = 3;
            this.label44.Text = "GIR BANK  - ";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Teal;
            this.label45.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.OldLace;
            this.label45.Location = new System.Drawing.Point(451, 11);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(446, 56);
            this.label45.TabIndex = 2;
            this.label45.Text = "Withdrawal Cash\r\n";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.label44);
            this.panel1.Controls.Add(this.label45);
            this.panel1.Location = new System.Drawing.Point(45, 34);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1096, 75);
            this.panel1.TabIndex = 21;
            // 
            // AcNumber
            // 
            this.AcNumber.AutoSize = true;
            this.AcNumber.BackColor = System.Drawing.Color.Teal;
            this.AcNumber.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AcNumber.ForeColor = System.Drawing.Color.OldLace;
            this.AcNumber.Location = new System.Drawing.Point(4, 11);
            this.AcNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.AcNumber.Name = "AcNumber";
            this.AcNumber.Size = new System.Drawing.Size(40, 56);
            this.AcNumber.TabIndex = 2;
            this.AcNumber.Text = "-";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Teal;
            this.panel5.Controls.Add(this.AcNumber);
            this.panel5.Location = new System.Drawing.Point(1149, 34);
            this.panel5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(531, 75);
            this.panel5.TabIndex = 22;
            // 
            // Debit_Cash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(1751, 869);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel5);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Debit_Cash";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Debit_Cash";
            this.Load += new System.EventHandler(this.Debit_Cash_Load);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.Balance_Panel.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.Main_Panel.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox CheckAcBalance;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label LastTrasactionlbl;
        private System.Windows.Forms.Panel Balance_Panel;
        private System.Windows.Forms.Label Trasaction_Proceed;
        private System.Windows.Forms.Label Pleasewaitlbl;
        private System.Windows.Forms.Label T_Complete;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel Main_Panel;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.Label AcNumber;
        private System.Windows.Forms.Panel panel5;
    }
}