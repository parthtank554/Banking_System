﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Bank_Management_System
{
    public partial class Gie_Bank_Dashbord : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        DataSet ds = new DataSet();
        string txtFirstname = "";
        public Gie_Bank_Dashbord()
        {
            InitializeComponent();
        }
        public void Con()
        {
            con = new SqlConnection(@"Provider=Microsoft.Jet.Sql.4.0;Data Source=E:\C#\Bank_Management_System\Bank_Management_System\bin\Bank_Managment_Database.mdb");
            con.Open();
        }
        private void Gie_Bank_Dashbord_Load(object sender, EventArgs e)
        {
           

            //blusername.Text = txtFirstname;
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 obj = new Form1();
            obj.Show();
        }

        private void Open_New_Account_Click(object sender, EventArgs e)
        {
            Customer_Ragistration_Form obj = new Customer_Ragistration_Form();
            this.Hide();
            obj.Show();
        }

        private void Search_Ac_Details_Click(object sender, EventArgs e)
        {
            this.Hide();
            Block_And_Unblock_Ac obj = new Block_And_Unblock_Ac();
            obj.Show();
        }
        private void Check_Ac_Balance_Click(object sender, EventArgs e)
        {
            Check_Account_Balance obj = new Check_Account_Balance();
            this.Hide();
            obj.Show();
        }

        private void Deposite_Amount_Click(object sender, EventArgs e)
        {
            this.Close();
            Deposite_Amount obj = new Deposite_Amount();
            obj.Show();
            
        }

        private void Withdrawal_Amount_Click(object sender, EventArgs e)
        {
            this.Hide();
            Debit_Amount_Form obj = new Debit_Amount_Form();
            obj.Show();
        }

        private void Transfer_Amount_Click(object sender, EventArgs e)
        {
            this.Hide();
            Transfer_Amount_Form obj = new Transfer_Amount_Form();
            obj.Show();
        }

        private void View_Ac_Details_Click(object sender, EventArgs e)
        {
            this.Hide();
            View_Account_Details obj = new View_Account_Details();
            obj.Show();
        }

        private void Remove_Ac_Click(object sender, EventArgs e)
        {
            this.Hide();
            Delete_Account obj = new Delete_Account();
            obj.Show();
        }

        private void View_Ac_History_Click(object sender, EventArgs e)
        {
            this.Hide();
            Account_History obj = new Account_History();
            obj.Show();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
            Next_Page_Dashbord obj = new Next_Page_Dashbord();
            obj.Show();
        }
    }
}
