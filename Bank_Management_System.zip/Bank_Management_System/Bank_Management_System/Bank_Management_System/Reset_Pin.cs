﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Bank_Management_System
{
    public partial class Reset_Pin : Form
    {
        SqlCommand cmd, cmd2;
        SqlConnection con;
        SqlDataAdapter oda;
        DataTable dt;
        string pinnum = "";
        public Reset_Pin()
        {
            InitializeComponent();
        }

        private void Reset_Pin_Load(object sender, EventArgs e)
        {
            Debit_Number_Label.Visible = false;
            Set_New_Pin_Panel.Enabled = false;
        }

        private void Pin_Number_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt32(Pin_Number.Text.Length) == 4)
            {
                Pin_Number.Enabled = false;
                con = new SqlConnection(Con_Class.cnn);
                con.Open();

                cmd = new SqlCommand("select * from Debit_Card_Apply where Pin='" + Pin_Number.Text + "'", con);
                oda = new SqlDataAdapter(cmd);
                dt = new DataTable();
                oda.Fill(dt);
                foreach (DataRow dr in dt.Rows)
                {
                    pinnum = dr["Pin"].ToString();
                    Debit_Number_Label.Text = dr["DebitNumber"].ToString();
                    Debit_Number_Label.Visible = true;
                    Set_New_Pin_Panel.Enabled = true;
                    New_Pin_Text_Box.Focus();

                }
                if (Debit_Number_Label.Text == "-")
                {
                    MessageBox.Show("Pin Number Not Found.....", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Debit_Number_Label.Visible = false;
                    Set_New_Pin_Panel.Enabled = false;
                    Pin_Number.Enabled = true;
                    Pin_Number.Clear();
                    Pin_Number.Focus();
                }

            }
        }
        private void Pin_Number_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                this.Close();
                Reset_And_Forggot_Card_Pin obj = new Reset_And_Forggot_Card_Pin();
                obj.Show();
            }
        }
        private void Confirm_Pin_Text_Box_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt32(Confirm_Pin_Text_Box.Text.Length) == 4)
            {
                if (New_Pin_Text_Box.Text == Confirm_Pin_Text_Box.Text)
                {
                    con = new SqlConnection(Con_Class.cnn);
                    con.Open();

                    cmd2 = new SqlCommand("update Debit_Card_Apply set Pin='" + Confirm_Pin_Text_Box.Text + "' where DebitNumber='" + Debit_Number_Label.Text + "'", con);
                    int res = cmd2.ExecuteNonQuery();
                    if (res > 0)
                    {
                        MessageBox.Show("Pin Updated Successfully.....", "Suceess !", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Debit_Number_Label.Visible = false;
                        Set_New_Pin_Panel.Enabled = false;
                        Pin_Number.Enabled = true;
                        New_Pin_Text_Box.Clear();
                        Confirm_Pin_Text_Box.Clear();
                        Pin_Number.Clear();
                        Pin_Number.Focus();
                    }
                    else
                    {
                        MessageBox.Show("Error");
                    }

                }
            }
        }

        private void New_Pin_Text_Box_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                MessageBox.Show("Please Logout First......", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                DialogResult di = MessageBox.Show("Are You Sure All Reset........", "Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                if (di == DialogResult.Yes)
                {
                    Debit_Number_Label.Visible = false;
                    Set_New_Pin_Panel.Enabled = false;
                    Pin_Number.Enabled = true;
                    New_Pin_Text_Box.Clear();
                    Confirm_Pin_Text_Box.Clear();
                    Pin_Number.Clear();
                    Pin_Number.Focus();
                }
            }
        }

        private void Confirm_Pin_Text_Box_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                MessageBox.Show("Please Logout First......", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                DialogResult di = MessageBox.Show("Are You Sure All Reset........", "Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                if (di == DialogResult.Yes)
                {
                    Debit_Number_Label.Visible = false;
                    Set_New_Pin_Panel.Enabled = false;
                    Pin_Number.Enabled = true;
                    New_Pin_Text_Box.Clear();
                    Confirm_Pin_Text_Box.Clear();
                    Pin_Number.Clear();
                    Pin_Number.Focus();
                }
            }
        }

        private void Pin_Number_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                this.Close();
                Reset_And_Forggot_Card_Pin obj = new Reset_And_Forggot_Card_Pin();
                obj.Show();
            }
        }
    }
}

