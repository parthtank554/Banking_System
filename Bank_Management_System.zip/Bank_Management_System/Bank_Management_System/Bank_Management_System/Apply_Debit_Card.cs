﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Bank_Management_System
{
    public partial class Apply_Debit_Card : Form
    {
        SqlConnection con;
        SqlDataAdapter oda;
        DataTable dt;
        SqlCommand cmd, comm, bu, cmd2, History,cmd3;
        DataSet ds = new DataSet();
        int i = 0;
        string BlockList = "", firstnm = "", lastnm = "", AcBalance = "",AcNumber="",bc="";
        public Apply_Debit_Card()
        {
            InitializeComponent();
        }
        public void debit_amount()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();
            string qry = "select AcBalance from Customer_Table where AcNumber='" + CheckAcBalance.Text + "'";
            cmd2 = new SqlCommand(qry, con);
            DataTable dt = new DataTable();
            SqlDataAdapter oda = new SqlDataAdapter(cmd2);
            oda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
               int Balanece = Convert.ToInt32(dr["AcBalance"].ToString());
                int UpdateBal = Balanece - 250;
                AcBalance = UpdateBal.ToString();
            }
            cmd2 = new SqlCommand("update Customer_Table set AcBalance='" + AcBalance + "' where  AcNumber='" + CheckAcBalance.Text + "'", con);
        }
        public void Check_Ac()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();

            cmd3 = new SqlCommand("select * From Debit_Card_Apply where AcNumber='" + CheckAcBalance.Text + "'",con);
            oda = new SqlDataAdapter(cmd3);
            dt = new DataTable();
            oda.Fill(dt);

            foreach (DataRow dr in dt.Rows)
            {
                AcNumber = dr["AcNumber"].ToString();
            }
        
        }
        public void Block_List()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();
            string qry = "select * from Blocke_Ac where BalockAcNumber='" + CheckAcBalance.Text + "'";
            comm = new SqlCommand(qry, con);
            DataTable dt = new DataTable();
            SqlDataAdapter oda = new SqlDataAdapter(comm);
            oda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                BlockList = dr["BalockAcNumber"].ToString();

            }
        }
      
        private void CheckAcBalance_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                this.Close();
                Next_Page_Dashbord obj = new Next_Page_Dashbord();
                obj.Show();
            }
        }
        public void Debit_Label_Visible_False()
        {
            Notification_Label.Visible = false;
            Name_Detail_Panel.Enabled = false;
            Loding_Panel.Enabled = false;
            lblreset.Visible = false;
            Control_Panel.Enabled = false;
            Apply_Apnel.Enabled = false;
            Reset_Panel.Enabled = false;
            Submit_Panel.Enabled = false;
            Debit_Card_Panel.Visible = false;
            Debit_First_Name.Visible = false;
            Debit_Last_Name.Visible = false;
            Debit_Card_First_Number.Visible = false;
            Debit_Card_Secondt_Number.Visible = false;
            Debit_Card_Third_Number.Visible = false;
            Debit_Card_Fourth_Number.Visible = false;
            Valid_Upto_Date.Visible = false;
            Valid_Upto_Text_Label.Visible = false;
            Uniq_Id_Number.Visible = false;
            Debit_Card_CVV_Number.Visible = false;
        }
        public void Debit_Label_Visible_True()
        {
           
            Name_Detail_Panel.Visible = true;
            Debit_Card_Panel.Visible = true;
            Debit_First_Name.Visible = true;
            Debit_Last_Name.Visible = true;
            Debit_Card_First_Number.Visible = true;
            Debit_Card_Secondt_Number.Visible = true;
            Debit_Card_Third_Number.Visible = true;
            Debit_Card_Fourth_Number.Visible = true;
            Valid_Upto_Date.Visible = true;
            Valid_Upto_Text_Label.Visible = true;
            Uniq_Id_Number.Visible = true;
            Debit_Card_CVV_Number.Visible = true;

            Random s = new Random();
            Debit_Card_Secondt_Number.Text = s.Next(2000, 3000).ToString();
            Debit_Card_Third_Number.Text = s.Next(4000, 5000).ToString();
            Debit_Card_Fourth_Number.Text = s.Next(6000, 7000).ToString();
            Uniq_Id_Number.Text = s.Next(8000, 9000).ToString();
            Debit_Card_CVV_Number.Text = s.Next(100, 900).ToString();
            Debit_First_Name.Text = firstnm;
            Debit_Last_Name.Text = lastnm;
        }
        private void Apply_Debit_Card_Load(object sender, EventArgs e)
        {
            CheckAcBalance.Focus();
            Debit_Label_Visible_False();
        }

        private void CheckAcBalance_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt16(CheckAcBalance.Text.Length) == 15)
            {
                Block_List();
                if (CheckAcBalance.Text == BlockList)
                {
                    MessageBox.Show("Account Is Blocked Please Try Another Account !! ", "DeActivated", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    CheckAcBalance.Clear();
                    CheckAcBalance.Enabled = true;
                    CheckAcBalance.Focus();
                    this.OnLoad(e);
                }
                else
                {
                    Check_Ac();
                    if (AcNumber == CheckAcBalance.Text)
                    {
                        MessageBox.Show("This Account Debit Card Alredy  Issued......", "Currently Activated", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        CheckAcBalance.Clear();
                        CheckAcBalance.Enabled = true;
                        CheckAcBalance.Focus();
                        this.OnLoad(e);
                    }
                    else
                    {
                        CheckAcBalance.Enabled = false;
                        con = new SqlConnection(Con_Class.cnn);
                        con.Open();
                        string qry = "select * from Customer_Table where AcNumber='" + CheckAcBalance.Text + "'";
                        cmd = new SqlCommand(qry, con);
                        DataTable dt = new DataTable();
                        SqlDataAdapter oda = new SqlDataAdapter(cmd);
                        oda.Fill(dt);
                        foreach (DataRow dr in dt.Rows)
                        {
                            Reset_Panel.Visible = true;

                            Name_Detail_Panel.Enabled = true;
                            Control_Panel.Enabled = true;
                            Apply_Apnel.Enabled = true;
                            Reset_Panel.Enabled = true;
                            AcHoldername.Text = dr["Firstname"].ToString();
                            Lastname.Text = dr["Lastname"].ToString();
                            AccountNumber.Text = dr["AcNumber"].ToString();
                            firstnm = dr["Firstname"].ToString();
                            lastnm = dr["Lastname"].ToString();
                            lblexit.Visible = false;
                            lblreset.Visible = true;


                        }
                        if (AccountNumber.Text == "-")
                        {
                            CheckAcBalance.Clear();
                            MessageBox.Show("Acount Not Found....?", "Invalid A/c Number", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            CheckAcBalance.Enabled = true;
                            CheckAcBalance.Focus();
                        }
                    }
                }
            }
        
        }
        private void Temper_TextBox_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.A)
            {
                timer1.Start();
                Notification_Label.Visible = true;
                Apply_Apnel.Enabled = false;
                Reset_Panel.Enabled = false;
                Loding_Panel.Enabled = true;

            }

            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                Debit_Label_Visible_False();
                Apply_Apnel.Enabled = false;
                Reset_Panel.Enabled = false;
                Submit_Panel.Enabled = false;
                Notification_Label.Visible = false;
                Name_Detail_Panel.Enabled = false;
                AcHoldername.Text = "-";
                Lastname.Text = "-";
                AccountNumber.Text = "-";
                Control_Panel.Enabled = false;
                CheckAcBalance.Enabled = true;
                lblreset.Visible = false;
                lblexit.Visible = true;
                CheckAcBalance.Clear();
                CheckAcBalance.Focus();
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.S)
            {
                if (Debit_Card_Panel.Visible == false)
                {

                    MessageBox.Show("Not Proceed....", "404", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    con = new SqlConnection(Con_Class.cnn);
                    con.Open();
                    String DebitNum = Debit_Card_First_Number.Text + Debit_Card_Secondt_Number.Text + Debit_Card_Third_Number.Text + Debit_Card_Fourth_Number.Text;
                    String Status = "DeActivate", AcStatus = "UnBlock";
                    Random pin = new Random();
                    String Pin = pin.Next(2000, 8000).ToString();
                    cmd = new SqlCommand("insert into Debit_Card_Apply  values('" + DebitNum + "','" + Debit_Card_First_Number.Text + "','" + Debit_Card_Secondt_Number.Text + "','" + Debit_Card_Third_Number.Text + "','" + Debit_Card_Fourth_Number.Text + "','" + Uniq_Id_Number.Text + "','" + Valid_Upto_Date.Text + "','" + Debit_First_Name.Text + "','" + Debit_Last_Name.Text + "','" + AccountNumber.Text + "','" + Debit_Card_CVV_Number.Text + "','" + Status + "', '" + "Visa" + "','" + Pin + "','-')", con);
                    cmd.ExecuteNonQuery();
                    comm = new SqlCommand("insert into Debit_Random_Pin values('" + Pin + "')", con);
                    comm.ExecuteNonQuery();
                    debit_amount();
                    cmd2.ExecuteNonQuery();
                    string Date = DateTime.Now.ToLongDateString();
                    string Time = DateTime.Now.ToLongTimeString();
                    string Db = "Debit";
                    History = new SqlCommand("insert into Ac_History values('" + Date + "','" + Time + "','" + AcHoldername.Text + "','" + CheckAcBalance.Text + "','" + Db + "','250')", con);
                    int res = History.ExecuteNonQuery();
                    bu = new SqlCommand("insert into Block_Unblock_Status values('" + AcStatus + "')", con);
                    if (res > 0)
                    {
                        MessageBox.Show("Detail Submited Successfully", "Detail Submited", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        MessageBox.Show("Your Card Pin Please Note Down And Reset Within 24 Hourse : " + Pin, "Auto Generated Pin", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Debit_Label_Visible_False();
                        Apply_Apnel.Enabled = false;
                        Reset_Panel.Enabled = false;
                        Submit_Panel.Enabled = false;
                        Notification_Label.Visible = false;
                        Name_Detail_Panel.Enabled = false;
                        AcHoldername.Text = "-";
                        Lastname.Text = "-";
                        AccountNumber.Text = "-";
                        Control_Panel.Enabled = false;
                        CheckAcBalance.Enabled = true;
                        lblreset.Visible = false;
                        lblexit.Visible = true;
                        CheckAcBalance.Clear();
                        CheckAcBalance.Focus();
                        timer1.Stop();
                        i = 0;
                        Notification_Label.Text = "Loading....";
                    }
                    else
                    {
                        MessageBox.Show("Somthing Went Wrong Please Try Again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Debit_Label_Visible_False();
                        Apply_Apnel.Enabled = false;
                        Reset_Panel.Enabled = false;
                        Submit_Panel.Enabled = false;
                        Notification_Label.Visible = false;
                        Name_Detail_Panel.Enabled = false;
                        AcHoldername.Text = "-";
                        Lastname.Text = "-";
                        AccountNumber.Text = "-";
                        Control_Panel.Enabled = false;
                        CheckAcBalance.Enabled = true;
                        lblreset.Visible = false;
                        lblexit.Visible = true;
                        CheckAcBalance.Clear();
                        CheckAcBalance.Focus();
                    }
                }
                if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
                {
                    MessageBox.Show("Logout First...?", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
        }
        

        private void timer1_Tick(object sender, EventArgs e)
        {
           
            i++;
            if (i == 50) { Notification_Label.Text = "Verifying Customer Deatils........"; }
            if (i == 100) { Notification_Label.Text = "Validate Cutomer Account.........."; }
            if (i == 150) { Notification_Label.Text = "Validate Cutomer Uniq Id.........."; timer1.Stop(); MessageBox.Show("Validation Successfully Completed...", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information); timer1.Start(); }
            if (i == 200) { Notification_Label.Text = "Get Approval From Bank.........."; }
            if (i == 250) { timer1.Stop(); MessageBox.Show("Approved By Bank ...", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information); timer1.Start(); Notification_Label.Text = "Generate Unique Number....";}
            if (i == 300) { Notification_Label.Text = "Card Is Under Printing Please Wait........."; }
            if(i == 350) { Notification_Label.Text = "Congratulation ! Card Printed Successfully";}
            if (i == 400) { Debit_Label_Visible_True(); Reset_Panel.Enabled = true; Submit_Panel.Enabled = true; Temper_TextBox.Focus(); }
        }

        private void CheckAcBalance_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                this.Close();
                Next_Page_Dashbord obj = new Next_Page_Dashbord();
                obj.Show();
            }
        }
    }
}