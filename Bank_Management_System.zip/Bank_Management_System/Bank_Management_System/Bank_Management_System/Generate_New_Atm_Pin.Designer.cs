﻿namespace Bank_Management_System
{
    partial class Generate_New_Atm_Pin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Confirm_Pin_Text_Box = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.New_Pin_Text_Box = new System.Windows.Forms.TextBox();
            this.Set_New_Pin_Panel = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.Pin_Number = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Main_Pin_Panel = new System.Windows.Forms.Panel();
            this.label44 = new System.Windows.Forms.Label();
            this.Gir_lbl_panel = new System.Windows.Forms.Panel();
            this.label45 = new System.Windows.Forms.Label();
            this.Cancel_Panel = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.wait_lbl = new System.Windows.Forms.Label();
            this.Last_Trasaction = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.Set_New_Pin_Panel.SuspendLayout();
            this.Main_Pin_Panel.SuspendLayout();
            this.Gir_lbl_panel.SuspendLayout();
            this.Cancel_Panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // Confirm_Pin_Text_Box
            // 
            this.Confirm_Pin_Text_Box.BackColor = System.Drawing.Color.CadetBlue;
            this.Confirm_Pin_Text_Box.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Confirm_Pin_Text_Box.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Confirm_Pin_Text_Box.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.Confirm_Pin_Text_Box.Location = new System.Drawing.Point(865, 125);
            this.Confirm_Pin_Text_Box.MaxLength = 4;
            this.Confirm_Pin_Text_Box.Name = "Confirm_Pin_Text_Box";
            this.Confirm_Pin_Text_Box.Size = new System.Drawing.Size(250, 43);
            this.Confirm_Pin_Text_Box.TabIndex = 22;
            this.Confirm_Pin_Text_Box.UseSystemPasswordChar = true;
            this.Confirm_Pin_Text_Box.TextChanged += new System.EventHandler(this.Confirm_Pin_Text_Box_TextChanged);
            this.Confirm_Pin_Text_Box.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Pin_Number_KeyDown);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Teal;
            this.label4.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.OldLace;
            this.label4.Location = new System.Drawing.Point(240, 123);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(576, 43);
            this.label4.TabIndex = 21;
            this.label4.Text = "Enter Confirm  Pin Number :\r\n";
            // 
            // New_Pin_Text_Box
            // 
            this.New_Pin_Text_Box.BackColor = System.Drawing.Color.CadetBlue;
            this.New_Pin_Text_Box.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.New_Pin_Text_Box.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.New_Pin_Text_Box.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.New_Pin_Text_Box.Location = new System.Drawing.Point(865, 41);
            this.New_Pin_Text_Box.MaxLength = 4;
            this.New_Pin_Text_Box.Name = "New_Pin_Text_Box";
            this.New_Pin_Text_Box.Size = new System.Drawing.Size(250, 43);
            this.New_Pin_Text_Box.TabIndex = 20;
            this.New_Pin_Text_Box.UseSystemPasswordChar = true;
            this.New_Pin_Text_Box.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Pin_Number_KeyDown);
            // 
            // Set_New_Pin_Panel
            // 
            this.Set_New_Pin_Panel.BackColor = System.Drawing.Color.Teal;
            this.Set_New_Pin_Panel.Controls.Add(this.Confirm_Pin_Text_Box);
            this.Set_New_Pin_Panel.Controls.Add(this.label4);
            this.Set_New_Pin_Panel.Controls.Add(this.New_Pin_Text_Box);
            this.Set_New_Pin_Panel.Controls.Add(this.label2);
            this.Set_New_Pin_Panel.Location = new System.Drawing.Point(29, 300);
            this.Set_New_Pin_Panel.Name = "Set_New_Pin_Panel";
            this.Set_New_Pin_Panel.Size = new System.Drawing.Size(1366, 210);
            this.Set_New_Pin_Panel.TabIndex = 72;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Teal;
            this.label2.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.OldLace;
            this.label2.Location = new System.Drawing.Point(325, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(490, 43);
            this.label2.TabIndex = 4;
            this.label2.Text = "Enter New Pin Number :\r\n";
            // 
            // Pin_Number
            // 
            this.Pin_Number.BackColor = System.Drawing.Color.CadetBlue;
            this.Pin_Number.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Pin_Number.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pin_Number.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.Pin_Number.Location = new System.Drawing.Point(865, 29);
            this.Pin_Number.MaxLength = 4;
            this.Pin_Number.Name = "Pin_Number";
            this.Pin_Number.Size = new System.Drawing.Size(250, 43);
            this.Pin_Number.TabIndex = 20;
            this.Pin_Number.TextChanged += new System.EventHandler(this.Pin_Number_TextChanged);
            this.Pin_Number.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Pin_Number_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Teal;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.OldLace;
            this.label1.Location = new System.Drawing.Point(152, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(663, 43);
            this.label1.TabIndex = 4;
            this.label1.Text = "Enter Auto Genrated 4 Digit Pin :\r\n";
            // 
            // Main_Pin_Panel
            // 
            this.Main_Pin_Panel.BackColor = System.Drawing.Color.Teal;
            this.Main_Pin_Panel.Controls.Add(this.Pin_Number);
            this.Main_Pin_Panel.Controls.Add(this.label1);
            this.Main_Pin_Panel.Location = new System.Drawing.Point(29, 185);
            this.Main_Pin_Panel.Name = "Main_Pin_Panel";
            this.Main_Pin_Panel.Size = new System.Drawing.Size(1366, 98);
            this.Main_Pin_Panel.TabIndex = 71;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.Teal;
            this.label44.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.Chartreuse;
            this.label44.Location = new System.Drawing.Point(122, 9);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(270, 43);
            this.label44.TabIndex = 3;
            this.label44.Text = "GIR BANK  - ";
            // 
            // Gir_lbl_panel
            // 
            this.Gir_lbl_panel.BackColor = System.Drawing.Color.Teal;
            this.Gir_lbl_panel.Controls.Add(this.label44);
            this.Gir_lbl_panel.Controls.Add(this.label45);
            this.Gir_lbl_panel.Location = new System.Drawing.Point(29, 95);
            this.Gir_lbl_panel.Name = "Gir_lbl_panel";
            this.Gir_lbl_panel.Size = new System.Drawing.Size(948, 73);
            this.Gir_lbl_panel.TabIndex = 68;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Teal;
            this.label45.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.OldLace;
            this.label45.Location = new System.Drawing.Point(398, 9);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(370, 43);
            this.label45.TabIndex = 2;
            this.label45.Text = "Generate New Pin\r\n";
            // 
            // Cancel_Panel
            // 
            this.Cancel_Panel.BackColor = System.Drawing.Color.Teal;
            this.Cancel_Panel.Controls.Add(this.label7);
            this.Cancel_Panel.Location = new System.Drawing.Point(1006, 95);
            this.Cancel_Panel.Name = "Cancel_Panel";
            this.Cancel_Panel.Size = new System.Drawing.Size(389, 73);
            this.Cancel_Panel.TabIndex = 73;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(56, 19);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(258, 33);
            this.label7.TabIndex = 22;
            this.label7.Text = "Cancel - (Ctrl + X)";
            // 
            // timer1
            // 
            this.timer1.Interval = 50;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // wait_lbl
            // 
            this.wait_lbl.AutoSize = true;
            this.wait_lbl.BackColor = System.Drawing.Color.Teal;
            this.wait_lbl.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wait_lbl.ForeColor = System.Drawing.Color.OldLace;
            this.wait_lbl.Location = new System.Drawing.Point(547, 273);
            this.wait_lbl.Name = "wait_lbl";
            this.wait_lbl.Size = new System.Drawing.Size(324, 43);
            this.wait_lbl.TabIndex = 23;
            this.wait_lbl.Text = "Please Wait........";
            // 
            // Last_Trasaction
            // 
            this.Last_Trasaction.AutoSize = true;
            this.Last_Trasaction.BackColor = System.Drawing.Color.Teal;
            this.Last_Trasaction.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Last_Trasaction.ForeColor = System.Drawing.Color.OldLace;
            this.Last_Trasaction.Location = new System.Drawing.Point(328, 273);
            this.Last_Trasaction.Name = "Last_Trasaction";
            this.Last_Trasaction.Size = new System.Drawing.Size(854, 43);
            this.Last_Trasaction.TabIndex = 74;
            this.Last_Trasaction.Text = "Last Trasaction Canceled Successfully.........";
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // Generate_New_Atm_Pin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(1448, 599);
            this.Controls.Add(this.wait_lbl);
            this.Controls.Add(this.Last_Trasaction);
            this.Controls.Add(this.Cancel_Panel);
            this.Controls.Add(this.Set_New_Pin_Panel);
            this.Controls.Add(this.Main_Pin_Panel);
            this.Controls.Add(this.Gir_lbl_panel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Generate_New_Atm_Pin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Generate_New_Atm_Pin";
            this.Load += new System.EventHandler(this.Generate_New_Atm_Pin_Load);
            this.Set_New_Pin_Panel.ResumeLayout(false);
            this.Set_New_Pin_Panel.PerformLayout();
            this.Main_Pin_Panel.ResumeLayout(false);
            this.Main_Pin_Panel.PerformLayout();
            this.Gir_lbl_panel.ResumeLayout(false);
            this.Gir_lbl_panel.PerformLayout();
            this.Cancel_Panel.ResumeLayout(false);
            this.Cancel_Panel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TextBox Confirm_Pin_Text_Box;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.TextBox New_Pin_Text_Box;
        private System.Windows.Forms.Panel Set_New_Pin_Panel;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox Pin_Number;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel Main_Pin_Panel;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Panel Gir_lbl_panel;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Panel Cancel_Panel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label wait_lbl;
        private System.Windows.Forms.Label Last_Trasaction;
        private System.Windows.Forms.Timer timer2;
    }
}