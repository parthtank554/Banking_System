﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Globalization;

namespace Bank_Management_System
{
    public partial class Transfer_Amount_Form : Form
    {

        SqlConnection con;
        SqlCommand cmd,comm,comn,ToHistory,FromHistory;
        string BlockList = "";
        int Balanece = 0;
        string ToAcBalance = "",BlockList2;
        public Transfer_Amount_Form()
        {
            InitializeComponent();
        }
        public void Block_List()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();
            string qry = "select * from Blocke_Ac where BalockAcNumber='" + ToAccountBalancetextbox.Text + "'";
            comm = new SqlCommand(qry, con);
            DataTable dt = new DataTable();
            SqlDataAdapter oda = new SqlDataAdapter(comm);
            oda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                BlockList = dr["BalockAcNumber"].ToString();

            }
        }
        public void Block_List2()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();
            string qry = "select * from Blocke_Ac where BalockAcNumber='" + FromAccountBalancetextbox.Text + "'";
            comn = new SqlCommand(qry, con);
            DataTable dt = new DataTable();
            SqlDataAdapter oda = new SqlDataAdapter(comn);
            oda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                BlockList2 = dr["BalockAcNumber"].ToString();

            }
        }
        public void Credit_Fund()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();
            string qry = "select AcBalance from Customer_Table where AcNumber='" + FromAccountBalancetextbox.Text + "'";
            cmd = new SqlCommand(qry, con);
            DataTable dt = new DataTable();
            SqlDataAdapter oda = new SqlDataAdapter(cmd);
            oda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                Balanece = Convert.ToInt32(dr["AcBalance"].ToString());
                int UpdateBal = Balanece + Convert.ToInt32(DebitAmount.Text);
                ToAcBalance = UpdateBal.ToString();

            }
            cmd = new SqlCommand("update Customer_Table set AcBalance='" + ToAcBalance + "' where  AcNumber='" + FromAccountBalancetextbox.Text + "'", con);
            string Date = DateTime.Now.ToLongDateString();
            string Time = DateTime.Now.ToLongTimeString();
            string Credit = "Credit";
            FromHistory = new SqlCommand("insert into Ac_History values('" + Date + "','" + Time + "','" + FromAcHoldername.Text + "','" + FromAccountBalancetextbox.Text + "','" + Credit + "','" + DebitAmount.Text + "')", con);
            FromHistory.ExecuteNonQuery();
            int res = cmd.ExecuteNonQuery();
            Logout_Panel.Visible = true;
        }
        public void Debit_Fund()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();
            string qry = "select AcBalance from Customer_Table where AcNumber='" + ToAccountBalancetextbox.Text + "'";
            comm = new SqlCommand(qry, con);
            DataTable dt = new DataTable();
            SqlDataAdapter oda = new SqlDataAdapter(comm);
            oda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                Balanece = Convert.ToInt32(dr["AcBalance"].ToString());
                int UpdateBal = Balanece - Convert.ToInt32(DebitAmount.Text);
                ToAcBalance = UpdateBal.ToString();
                
            }
            comm = new SqlCommand("update Customer_Table set AcBalance='" + ToAcBalance + "' where  AcNumber='" +ToAccountBalancetextbox.Text + "'", con);
            string Date = DateTime.Now.ToLongDateString();
            string Time = DateTime.Now.ToLongTimeString();
            string Credit = "Debit";
            ToHistory = new SqlCommand("insert into Ac_History values('" + Date + "','" + Time + "','" + ToAcHoldername.Text + "','" + ToAccountBalancetextbox.Text + "','" + Credit + "','" + DebitAmount.Text + "')", con);
            ToHistory.ExecuteNonQuery();
            int res = comm.ExecuteNonQuery();
            if (res > 0)
            {
                MessageBox.Show("Trasaction Successful !", "Sccess", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ToAccountBalancetextbox.Enabled = true;
                Logout_Panel.Visible = false;
                ToAccountBalancetextbox.Clear();
                ToAccountBalancetextbox.Focus();
            }
        }

        private void Transfer_Amount_Form_Load(object sender, EventArgs e)
        {
            Logout_Panel.Visible = false;
            ToAccountBalancetextbox.Focus();
            ToNameDetailPanel.Enabled = false;
            FromPanel.Enabled = false;
            FromDetailPanel.Enabled = false;
            Deposite_Panel.Enabled = false;
            Submit_Button_Panel.Enabled = false;
           
            Random rand = new Random();
            int num = rand.Next(6, 8);
            int total = 0;
            string captcha = "";

            do
            {
                int chr = rand.Next(100, 123);
                if ((chr >= 48 && chr <= 57) || (chr >= 65 && chr <= 90) || (chr >= 97 && chr <= 122))
                {
                    captcha = captcha + (char)chr;
                    total++;
                    if (total == num)
                        break;
                    {

                    }
                }
            } while (true);

            Captcha.Text = captcha;
        }
        private void ToAccountBalancetextbox_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt16(ToAccountBalancetextbox.Text.Length) == 15)
            {
                if (ToAccountBalancetextbox.Text == "")
                {
                    MessageBox.Show("Please Enter Account Number", "Blank Record", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    ToAccountBalancetextbox.Focus();
                    ToNameDetailPanel.Enabled = false;
                    FromPanel.Enabled = false;
                    FromDetailPanel.Enabled = false;
                    Deposite_Panel.Enabled = false;
                    Submit_Button_Panel.Enabled = false;
                }
                else
                {
                    Block_List();
                    if (BlockList == ToAccountBalancetextbox.Text)
                    {
                        MessageBox.Show("Account Is Blocked Please Contact Nearest Breansh !!", "DeActivated", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        ToAccountBalancetextbox.Clear();
                        ToAccountBalancetextbox.Focus();
                        ToNameDetailPanel.Enabled = false;
                        FromPanel.Enabled = false;
                        FromDetailPanel.Enabled = false;
                        Deposite_Panel.Enabled = false;
                        Submit_Button_Panel.Enabled = false;
                    }
                    else
                    {
                        con = new SqlConnection(Con_Class.cnn);
                        con.Open();
                        string qry = "select * from Customer_Table where AcNumber='" + ToAccountBalancetextbox.Text + "'";
                        cmd = new SqlCommand(qry, con);
                        DataTable dt = new DataTable();
                        SqlDataAdapter oda = new SqlDataAdapter(cmd);
                        oda.Fill(dt);
                        foreach (DataRow dr in dt.Rows)
                        {
                            string Bal = dr["AcBalance"].ToString();
                            Bal = string.Format(CultureInfo.CreateSpecificCulture("hi-IN"), "{0:C}", double.Parse(Bal));
                            ToAccountBal.Text = Bal;
                            ToAcHoldername.Text = dr["Firstname"].ToString();
                            ToLastname.Text = dr["Lastname"].ToString();
                            Logout_Panel.Visible = true;
                            this.OnLoad(e);
                            Logout_Panel.Visible = true;
                        }
                        if (ToAcHoldername.Text == "-")
                        {
                            MessageBox.Show("Account Not Found !", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            ToAccountBalancetextbox.Focus();
                            ToNameDetailPanel.Enabled = false;
                            FromPanel.Enabled = false;
                            FromDetailPanel.Enabled = false;
                            Deposite_Panel.Enabled = false;
                            Submit_Button_Panel.Enabled = false;
                            Logout_Panel.Visible = false;
                            ToAccountBalancetextbox.Clear();
                            ToAccountBalancetextbox.Focus();
                        }
                        else
                        {
                            ToAccountBalancetextbox.Enabled = false;
                            ToNameDetailPanel.Enabled = true;
                            FromPanel.Enabled = true;
                            FromAccountBalancetextbox.Enabled = true;
                            Logout_Panel.Visible = true;
                            FromAccountBalancetextbox.Clear();
                            FromAccountBalancetextbox.Focus();
                        }
                    }
                }
            }
        }

        private void FromAccountBalancetextbox_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt16(FromAccountBalancetextbox.Text.Length) == 15)
            {

                Block_List2();
                if (BlockList2 == FromAccountBalancetextbox.Text)
                {
                    MessageBox.Show("Account Is Blocked Please Contact Nearest Breansh !!", "DeActivated", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    FromAccountBalancetextbox.Clear();
                    FromAccountBalancetextbox.Focus();
                    Logout_Panel.Visible = true;
                    Deposite_Panel.Enabled = false;
                    Submit_Button_Panel.Enabled = false;
                }
                else
                {
                    con = new SqlConnection(Con_Class.cnn);
                    con.Open();
                    string qry = "select * from Customer_Table where AcNumber='" + FromAccountBalancetextbox.Text + "'";
                    cmd = new SqlCommand(qry, con);
                    DataTable dt = new DataTable();
                    SqlDataAdapter oda = new SqlDataAdapter(cmd);
                    oda.Fill(dt);
                    foreach (DataRow dr in dt.Rows)
                    {


                        string Bal = dr["AcBalance"].ToString();
                        Bal = string.Format(CultureInfo.CreateSpecificCulture("hi-IN"), "{0:C}", double.Parse(Bal));
                        FromAccountBal.Text = Bal;
                        FromAcHoldername.Text = dr["Firstname"].ToString();
                        FromLastname.Text = dr["Lastname"].ToString();
                        Logout_Panel.Visible = true;
                        this.OnLoad(e);
                        Logout_Panel.Visible = true;
                    }
                    if (FromAcHoldername.Text == "-")
                    {
                        MessageBox.Show("Account Number Not Found", "Not Found !", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        FromAccountBalancetextbox.Clear();
                        FromAccountBalancetextbox.Focus();
                        Deposite_Panel.Enabled = false;
                        Submit_Button_Panel.Enabled = false;
                        Logout_Panel.Visible = true;

                    }
                    else
                    {

                        FromAccountBalancetextbox.Enabled = false;
                        FromDetailPanel.Enabled = true;
                        FromPanel.Enabled = true;
                        FromDetailPanel.Enabled = true;
                        ToNameDetailPanel.Enabled = true;
                        Deposite_Panel.Enabled = true;
                        Logout_Panel.Visible = true;
                        DebitAmount.Focus();
                        Submit_Button_Panel.Enabled = true;

                    }
                }
            }
        }
        private void ToAccountBalancetextbox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                    this.Close();
                    Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
                    obj.Show();
                
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                text_Captcha.Clear();
                FromAccountBalancetextbox.Clear();
                ToAccountBalancetextbox.Clear();
                DebitAmount.Clear();
                FromAccountBal.Text = "-";
                FromAcHoldername.Text = "-";
                FromLastname.Text = "-";
                ToAccountBal.Text = "-";
                ToAcHoldername.Text = "-";
                ToLastname.Text = "-";
                ToAccountBalancetextbox.Enabled = true;
                ToAccountBalancetextbox.Focus();
                ToNameDetailPanel.Enabled = false;
                Logout_Panel.Visible = false;
                FromPanel.Enabled = false;
                FromDetailPanel.Enabled = false;
                Deposite_Panel.Enabled = false;
                Submit_Button_Panel.Enabled = false;
            }
            
        }

        private void FromAccountBalancetextbox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                if (ToAcHoldername.Text != "-" || DebitAmount.Text != " " || text_Captcha.Text != " ")
                {
                    MessageBox.Show("Please Logout First", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Logout_Panel.Visible = true;
                }
                else
                {

                    this.Close();
                    Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
                    obj.Show();
                }
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                text_Captcha.Clear();
                FromAccountBalancetextbox.Clear();
                ToAccountBalancetextbox.Clear();
                DebitAmount.Clear();
                FromAccountBal.Text = "-";
                FromAcHoldername.Text = "-";
                FromLastname.Text = "-";
                ToAccountBal.Text = "-";
                ToAcHoldername.Text = "-";
                ToLastname.Text = "-";
                ToAccountBalancetextbox.Enabled = true;
                ToAccountBalancetextbox.Focus();
                ToNameDetailPanel.Enabled = false;
                Logout_Panel.Visible = false;
                FromPanel.Enabled = false;
                FromDetailPanel.Enabled = false;
                Deposite_Panel.Enabled = false;
                Submit_Button_Panel.Enabled = false;
            }
           
        }

        private void DebitAmount_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                if (ToAcHoldername.Text != "-" || DebitAmount.Text != " " || text_Captcha.Text != " ")
                {
                    MessageBox.Show("Please Logout First", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Logout_Panel.Visible = true;
                }
                else
                {

                    this.Close();
                    Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
                    obj.Show();
                }
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                text_Captcha.Clear();
                FromAccountBalancetextbox.Clear();
                ToAccountBalancetextbox.Clear();
                DebitAmount.Clear();
                FromAccountBal.Text = "-";
                FromAcHoldername.Text = "-";
                FromLastname.Text = "-";
                ToAccountBal.Text = "-";
                ToAcHoldername.Text = "-";
                ToLastname.Text = "-";
                ToAccountBalancetextbox.Enabled = true;
                ToAccountBalancetextbox.Focus();
                ToNameDetailPanel.Enabled = false;
                Logout_Panel.Visible = false;
                FromPanel.Enabled = false;
                FromDetailPanel.Enabled = false;
                Deposite_Panel.Enabled = false;
                Submit_Button_Panel.Enabled = false;
            }
        }

        private void text_Captcha_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                if (ToAcHoldername.Text != "-" || DebitAmount.Text != " " || text_Captcha.Text != " ")
                {
                    MessageBox.Show("Please Logout First", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Logout_Panel.Visible = true;
                }
                else
                {

                    this.Close();
                    Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
                    obj.Show();
                }
            }
            if (e.KeyCode == Keys.Enter)
            {
                if (DebitAmount.Text == "")
                {
                    MessageBox.Show("Please Enter Transfer Amount", "Blank Record !!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    text_Captcha.Clear();
                    this.OnLoad(e);
                    FromAccountBalancetextbox.Enabled = false;
                    FromDetailPanel.Enabled = true;
                    FromPanel.Enabled = true;
                    FromDetailPanel.Enabled = true;
                    ToNameDetailPanel.Enabled = true;
                    Deposite_Panel.Enabled = true;
                    Logout_Panel.Visible = true;
                    DebitAmount.Focus();
                    Submit_Button_Panel.Enabled = true;
                    DebitAmount.Focus();
                }
                else
                {
                    if (text_Captcha.Text == "")
                    {
                        MessageBox.Show("Please Enter Captcha Code", "Blank Record !!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        text_Captcha.Clear();
                        this.OnLoad(e);
                        FromAccountBalancetextbox.Enabled = false;
                        Logout_Panel.Visible = true;
                        FromDetailPanel.Enabled = true;
                        FromPanel.Enabled = true;
                        FromDetailPanel.Enabled = true;
                        ToNameDetailPanel.Enabled = true;
                        Deposite_Panel.Enabled = true;
                        DebitAmount.Focus();
                        Submit_Button_Panel.Enabled = true;
                        text_Captcha.Focus();
                    }
                    else
                    {
                        if (text_Captcha.Text != Captcha.Text)
                        {
                            MessageBox.Show("Invalid Captcha Code", "Invalid !!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            text_Captcha.Clear();
                            this.OnLoad(e);
                            FromAccountBalancetextbox.Enabled = false;
                            FromDetailPanel.Enabled = true;
                            FromPanel.Enabled = true;
                            FromDetailPanel.Enabled = true;
                            ToNameDetailPanel.Enabled = true;
                            Deposite_Panel.Enabled = true;
                            Submit_Button_Panel.Enabled = true;
                            Logout_Panel.Visible = true;
                            text_Captcha.Focus();

                        }
                        else
                        {
                            Debit_Fund();
                            Credit_Fund();
                            text_Captcha.Clear();
                            FromAccountBalancetextbox.Clear();
                            ToAccountBalancetextbox.Clear();
                            DebitAmount.Clear();
                            FromAccountBal.Text = "-";
                            FromAcHoldername.Text = "-";
                            FromLastname.Text = "-";
                            ToAccountBal.Text = "-";
                            ToAcHoldername.Text = "-";
                            ToLastname.Text = "-";
                            ToAccountBalancetextbox.Focus();
                            Logout_Panel.Visible = true;
                            ToNameDetailPanel.Enabled = false;
                            FromPanel.Enabled = false;
                            FromDetailPanel.Enabled = false;
                            Deposite_Panel.Enabled = false;
                            Submit_Button_Panel.Enabled = false;
                        }
                    }
                }
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                
                text_Captcha.Clear();
                FromAccountBalancetextbox.Clear();
                ToAccountBalancetextbox.Clear();
                DebitAmount.Clear();
                FromAccountBal.Text = "-";
                FromAcHoldername.Text = "-";
                FromLastname.Text = "-";
                ToAccountBal.Text = "-";
                ToAcHoldername.Text = "-";
                ToLastname.Text = "-";
                ToAccountBalancetextbox.Enabled = true;
                ToAccountBalancetextbox.Focus();
                ToNameDetailPanel.Enabled = false;
                FromPanel.Enabled = false;
                Logout_Panel.Visible = false;
                FromDetailPanel.Enabled = false;
                Deposite_Panel.Enabled = false;
                Submit_Button_Panel.Enabled = false;
            }
        }
   }
}
    

