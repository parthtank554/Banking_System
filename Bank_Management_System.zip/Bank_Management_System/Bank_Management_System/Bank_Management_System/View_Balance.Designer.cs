﻿namespace Bank_Management_System
{
    partial class View_Balance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.T_Complete = new System.Windows.Forms.Label();
            this.Pleasewaitlbl = new System.Windows.Forms.Label();
            this.Balance_Panel = new System.Windows.Forms.Panel();
            this.Balance = new System.Windows.Forms.Label();
            this.Check_Panel = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.AcNumber = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.Balance_Panel.SuspendLayout();
            this.Check_Panel.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.label44);
            this.panel1.Controls.Add(this.label45);
            this.panel1.Location = new System.Drawing.Point(48, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(822, 61);
            this.panel1.TabIndex = 15;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.Teal;
            this.label44.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.Chartreuse;
            this.label44.Location = new System.Drawing.Point(122, 9);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(270, 43);
            this.label44.TabIndex = 3;
            this.label44.Text = "GIR BANK  - ";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Teal;
            this.label45.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.OldLace;
            this.label45.Location = new System.Drawing.Point(409, 9);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(331, 43);
            this.label45.TabIndex = 2;
            this.label45.Text = "Balance Inquiry\r\n";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Teal;
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(48, 79);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1226, 541);
            this.panel2.TabIndex = 16;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkCyan;
            this.panel3.Controls.Add(this.T_Complete);
            this.panel3.Controls.Add(this.Pleasewaitlbl);
            this.panel3.Controls.Add(this.Balance_Panel);
            this.panel3.Controls.Add(this.Check_Panel);
            this.panel3.Location = new System.Drawing.Point(69, 42);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1103, 450);
            this.panel3.TabIndex = 17;
            // 
            // T_Complete
            // 
            this.T_Complete.AutoSize = true;
            this.T_Complete.BackColor = System.Drawing.Color.Teal;
            this.T_Complete.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.T_Complete.ForeColor = System.Drawing.Color.OldLace;
            this.T_Complete.Location = new System.Drawing.Point(295, 178);
            this.T_Complete.Name = "T_Complete";
            this.T_Complete.Size = new System.Drawing.Size(554, 43);
            this.T_Complete.TabIndex = 5;
            this.T_Complete.Text = "Trasaction Complete.............";
            // 
            // Pleasewaitlbl
            // 
            this.Pleasewaitlbl.AutoSize = true;
            this.Pleasewaitlbl.BackColor = System.Drawing.Color.Teal;
            this.Pleasewaitlbl.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pleasewaitlbl.ForeColor = System.Drawing.Color.OldLace;
            this.Pleasewaitlbl.Location = new System.Drawing.Point(391, 272);
            this.Pleasewaitlbl.Name = "Pleasewaitlbl";
            this.Pleasewaitlbl.Size = new System.Drawing.Size(294, 43);
            this.Pleasewaitlbl.TabIndex = 5;
            this.Pleasewaitlbl.Text = "Please Wait.....";
            // 
            // Balance_Panel
            // 
            this.Balance_Panel.BackColor = System.Drawing.Color.Teal;
            this.Balance_Panel.Controls.Add(this.Balance);
            this.Balance_Panel.Location = new System.Drawing.Point(414, 246);
            this.Balance_Panel.Name = "Balance_Panel";
            this.Balance_Panel.Size = new System.Drawing.Size(339, 104);
            this.Balance_Panel.TabIndex = 19;
            // 
            // Balance
            // 
            this.Balance.AutoSize = true;
            this.Balance.BackColor = System.Drawing.Color.Teal;
            this.Balance.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Balance.ForeColor = System.Drawing.Color.OldLace;
            this.Balance.Location = new System.Drawing.Point(17, 27);
            this.Balance.Name = "Balance";
            this.Balance.Size = new System.Drawing.Size(31, 43);
            this.Balance.TabIndex = 5;
            this.Balance.Text = "-\r\n";
            // 
            // Check_Panel
            // 
            this.Check_Panel.BackColor = System.Drawing.Color.Teal;
            this.Check_Panel.Controls.Add(this.label1);
            this.Check_Panel.Location = new System.Drawing.Point(22, 60);
            this.Check_Panel.Name = "Check_Panel";
            this.Check_Panel.Size = new System.Drawing.Size(1065, 104);
            this.Check_Panel.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Teal;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.OldLace;
            this.label1.Location = new System.Drawing.Point(284, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(460, 43);
            this.label1.TabIndex = 4;
            this.label1.Text = "Your Account Balamce";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Teal;
            this.panel5.Controls.Add(this.AcNumber);
            this.panel5.Location = new System.Drawing.Point(876, 12);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(398, 61);
            this.panel5.TabIndex = 16;
            // 
            // AcNumber
            // 
            this.AcNumber.AutoSize = true;
            this.AcNumber.BackColor = System.Drawing.Color.Teal;
            this.AcNumber.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AcNumber.ForeColor = System.Drawing.Color.OldLace;
            this.AcNumber.Location = new System.Drawing.Point(3, 9);
            this.AcNumber.Name = "AcNumber";
            this.AcNumber.Size = new System.Drawing.Size(31, 43);
            this.AcNumber.TabIndex = 2;
            this.AcNumber.Text = "-";
            // 
            // timer1
            // 
            this.timer1.Interval = 50;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // View_Balance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(1333, 645);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "View_Balance";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "View_Balance";
            this.Load += new System.EventHandler(this.View_Balance_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.Balance_Panel.ResumeLayout(false);
            this.Balance_Panel.PerformLayout();
            this.Check_Panel.ResumeLayout(false);
            this.Check_Panel.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel Balance_Panel;
        private System.Windows.Forms.Label Balance;
        private System.Windows.Forms.Panel Check_Panel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel5;
        public System.Windows.Forms.Label AcNumber;
        private System.Windows.Forms.Label Pleasewaitlbl;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label T_Complete;
    }
}