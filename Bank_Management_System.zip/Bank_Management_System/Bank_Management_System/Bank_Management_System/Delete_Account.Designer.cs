﻿namespace Bank_Management_System
{
    partial class Delete_Account
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.withdrawalpanel = new System.Windows.Forms.Panel();
            this.Remove_Panel = new System.Windows.Forms.Panel();
            this.resetbuttonpanel = new System.Windows.Forms.Panel();
            this.AcDetailpanel = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.Lastname = new System.Windows.Forms.Label();
            this.AcHoldername = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.AccountBal = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.CheckAcBalance = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Remove_Ac_Panel = new System.Windows.Forms.Panel();
            this.withdrawalbuttonpanel1 = new System.Windows.Forms.Panel();
            this.Logout_Ac_Panel = new System.Windows.Forms.Panel();
            this.Exit_Ac_Panel = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.Withdrawal_Ac_Panel = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Temp = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel10.SuspendLayout();
            this.withdrawalpanel.SuspendLayout();
            this.Remove_Panel.SuspendLayout();
            this.resetbuttonpanel.SuspendLayout();
            this.AcDetailpanel.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.Remove_Ac_Panel.SuspendLayout();
            this.withdrawalbuttonpanel1.SuspendLayout();
            this.Logout_Ac_Panel.SuspendLayout();
            this.Exit_Ac_Panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.label44);
            this.panel1.Controls.Add(this.label45);
            this.panel1.Location = new System.Drawing.Point(538, 193);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(948, 61);
            this.panel1.TabIndex = 12;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.Teal;
            this.label44.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.Chartreuse;
            this.label44.Location = new System.Drawing.Point(122, 9);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(270, 43);
            this.label44.TabIndex = 3;
            this.label44.Text = "GIR BANK  - ";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Teal;
            this.label45.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.OldLace;
            this.label45.Location = new System.Drawing.Point(398, 9);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(343, 43);
            this.label45.TabIndex = 2;
            this.label45.Text = "Remove Account";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Teal;
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(165, 275);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1641, 687);
            this.panel2.TabIndex = 13;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkCyan;
            this.panel4.Controls.Add(this.panel10);
            this.panel4.Controls.Add(this.withdrawalpanel);
            this.panel4.Controls.Add(this.Remove_Panel);
            this.panel4.Controls.Add(this.resetbuttonpanel);
            this.panel4.Controls.Add(this.AcDetailpanel);
            this.panel4.Location = new System.Drawing.Point(93, 168);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1479, 462);
            this.panel4.TabIndex = 13;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Teal;
            this.panel10.Controls.Add(this.Exit_Ac_Panel);
            this.panel10.Location = new System.Drawing.Point(780, 327);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(607, 93);
            this.panel10.TabIndex = 46;
            // 
            // withdrawalpanel
            // 
            this.withdrawalpanel.BackColor = System.Drawing.Color.Teal;
            this.withdrawalpanel.Controls.Add(this.withdrawalbuttonpanel1);
            this.withdrawalpanel.Location = new System.Drawing.Point(780, 164);
            this.withdrawalpanel.Name = "withdrawalpanel";
            this.withdrawalpanel.Size = new System.Drawing.Size(607, 94);
            this.withdrawalpanel.TabIndex = 45;
            // 
            // Remove_Panel
            // 
            this.Remove_Panel.BackColor = System.Drawing.Color.Teal;
            this.Remove_Panel.Controls.Add(this.Remove_Ac_Panel);
            this.Remove_Panel.Location = new System.Drawing.Point(24, 164);
            this.Remove_Panel.Name = "Remove_Panel";
            this.Remove_Panel.Size = new System.Drawing.Size(607, 94);
            this.Remove_Panel.TabIndex = 44;
            // 
            // resetbuttonpanel
            // 
            this.resetbuttonpanel.BackColor = System.Drawing.Color.Teal;
            this.resetbuttonpanel.Controls.Add(this.Logout_Ac_Panel);
            this.resetbuttonpanel.Location = new System.Drawing.Point(24, 327);
            this.resetbuttonpanel.Name = "resetbuttonpanel";
            this.resetbuttonpanel.Size = new System.Drawing.Size(607, 93);
            this.resetbuttonpanel.TabIndex = 14;
            // 
            // AcDetailpanel
            // 
            this.AcDetailpanel.BackColor = System.Drawing.Color.Teal;
            this.AcDetailpanel.Controls.Add(this.panel6);
            this.AcDetailpanel.Controls.Add(this.panel5);
            this.AcDetailpanel.Controls.Add(this.label5);
            this.AcDetailpanel.Controls.Add(this.label2);
            this.AcDetailpanel.Location = new System.Drawing.Point(24, 39);
            this.AcDetailpanel.Name = "AcDetailpanel";
            this.AcDetailpanel.Size = new System.Drawing.Size(1414, 86);
            this.AcDetailpanel.TabIndex = 13;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DarkCyan;
            this.panel6.Controls.Add(this.Lastname);
            this.panel6.Controls.Add(this.AcHoldername);
            this.panel6.Location = new System.Drawing.Point(353, 14);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(397, 56);
            this.panel6.TabIndex = 25;
            // 
            // Lastname
            // 
            this.Lastname.AutoSize = true;
            this.Lastname.BackColor = System.Drawing.Color.DarkCyan;
            this.Lastname.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lastname.ForeColor = System.Drawing.Color.Transparent;
            this.Lastname.Location = new System.Drawing.Point(163, 14);
            this.Lastname.Name = "Lastname";
            this.Lastname.Size = new System.Drawing.Size(25, 33);
            this.Lastname.TabIndex = 25;
            this.Lastname.Text = "-";
            // 
            // AcHoldername
            // 
            this.AcHoldername.AutoSize = true;
            this.AcHoldername.BackColor = System.Drawing.Color.DarkCyan;
            this.AcHoldername.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AcHoldername.ForeColor = System.Drawing.Color.Transparent;
            this.AcHoldername.Location = new System.Drawing.Point(17, 14);
            this.AcHoldername.Name = "AcHoldername";
            this.AcHoldername.Size = new System.Drawing.Size(25, 33);
            this.AcHoldername.TabIndex = 22;
            this.AcHoldername.Text = "-";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkCyan;
            this.panel5.Controls.Add(this.AccountBal);
            this.panel5.Location = new System.Drawing.Point(1063, 14);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(237, 56);
            this.panel5.TabIndex = 13;
            // 
            // AccountBal
            // 
            this.AccountBal.AutoSize = true;
            this.AccountBal.BackColor = System.Drawing.Color.DarkCyan;
            this.AccountBal.Font = new System.Drawing.Font("Calisto MT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AccountBal.ForeColor = System.Drawing.Color.Transparent;
            this.AccountBal.Location = new System.Drawing.Point(13, 9);
            this.AccountBal.Name = "AccountBal";
            this.AccountBal.Size = new System.Drawing.Size(26, 37);
            this.AccountBal.TabIndex = 24;
            this.AccountBal.Text = "-";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Teal;
            this.label5.Font = new System.Drawing.Font("Century Schoolbook", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.OldLace;
            this.label5.Location = new System.Drawing.Point(796, 28);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(242, 30);
            this.label5.TabIndex = 23;
            this.label5.Text = "Account Balance : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Teal;
            this.label2.Font = new System.Drawing.Font("Century Schoolbook", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.OldLace;
            this.label2.Location = new System.Drawing.Point(40, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(307, 30);
            this.label2.TabIndex = 21;
            this.label2.Text = "Account Holder Name : ";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkCyan;
            this.panel3.Controls.Add(this.CheckAcBalance);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(274, 36);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1094, 85);
            this.panel3.TabIndex = 12;
            // 
            // CheckAcBalance
            // 
            this.CheckAcBalance.BackColor = System.Drawing.Color.CadetBlue;
            this.CheckAcBalance.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CheckAcBalance.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckAcBalance.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.CheckAcBalance.Location = new System.Drawing.Point(537, 18);
            this.CheckAcBalance.MaxLength = 15;
            this.CheckAcBalance.Name = "CheckAcBalance";
            this.CheckAcBalance.Size = new System.Drawing.Size(510, 43);
            this.CheckAcBalance.TabIndex = 20;
            this.CheckAcBalance.TextChanged += new System.EventHandler(this.CheckAcBalance_TextChanged);
            this.CheckAcBalance.KeyDown += new System.Windows.Forms.KeyEventHandler(this.CheckAcBalance_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkCyan;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.OldLace;
            this.label1.Location = new System.Drawing.Point(34, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(497, 43);
            this.label1.TabIndex = 4;
            this.label1.Text = "Enter Account Number : ";
            // 
            // Remove_Ac_Panel
            // 
            this.Remove_Ac_Panel.BackColor = System.Drawing.Color.Red;
            this.Remove_Ac_Panel.Controls.Add(this.label3);
            this.Remove_Ac_Panel.Location = new System.Drawing.Point(45, 18);
            this.Remove_Ac_Panel.Name = "Remove_Ac_Panel";
            this.Remove_Ac_Panel.Size = new System.Drawing.Size(513, 56);
            this.Remove_Ac_Panel.TabIndex = 0;
            // 
            // withdrawalbuttonpanel1
            // 
            this.withdrawalbuttonpanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.withdrawalbuttonpanel1.Controls.Add(this.Withdrawal_Ac_Panel);
            this.withdrawalbuttonpanel1.Location = new System.Drawing.Point(45, 18);
            this.withdrawalbuttonpanel1.Name = "withdrawalbuttonpanel1";
            this.withdrawalbuttonpanel1.Size = new System.Drawing.Size(513, 56);
            this.withdrawalbuttonpanel1.TabIndex = 1;
            // 
            // Logout_Ac_Panel
            // 
            this.Logout_Ac_Panel.BackColor = System.Drawing.Color.Snow;
            this.Logout_Ac_Panel.Controls.Add(this.label6);
            this.Logout_Ac_Panel.Location = new System.Drawing.Point(45, 23);
            this.Logout_Ac_Panel.Name = "Logout_Ac_Panel";
            this.Logout_Ac_Panel.Size = new System.Drawing.Size(513, 56);
            this.Logout_Ac_Panel.TabIndex = 1;
            // 
            // Exit_Ac_Panel
            // 
            this.Exit_Ac_Panel.BackColor = System.Drawing.Color.White;
            this.Exit_Ac_Panel.Controls.Add(this.label7);
            this.Exit_Ac_Panel.Location = new System.Drawing.Point(45, 23);
            this.Exit_Ac_Panel.Name = "Exit_Ac_Panel";
            this.Exit_Ac_Panel.Size = new System.Drawing.Size(513, 56);
            this.Exit_Ac_Panel.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Red;
            this.label3.Font = new System.Drawing.Font("Century Schoolbook", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.OldLace;
            this.label3.Location = new System.Drawing.Point(107, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(282, 30);
            this.label3.TabIndex = 26;
            this.label3.Text = "Remove A/c : (Ctrl+D)";
            // 
            // Withdrawal_Ac_Panel
            // 
            this.Withdrawal_Ac_Panel.AutoSize = true;
            this.Withdrawal_Ac_Panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Withdrawal_Ac_Panel.Font = new System.Drawing.Font("Century Schoolbook", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Withdrawal_Ac_Panel.ForeColor = System.Drawing.Color.OldLace;
            this.Withdrawal_Ac_Panel.Location = new System.Drawing.Point(76, 14);
            this.Withdrawal_Ac_Panel.Name = "Withdrawal_Ac_Panel";
            this.Withdrawal_Ac_Panel.Size = new System.Drawing.Size(314, 30);
            this.Withdrawal_Ac_Panel.TabIndex = 27;
            this.Withdrawal_Ac_Panel.Text = "Debit Amount : (Ctrl+W)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Century Schoolbook", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(137, 15);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(224, 30);
            this.label6.TabIndex = 27;
            this.label6.Text = "Logout : (Ctrl+R)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Century Schoolbook", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(153, 15);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(185, 30);
            this.label7.TabIndex = 28;
            this.label7.Text = "Exit : (Ctrl+X)";
            // 
            // Temp
            // 
            this.Temp.BackColor = System.Drawing.Color.CadetBlue;
            this.Temp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Temp.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Temp.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.Temp.Location = new System.Drawing.Point(879, 1062);
            this.Temp.MaxLength = 15;
            this.Temp.Name = "Temp";
            this.Temp.Size = new System.Drawing.Size(10, 43);
            this.Temp.TabIndex = 47;
            this.Temp.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Temp_KeyDown);
            // 
            // Delete_Account
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(1869, 1066);
            this.Controls.Add(this.Temp);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Delete_Account";
            this.Text = "Delete_Account";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Delete_Account_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.withdrawalpanel.ResumeLayout(false);
            this.Remove_Panel.ResumeLayout(false);
            this.resetbuttonpanel.ResumeLayout(false);
            this.AcDetailpanel.ResumeLayout(false);
            this.AcDetailpanel.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.Remove_Ac_Panel.ResumeLayout(false);
            this.Remove_Ac_Panel.PerformLayout();
            this.withdrawalbuttonpanel1.ResumeLayout(false);
            this.withdrawalbuttonpanel1.PerformLayout();
            this.Logout_Ac_Panel.ResumeLayout(false);
            this.Logout_Ac_Panel.PerformLayout();
            this.Exit_Ac_Panel.ResumeLayout(false);
            this.Exit_Ac_Panel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        public System.Windows.Forms.TextBox CheckAcBalance;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel AcDetailpanel;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label Lastname;
        private System.Windows.Forms.Label AcHoldername;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label AccountBal;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel resetbuttonpanel;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel Remove_Panel;
        private System.Windows.Forms.Panel withdrawalpanel;
        private System.Windows.Forms.Panel Exit_Ac_Panel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel withdrawalbuttonpanel1;
        private System.Windows.Forms.Label Withdrawal_Ac_Panel;
        private System.Windows.Forms.Panel Remove_Ac_Panel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel Logout_Ac_Panel;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.TextBox Temp;
    }
}