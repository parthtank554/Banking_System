﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank_Management_System
{
    public partial class Trasaction_Dashbord : Form
    {
        public Trasaction_Dashbord()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Hide();
            View_Balance obj = new View_Balance();
            obj.AcNumber.Text = Acnumber.Text;
            obj.Show();
        }

        private void Trasaction_Dashbord_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Cash_Deposite obj = new Cash_Deposite();
            obj.AcNumber.Text = Acnumber.Text;
            obj.Show();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Debit_Cash obj = new Debit_Cash();
            obj.AcNumber.Text = Acnumber.Text;
            obj.Show();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            this.Close();
            Reset_Atm_Pin obj = new Reset_Atm_Pin();
            obj.Show();
        }
    }
}
