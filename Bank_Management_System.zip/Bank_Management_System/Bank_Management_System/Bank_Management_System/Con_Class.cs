﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient; 

namespace Bank_Management_System
{
    class Con_Class
    {
        // Updated connection string for SQL Server
        public static string cnn = "Data Source=(LocalDB)\\MSSQLLocalDB;Initial Catalog=Bank_Managment_System;Integrated Security=True";
    }
}
