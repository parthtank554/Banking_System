﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;
namespace Bank_Management_System
{
    public partial class Form1 : Form
    {
        SqlConnection con;
        SqlCommand cmd,cmd2;
        SqlDataAdapter da,oda;
        DataTable dt,dt2;
        string RandomPass = "", MainPass = "", Email = "", textuid = "",pass = "";
        public Form1()
        {
            InitializeComponent();
        }
        public void Getuidandpass()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();

            cmd = new SqlCommand("select * from Employee_Ragistration where EmailId='" + txtusername.Text + "'", con);
            da = new SqlDataAdapter(cmd);

            dt = new DataTable();
            da.Fill(dt);

           foreach(DataRow dr in dt.Rows)
           {
               textuid = dr["EmailId"].ToString();
               MainPass = dr["ps"].ToString();
           }
            
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("  Are You Sure Want Exit Application  ", "Exit Application", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            txtusername.Text = "";
                txtpassword.Text = "";
            OTP_PANEL.Visible = false;
            Random rand = new Random();
            int num = rand.Next(6, 7);
            int total = 0;
            string captcha = "";

            do
            {
                int chr = rand.Next(100, 123);
                if ((chr >= 48 && chr <= 57) || (chr >= 65 && chr <= 90) || (chr >= 97 && chr <= 122))
                {
                    captcha = captcha + (char)chr;
                    total++;
                    if (total == num)
                        break;
                    {

                    }
                }
            } while (true);
            Captcha.Text = captcha;

        }
        public void RandomPassword()
        {

            con = new SqlConnection(Con_Class.cnn);
            con.Open();
            string qry = "select * from Employee_Password where pass='" + txtpassword.Text + "'";
            cmd = new SqlCommand(qry, con);
            DataTable dt = new DataTable();
            SqlDataAdapter oda = new SqlDataAdapter(cmd);
            oda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                RandomPass = dr["pass"].ToString();
            }
        }

        public void MainPassword()
        {
            string qry = "select * from Employee_Ragistration where ps='" + txtpassword.Text + "'";
            cmd = new SqlCommand(qry, con);
            DataTable dt = new DataTable();
            SqlDataAdapter oda = new SqlDataAdapter(cmd);
            oda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                MainPass = dr["ps"].ToString();
            }
        }
        public void UserId()
        {
            string qry = "select * from Employee_Ragistration where EmailId='" + txtusername.Text + "'";
            cmd = new SqlCommand(qry, con);
            DataTable dt = new DataTable();
            SqlDataAdapter oda = new SqlDataAdapter(cmd);
            oda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                Email = dr["EmailId"].ToString();
            }
        }

        private void Btn_Clear_Click(object sender, EventArgs e)
        {
            txtusername.Clear();
            txtpassword.Clear();
            txtusername.Focus();
        }




        public void getpass()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();

            cmd = new SqlCommand("select * from Emp_Otp where OTP='" + OTP.Text + "'", con);
            oda = new SqlDataAdapter(cmd);
            dt2 = new DataTable();
            oda.Fill(dt2);
            foreach (DataRow dr in dt2.Rows)
            {
                pass = dr["OTP"].ToString();
            }
        }



        private void checkshowhidepass_CheckedChanged(object sender, EventArgs e)
        {
            if (checkshowhidepass.Checked == true)
            {
                txtpassword.UseSystemPasswordChar = false;
            }
            else if (checkshowhidepass.Checked == false)
            {
                txtpassword.UseSystemPasswordChar = true;
            }
        }

        private void New_User_Link_Click(object sender, EventArgs e)
        {
            New_User_Ragistration_From obj = new New_User_Ragistration_From();
            this.Hide();
            obj.Show();
        }

        private void Reset_Password_Link_Click(object sender, EventArgs e)
        {
            this.Hide();
            Reset_Password_From obj = new Reset_Password_From();
            obj.Show();
        }
        private void label6_Click(object sender, EventArgs e)
        {
            this.OnLoad(e);
        }

        private void text_Captcha_TextChanged(object sender, EventArgs e)
        {

            if (Convert.ToInt32(text_Captcha.Text.Length) == 6)
            {

                if (txtusername.Text == "")
                {
                    MessageBox.Show("Enter Valid User Id ! ", "Blank Record", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    txtusername.Focus();
                    this.OnLoad(e);
                }
                else
                {
                    if (txtpassword.Text == "")
                    {
                        MessageBox.Show("Enter Valid Password ! ", "Blank Record", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        txtusername.Focus();
                        this.OnLoad(e);
                    }
                    else
                    {
                        if (txtusername.Text == "" || txtpassword.Text == "")
                        {
                            MessageBox.Show("Enter Valid UID And Password", "Blank Record", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            this.OnLoad(e);
                            txtusername.Focus();
                        }
                        else
                        {
                            if (text_Captcha.Text == Captcha.Text)
                            {
                                RandomPassword();
                                MainPassword();
                                UserId();
                                if (txtpassword.Text == RandomPass)
                                {
                                    if (txtusername.Text == Email)
                                    {

                                        this.Hide();
                                        Reset_Password_From obj = new Reset_Password_From();
                                        obj.Show();
                                    }
                                    else
                                    {
                                        MessageBox.Show("Incorrect Username !!", "Incorrect", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        this.OnLoad(e);
                                    }
                                }
                                else
                                {

                                    if (txtpassword.Text == MainPass)
                                    {
                                        if (txtusername.Text == Email)
                                        {
                                            Random rm = new Random();
                                            int ran = rm.Next(1000,9000);
                                            string pass = ran.ToString();

                                            MailMessage mail = new MailMessage();
                                            string from = "#";
                                            mail.Subject = "Gir Bank User Varification...!";
                                            mail.From = new MailAddress(from);
                                            mail.Body = "Hiii ! Dear Applicant Your Varification Code Is : " + pass;
                                            mail.To.Add(new MailAddress(txtusername.Text));

                                            SmtpClient smtp = new SmtpClient();
                                            smtp.Host = "smtp.gmail.com";
                                            smtp.Port = 587;
                                            smtp.UseDefaultCredentials = false;
                                            smtp.EnableSsl = true;

                                            NetworkCredential nec = new NetworkCredential(from, "#");

                                            smtp.Credentials = nec;

                                            smtp.Send(mail);

                                            cmd2 = new SqlCommand("insert into Emp_Otp values('" + pass + "')", con);
                                            int res = cmd2.ExecuteNonQuery();
                                            if (res > 0)
                                            {

                                                MessageBox.Show("Check Your Email-Id Enter Varification Code...", "OTP", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                                txtusername.Enabled = false;
                                                txtpassword.Enabled = false;
                                                text_Captcha.Enabled = false;
                                                Reset_Label.Visible = false;
                                                OTP_PANEL.Visible = true;
                                                OTP.Focus();
                                            }
                                            else
                                            {
                                                MessageBox.Show("Error");
                                            }
                                           

                                        }
                                            
                                        else
                                        {
                                            MessageBox.Show("Incorrect Username !!", "Incorrect", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                            text_Captcha.Clear();
                                            this.OnLoad(e);
                                        }
                                    }
                                    else
                                    {
                                        MessageBox.Show("Incorrect Password !!", "Incorrect", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        text_Captcha.Clear();
                                        this.OnLoad(e);
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show("Incorrect Captcha Code ! ", "Invalid Captcha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                text_Captcha.Clear();
                                text_Captcha.Focus();
                                this.OnLoad(e);

                            }

                        }
                    }
                }
            }
        }

        private void label6_Click_1(object sender, EventArgs e)
        {

        }

        private void txtpassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                txtusername.Text = "";
                txtpassword.Text = "";
                text_Captcha.Text = "";
                txtusername.Focus();
            }
        }

        private void txtusername_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                txtusername.Text = "";
                txtpassword.Text = "";
                text_Captcha.Text = "";
                txtusername.Focus();
            }
        }

        private void label7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Gir_Bank_Atm obj = new Gir_Bank_Atm();
            obj.Show();
        }

        private void txtusername_TextChanged(object sender, EventArgs e)
        {

        }

        private void OTP_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt32(OTP.Text.Length) == 4)
            {
                getpass();
                OTP.Enabled = false;
                if (OTP.Text == pass)
                {
                    MessageBox.Show("Welcome");
                    this.Hide();
                    Gie_Bank_Dashbord d = new Gie_Bank_Dashbord();
                    d.Show();
                }
                else
                {
                    MessageBox.Show("Invalid");
                }
            }
 
        }
    }
}

