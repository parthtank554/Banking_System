﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Globalization;
namespace Bank_Management_System
{
    public partial class Check_Account_Balance : Form
    {
        SqlConnection con;
        SqlCommand cmd,comm;
        SqlDataAdapter da;
        string BlockList = "";
        DataSet ds = new DataSet();
        public Check_Account_Balance()
        {
            InitializeComponent();
        }

        private void Check_Account_Balance_Load(object sender, EventArgs e)
        {
            Clear_Panel.Visible = false;
        }
        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
            this.Close();
            obj.Show();
        }
        public void Block_List()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();
            string qry = "select * from Blocke_Ac where BalockAcNumber='" + CheckAcBalance.Text + "'";
            comm = new SqlCommand(qry, con);
            DataTable dt = new DataTable();
            SqlDataAdapter oda = new SqlDataAdapter(comm);
            oda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                BlockList = dr["BalockAcNumber"].ToString();

            }
        }

        private void CheckAcBalance_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt16(CheckAcBalance.Text.Length) == 15 )
            {
                if (CheckAcBalance.Text == "")
                {
                    MessageBox.Show("Please Enter Account Number", "Blank Record", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    Clear_Panel.Visible = false;
                }
                else
                {
                    Block_List();
                     if (BlockList == CheckAcBalance.Text)
                     {
                         MessageBox.Show("Account Is Blocked Please Contact Nearest Breansh !!", "DeActivated", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            CheckAcBalance.Clear();
                            Lastname.Text = "-";
                            AcHoldername.Text = "-";
                            AccountBal.Text = "-";
                            CheckAcBalance.Enabled = true;
                            Clear_Panel.Visible = false; ;
                            CheckAcBalance.Focus();
                     }
                     else
                     {
                        CheckAcBalance.Enabled = false;
                        con = new SqlConnection(Con_Class.cnn);
                        con.Open();
                        string qry = "select * from Customer_Table where AcNumber='" + CheckAcBalance.Text + "'";
                        cmd = new SqlCommand(qry, con);
                        DataTable dt = new DataTable();
                        SqlDataAdapter oda = new SqlDataAdapter(cmd);
                        oda.Fill(dt);
                        foreach (DataRow dr in dt.Rows)
                        {
                            string Bal = dr["AcBalance"].ToString();
                            Bal = string.Format(CultureInfo.CreateSpecificCulture("hi-IN"), "{0:C}", double.Parse(Bal));
                            AccountBal.Text = Bal;
                            AcHoldername.Text = dr["Firstname"].ToString();
                            Lastname.Text = dr["Lastname"].ToString();
                            Clear_Panel.Visible = true;
                        }
                        Temper.Focus();
                        if (AcHoldername.Text == "-")
                        {
                            MessageBox.Show("Account Number Not Found...!", "404 Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            CheckAcBalance.Clear();
                            CheckAcBalance.Enabled = true;
                            Clear_Panel.Visible = false;
                            CheckAcBalance.Focus();
                        }
                       
                    }
                }
            }
        }
        

        private void CheckAcBalance_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122)
            {
                e.Handled = true;
            }
        }

        private void Temper_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                if (AcHoldername.Text != "-")
                {
                    MessageBox.Show("Please Logout First", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Clear_Panel.Visible = true;
                }
                else
                {

                    this.Close();
                    Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
                    obj.Show();
                }
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                CheckAcBalance.Clear();
                Lastname.Text = "-";
                AcHoldername.Text = "-";
                AccountBal.Text = "-";
                CheckAcBalance.Enabled = true;
                Clear_Panel.Visible = false; ;
                CheckAcBalance.Focus();
            }
        }

        private void CheckAcBalance_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                    this.Close();
                    Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
                    obj.Show();
                
            }
        }
    }
}
