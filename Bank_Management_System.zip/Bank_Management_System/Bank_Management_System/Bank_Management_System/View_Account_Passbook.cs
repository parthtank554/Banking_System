﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Globalization;

namespace Bank_Management_System
{
    public partial class View_Account_Passbook : Form
    {
        SqlConnection con;
        SqlCommand cmd, comm;
        SqlDataAdapter da;
        DataSet ds = new DataSet();
        string BlockList = "";
        public View_Account_Passbook()
        {
            InitializeComponent();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
        
        public void Block_List()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();
            string qry = "select * from Blocke_Ac where BalockAcNumber='" + CheckAcBalance.Text + "'";
            comm = new SqlCommand(qry, con);
            DataTable dt = new DataTable();
            SqlDataAdapter oda = new SqlDataAdapter(comm);
            oda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                BlockList = dr["BalockAcNumber"].ToString();

            }
        }
        private void View_Account_Passbook_Load(object sender, EventArgs e)
        {
            CheckAcBalance.Focus();
            DetailPanel.Visible = false;
            Girbanklbl.Visible = false;
            CheckAcBalance.Focus();
        }

        private void CheckAcBalance_TextChanged(object sender, EventArgs e)
        {

            if (Convert.ToInt16(CheckAcBalance.Text.Length) == 15)
            {

                Block_List();
                if (BlockList == CheckAcBalance.Text)
                {
                    MessageBox.Show("Account Is Blocked Please Try Another Account !! ", "DeActivated", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    CheckAcBalance.Clear();
                    CheckAcBalance.Enabled = true;
                    CheckAcBalance.Focus();
                    DetailPanel.Visible = false;
                    this.OnLoad(e);
                }
                else
                {
                    CheckAcBalance.Enabled = false;
                    //Mainpanel.Visible = false;
                    con = new SqlConnection(Con_Class.cnn);
                    con.Open();
                    string qry = "select * from Customer_Table where AcNumber='" + CheckAcBalance.Text + "'";
                    cmd = new SqlCommand(qry, con);
                    DataTable dt = new DataTable();
                    SqlDataAdapter oda = new SqlDataAdapter(cmd);
                    oda.Fill(dt);
                    foreach (DataRow dr in dt.Rows)
                    {
                        DetailPanel.Visible = true;
                        Girbanklbl.Visible = true;
                        textBox1.Focus();
                        string Bal = dr["AcBalance"].ToString();
                        Bal = string.Format(CultureInfo.CreateSpecificCulture("hi-IN"), "{0:C}", double.Parse(Bal));
                        Firstname.Text = dr["Firstname"].ToString();
                        Middlename.Text = dr["Middlename"].ToString();
                        Lastname.Text = dr["Lastname"].ToString();
                        DateOfBirth.Text = dr["Dob"].ToString();
                        Gender.Text = dr["Gender"].ToString();
                        MoNum.Text = dr["MobileNumber"].ToString();
                        Email.Text = dr["EmailId"].ToString();
                        Taluka.Text = dr["Taluka"].ToString();
                        VTaluka.Text = dr["City"].ToString();
                        Contry.Text = dr["Contry"].ToString();
                        Distric.Text = dr["Distric"].ToString();
                        Pincode.Text = dr["Pincode"].ToString();
                        AcType.Text = dr["AcType"].ToString();
                        AcNumber.Text = dr["AcNumber"].ToString();
                        Accountbalance.Text = Bal;
                        Pancard.Text = dr["PanNumber"].ToString();
                        Occupation.Text = dr["Occupation"].ToString();
                    }
                    if (AcNumber.Text == "-")
                    {
                        MessageBox.Show("Account Number Not Found Please Try Again....?","Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        CheckAcBalance.Enabled = true;
                        CheckAcBalance.Clear();
                        CheckAcBalance.Focus();
                    }
                   
                }
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
               
                DetailPanel.Visible = false;
                Girbanklbl.Visible = false;
                CheckAcBalance.Enabled = true;
                CheckAcBalance.Clear();
                CheckAcBalance.Focus();
               
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                if (Lastname.Text != "-")
                {
                    MessageBox.Show("Please Logout First You Can Not Exit Before Logout Please Logout First...!", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }

            }
            
        }

        private void CheckAcBalance_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                this.Close();
                Next_Page_Dashbord obj = new Next_Page_Dashbord();
                obj.Show();
            }
        }
    }
}
