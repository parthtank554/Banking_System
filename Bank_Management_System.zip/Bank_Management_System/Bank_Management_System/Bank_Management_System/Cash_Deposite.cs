﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Bank_Management_System
{
    public partial class Cash_Deposite : Form
    {
        SqlCommand cmd, cmd2,cmd3,History;
        SqlConnection con;
        SqlDataAdapter oda;
        DataTable dt;
        string bal = "", Acnum = "",AcBalance = "",AcHolderName = "";
        int i = 0,a=0;
        public Cash_Deposite()
        {
            InitializeComponent();
        }
        public void getAcNumber()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();
            cmd = new SqlCommand("select * from Debit_Card_Apply where DebitNumber='" + AcNumber.Text + "'", con);
            oda = new SqlDataAdapter(cmd);
            dt = new DataTable();
            oda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                Acnum = dr["AcNumber"].ToString();
            }
        }
        private void Cash_Deposite_Load(object sender, EventArgs e)
        {
            timer1.Start();
            Main_Panel.Visible = false;
            Pleasewaitlbl.Visible = false;
            Cancel_Panel.Visible = false;
            T_Complete.Visible = false;
            Trasaction_Proceed.Visible = false;
            getAcNumber();
        }
        public void debit_amount()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();
            string qry = "select * from Customer_Table where AcNumber='" + Acnum + "'";
            cmd2 = new SqlCommand(qry, con);
            DataTable dt2 = new DataTable();
            SqlDataAdapter oda2 = new SqlDataAdapter(cmd2);
            oda2.Fill(dt2);
            foreach (DataRow dr in dt2.Rows)
            {
                AcHolderName = dr["Firstname"].ToString();
                int Balanece = Convert.ToInt32(dr["AcBalance"].ToString());
                int UpdateBal = Balanece + Convert.ToInt32(CheckAcBalance.Text);
                AcBalance = UpdateBal.ToString();
            }
            string Date = DateTime.Now.ToLongDateString();
            string Time = DateTime.Now.ToLongTimeString();
            string Db = "Credit";
            History = new SqlCommand("insert into Ac_History values('" + Date + "','" + Time + "','" + AcHolderName + "','" + Acnum + "','" + Db + "','" + CheckAcBalance.Text + "' )", con);
            History.ExecuteNonQuery();
            cmd3 = new SqlCommand("update Customer_Table set AcBalance='" + AcBalance + "' where  AcNumber='" + Acnum + "'", con);
            cmd2.ExecuteNonQuery();
            int res = cmd3.ExecuteNonQuery();
            if (res > 0)
            {
                timer1.Start();
            }
            else
            {
                MessageBox.Show("Somthing Wrong Please Try Again.....", "Faild", MessageBoxButtons.OK, MessageBoxIcon.Error);
                CheckAcBalance.Enabled = true;
                CheckAcBalance.Clear();

            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            i++;
            if (i == 45) { Pleasewaitlbl.Visible = true; }
            if (i == 80) { Pleasewaitlbl.Visible = false; }
            if (i == 110) { Main_Panel.Visible = true; CheckAcBalance.Focus(); timer1.Stop(); }
            if (i == 140) { Main_Panel.Visible = false; Trasaction_Proceed.Visible = true;Pleasewaitlbl.Visible = false;}
            if (i == 160) { Trasaction_Proceed.Visible = false; Main_Panel.Visible = false; T_Complete.Visible = true; }
            if (i == 190) { timer1.Stop(); this.Close(); Dashbord obj = new Dashbord(); obj.Show(); }
          
        }
        private void CheckAcBalance_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.E)
            {
                if (CheckAcBalance.Text == "")
                {
                    MessageBox.Show("Please Enter Deposite Amount......", "Blank", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    CheckAcBalance.Focus();
                }
                else
                {
                    CheckAcBalance.Enabled = false;
                    debit_amount();

                }
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.C)
            {
                Cancel_Panel.Visible = true;
                timer2.Start();
                Pleasewaitlbl.Visible = false;
                T_Complete.Visible = false;
                Main_Panel.Visible = false;
                
               
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            a++;
            if (a == 50)
            {
                timer2.Stop();
                this.Close();
                Dashbord obj = new Dashbord();
                obj.Show();
            }
           
        }
    }
   }

