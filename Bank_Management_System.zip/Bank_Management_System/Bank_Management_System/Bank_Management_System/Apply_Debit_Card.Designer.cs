﻿namespace Bank_Management_System
{
    partial class Apply_Debit_Card
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel3 = new System.Windows.Forms.Panel();
            this.CheckAcBalance = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lblexit = new System.Windows.Forms.Label();
            this.lblreset = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.Name_Detail_Panel = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Lastname = new System.Windows.Forms.Label();
            this.AcHoldername = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.AccountNumber = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Control_Panel = new System.Windows.Forms.Panel();
            this.Loding_Panel = new System.Windows.Forms.Panel();
            this.Notification_Label = new System.Windows.Forms.Label();
            this.Reset_Panel = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.Apply_Apnel = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.Submit_Panel = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.Temper_TextBox = new System.Windows.Forms.TextBox();
            this.Debit_Card_Panel = new System.Windows.Forms.Panel();
            this.Debit_Card_CVV_Number = new System.Windows.Forms.Label();
            this.Debit_Last_Name = new System.Windows.Forms.Label();
            this.Debit_First_Name = new System.Windows.Forms.Label();
            this.Valid_Upto_Date = new System.Windows.Forms.Label();
            this.Valid_Upto_Text_Label = new System.Windows.Forms.Label();
            this.Uniq_Id_Number = new System.Windows.Forms.Label();
            this.Debit_Card_Fourth_Number = new System.Windows.Forms.Label();
            this.Debit_Card_Third_Number = new System.Windows.Forms.Label();
            this.Debit_Card_Secondt_Number = new System.Windows.Forms.Label();
            this.Debit_Card_First_Number = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel3.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel1.SuspendLayout();
            this.Name_Detail_Panel.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel5.SuspendLayout();
            this.Control_Panel.SuspendLayout();
            this.Loding_Panel.SuspendLayout();
            this.Reset_Panel.SuspendLayout();
            this.Apply_Apnel.SuspendLayout();
            this.Submit_Panel.SuspendLayout();
            this.panel8.SuspendLayout();
            this.Debit_Card_Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Teal;
            this.panel3.Controls.Add(this.CheckAcBalance);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(130, 79);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1659, 79);
            this.panel3.TabIndex = 55;
            // 
            // CheckAcBalance
            // 
            this.CheckAcBalance.BackColor = System.Drawing.Color.CadetBlue;
            this.CheckAcBalance.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CheckAcBalance.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckAcBalance.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.CheckAcBalance.Location = new System.Drawing.Point(820, 18);
            this.CheckAcBalance.MaxLength = 15;
            this.CheckAcBalance.Name = "CheckAcBalance";
            this.CheckAcBalance.Size = new System.Drawing.Size(510, 43);
            this.CheckAcBalance.TabIndex = 20;
            this.CheckAcBalance.TextChanged += new System.EventHandler(this.CheckAcBalance_TextChanged);
            this.CheckAcBalance.KeyDown += new System.Windows.Forms.KeyEventHandler(this.CheckAcBalance_KeyDown_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Teal;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.OldLace;
            this.label1.Location = new System.Drawing.Point(300, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(497, 43);
            this.label1.TabIndex = 4;
            this.label1.Text = "Enter Account Number : ";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Teal;
            this.panel6.Controls.Add(this.lblexit);
            this.panel6.Controls.Add(this.lblreset);
            this.panel6.Location = new System.Drawing.Point(1517, 12);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(272, 61);
            this.panel6.TabIndex = 56;
            // 
            // lblexit
            // 
            this.lblexit.AutoSize = true;
            this.lblexit.BackColor = System.Drawing.Color.White;
            this.lblexit.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblexit.ForeColor = System.Drawing.Color.Red;
            this.lblexit.Location = new System.Drawing.Point(27, 16);
            this.lblexit.Name = "lblexit";
            this.lblexit.Size = new System.Drawing.Size(191, 29);
            this.lblexit.TabIndex = 24;
            this.lblexit.Text = "Exit  - (Ctrl + X)";
            // 
            // lblreset
            // 
            this.lblreset.AutoSize = true;
            this.lblreset.BackColor = System.Drawing.Color.White;
            this.lblreset.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblreset.ForeColor = System.Drawing.Color.Red;
            this.lblreset.Location = new System.Drawing.Point(25, 16);
            this.lblreset.Name = "lblreset";
            this.lblreset.Size = new System.Drawing.Size(219, 29);
            this.lblreset.TabIndex = 23;
            this.lblreset.Text = "Reset  - (Ctrl + R)";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.label44);
            this.panel1.Controls.Add(this.label45);
            this.panel1.Location = new System.Drawing.Point(489, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(948, 61);
            this.panel1.TabIndex = 54;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.Teal;
            this.label44.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.Chartreuse;
            this.label44.Location = new System.Drawing.Point(122, 9);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(270, 43);
            this.label44.TabIndex = 3;
            this.label44.Text = "GIR BANK  - ";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Teal;
            this.label45.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.OldLace;
            this.label45.Location = new System.Drawing.Point(398, 9);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(357, 43);
            this.label45.TabIndex = 2;
            this.label45.Text = "Apply Debit Card\r\n";
            // 
            // Name_Detail_Panel
            // 
            this.Name_Detail_Panel.BackColor = System.Drawing.Color.Teal;
            this.Name_Detail_Panel.Controls.Add(this.panel2);
            this.Name_Detail_Panel.Controls.Add(this.panel5);
            this.Name_Detail_Panel.Controls.Add(this.label5);
            this.Name_Detail_Panel.Controls.Add(this.label2);
            this.Name_Detail_Panel.Location = new System.Drawing.Point(130, 179);
            this.Name_Detail_Panel.Name = "Name_Detail_Panel";
            this.Name_Detail_Panel.Size = new System.Drawing.Size(1659, 116);
            this.Name_Detail_Panel.TabIndex = 57;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkCyan;
            this.panel2.Controls.Add(this.Lastname);
            this.panel2.Controls.Add(this.AcHoldername);
            this.panel2.Location = new System.Drawing.Point(353, 27);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(500, 56);
            this.panel2.TabIndex = 25;
            // 
            // Lastname
            // 
            this.Lastname.AutoSize = true;
            this.Lastname.BackColor = System.Drawing.Color.DarkCyan;
            this.Lastname.Font = new System.Drawing.Font("Modern No. 20", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lastname.ForeColor = System.Drawing.Color.Transparent;
            this.Lastname.Location = new System.Drawing.Point(162, 11);
            this.Lastname.Name = "Lastname";
            this.Lastname.Size = new System.Drawing.Size(28, 36);
            this.Lastname.TabIndex = 25;
            this.Lastname.Text = "-";
            // 
            // AcHoldername
            // 
            this.AcHoldername.AutoSize = true;
            this.AcHoldername.BackColor = System.Drawing.Color.DarkCyan;
            this.AcHoldername.Font = new System.Drawing.Font("Modern No. 20", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AcHoldername.ForeColor = System.Drawing.Color.Transparent;
            this.AcHoldername.Location = new System.Drawing.Point(21, 14);
            this.AcHoldername.Name = "AcHoldername";
            this.AcHoldername.Size = new System.Drawing.Size(28, 36);
            this.AcHoldername.TabIndex = 22;
            this.AcHoldername.Text = "-";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkCyan;
            this.panel5.Controls.Add(this.AccountNumber);
            this.panel5.Location = new System.Drawing.Point(1239, 27);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(409, 56);
            this.panel5.TabIndex = 13;
            // 
            // AccountNumber
            // 
            this.AccountNumber.AutoSize = true;
            this.AccountNumber.BackColor = System.Drawing.Color.DarkCyan;
            this.AccountNumber.Font = new System.Drawing.Font("Calisto MT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AccountNumber.ForeColor = System.Drawing.Color.Transparent;
            this.AccountNumber.Location = new System.Drawing.Point(13, 9);
            this.AccountNumber.Name = "AccountNumber";
            this.AccountNumber.Size = new System.Drawing.Size(26, 37);
            this.AccountNumber.TabIndex = 24;
            this.AccountNumber.Text = "-";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Teal;
            this.label5.Font = new System.Drawing.Font("Century Schoolbook", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.OldLace;
            this.label5.Location = new System.Drawing.Point(990, 44);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(243, 30);
            this.label5.TabIndex = 23;
            this.label5.Text = "Account Number : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Teal;
            this.label2.Font = new System.Drawing.Font("Century Schoolbook", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.OldLace;
            this.label2.Location = new System.Drawing.Point(40, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(307, 30);
            this.label2.TabIndex = 21;
            this.label2.Text = "Account Holder Name : ";
            // 
            // Control_Panel
            // 
            this.Control_Panel.BackColor = System.Drawing.Color.Teal;
            this.Control_Panel.Controls.Add(this.Loding_Panel);
            this.Control_Panel.Controls.Add(this.Reset_Panel);
            this.Control_Panel.Controls.Add(this.Apply_Apnel);
            this.Control_Panel.Controls.Add(this.Submit_Panel);
            this.Control_Panel.Location = new System.Drawing.Point(130, 301);
            this.Control_Panel.Name = "Control_Panel";
            this.Control_Panel.Size = new System.Drawing.Size(1659, 98);
            this.Control_Panel.TabIndex = 58;
            // 
            // Loding_Panel
            // 
            this.Loding_Panel.BackColor = System.Drawing.Color.SkyBlue;
            this.Loding_Panel.Controls.Add(this.Notification_Label);
            this.Loding_Panel.Location = new System.Drawing.Point(1063, 19);
            this.Loding_Panel.Name = "Loding_Panel";
            this.Loding_Panel.Size = new System.Drawing.Size(568, 61);
            this.Loding_Panel.TabIndex = 58;
            // 
            // Notification_Label
            // 
            this.Notification_Label.AutoSize = true;
            this.Notification_Label.BackColor = System.Drawing.Color.DarkSlateGray;
            this.Notification_Label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Notification_Label.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Notification_Label.Location = new System.Drawing.Point(36, 23);
            this.Notification_Label.Name = "Notification_Label";
            this.Notification_Label.Size = new System.Drawing.Size(121, 24);
            this.Notification_Label.TabIndex = 5;
            this.Notification_Label.Text = "Loading....";
            // 
            // Reset_Panel
            // 
            this.Reset_Panel.BackColor = System.Drawing.Color.DarkCyan;
            this.Reset_Panel.Controls.Add(this.label4);
            this.Reset_Panel.Location = new System.Drawing.Point(375, 19);
            this.Reset_Panel.Name = "Reset_Panel";
            this.Reset_Panel.Size = new System.Drawing.Size(301, 61);
            this.Reset_Panel.TabIndex = 57;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(32, 19);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(219, 29);
            this.label4.TabIndex = 22;
            this.label4.Text = "Reset  - (Ctrl + R)";
            // 
            // Apply_Apnel
            // 
            this.Apply_Apnel.BackColor = System.Drawing.Color.DarkCyan;
            this.Apply_Apnel.Controls.Add(this.label6);
            this.Apply_Apnel.Location = new System.Drawing.Point(45, 19);
            this.Apply_Apnel.Name = "Apply_Apnel";
            this.Apply_Apnel.Size = new System.Drawing.Size(292, 61);
            this.Apply_Apnel.TabIndex = 57;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(32, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(213, 29);
            this.label6.TabIndex = 22;
            this.label6.Text = " Apply- (Ctrl + A)";
            // 
            // Submit_Panel
            // 
            this.Submit_Panel.BackColor = System.Drawing.Color.DarkCyan;
            this.Submit_Panel.Controls.Add(this.label3);
            this.Submit_Panel.Location = new System.Drawing.Point(723, 19);
            this.Submit_Panel.Name = "Submit_Panel";
            this.Submit_Panel.Size = new System.Drawing.Size(316, 61);
            this.Submit_Panel.TabIndex = 57;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(37, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(227, 29);
            this.label3.TabIndex = 22;
            this.label3.Text = "Submit - (Ctrl + S)";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Teal;
            this.panel8.Controls.Add(this.Temper_TextBox);
            this.panel8.Controls.Add(this.Debit_Card_Panel);
            this.panel8.Location = new System.Drawing.Point(130, 405);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1659, 666);
            this.panel8.TabIndex = 59;
            // 
            // Temper_TextBox
            // 
            this.Temper_TextBox.BackColor = System.Drawing.Color.DarkCyan;
            this.Temper_TextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Temper_TextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 1.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Temper_TextBox.Location = new System.Drawing.Point(337, 667);
            this.Temper_TextBox.Name = "Temper_TextBox";
            this.Temper_TextBox.Size = new System.Drawing.Size(10, 3);
            this.Temper_TextBox.TabIndex = 26;
            this.Temper_TextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Temper_TextBox_KeyDown_1);
            // 
            // Debit_Card_Panel
            // 
            this.Debit_Card_Panel.BackColor = System.Drawing.Color.DarkCyan;
            this.Debit_Card_Panel.Controls.Add(this.Debit_Card_CVV_Number);
            this.Debit_Card_Panel.Controls.Add(this.Debit_Last_Name);
            this.Debit_Card_Panel.Controls.Add(this.Debit_First_Name);
            this.Debit_Card_Panel.Controls.Add(this.Valid_Upto_Date);
            this.Debit_Card_Panel.Controls.Add(this.Valid_Upto_Text_Label);
            this.Debit_Card_Panel.Controls.Add(this.Uniq_Id_Number);
            this.Debit_Card_Panel.Controls.Add(this.Debit_Card_Fourth_Number);
            this.Debit_Card_Panel.Controls.Add(this.Debit_Card_Third_Number);
            this.Debit_Card_Panel.Controls.Add(this.Debit_Card_Secondt_Number);
            this.Debit_Card_Panel.Controls.Add(this.Debit_Card_First_Number);
            this.Debit_Card_Panel.Controls.Add(this.pictureBox1);
            this.Debit_Card_Panel.Location = new System.Drawing.Point(14, 49);
            this.Debit_Card_Panel.Name = "Debit_Card_Panel";
            this.Debit_Card_Panel.Size = new System.Drawing.Size(1634, 583);
            this.Debit_Card_Panel.TabIndex = 60;
            // 
            // Debit_Card_CVV_Number
            // 
            this.Debit_Card_CVV_Number.AutoSize = true;
            this.Debit_Card_CVV_Number.BackColor = System.Drawing.Color.Black;
            this.Debit_Card_CVV_Number.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Debit_Card_CVV_Number.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Debit_Card_CVV_Number.Location = new System.Drawing.Point(1381, 180);
            this.Debit_Card_CVV_Number.Name = "Debit_Card_CVV_Number";
            this.Debit_Card_CVV_Number.Size = new System.Drawing.Size(66, 33);
            this.Debit_Card_CVV_Number.TabIndex = 15;
            this.Debit_Card_CVV_Number.Text = "652";
            // 
            // Debit_Last_Name
            // 
            this.Debit_Last_Name.AutoSize = true;
            this.Debit_Last_Name.BackColor = System.Drawing.Color.Black;
            this.Debit_Last_Name.Font = new System.Drawing.Font("Bookman Old Style", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Debit_Last_Name.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Debit_Last_Name.Location = new System.Drawing.Point(279, 462);
            this.Debit_Last_Name.Name = "Debit_Last_Name";
            this.Debit_Last_Name.Size = new System.Drawing.Size(163, 32);
            this.Debit_Last_Name.TabIndex = 14;
            this.Debit_Last_Name.Text = "KESHVALA";
            // 
            // Debit_First_Name
            // 
            this.Debit_First_Name.AutoSize = true;
            this.Debit_First_Name.BackColor = System.Drawing.Color.Black;
            this.Debit_First_Name.Font = new System.Drawing.Font("Bookman Old Style", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Debit_First_Name.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Debit_First_Name.Location = new System.Drawing.Point(153, 462);
            this.Debit_First_Name.Name = "Debit_First_Name";
            this.Debit_First_Name.Size = new System.Drawing.Size(111, 32);
            this.Debit_First_Name.TabIndex = 13;
            this.Debit_First_Name.Text = "RAHUL";
            // 
            // Valid_Upto_Date
            // 
            this.Valid_Upto_Date.AutoSize = true;
            this.Valid_Upto_Date.BackColor = System.Drawing.Color.Black;
            this.Valid_Upto_Date.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Valid_Upto_Date.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Valid_Upto_Date.Location = new System.Drawing.Point(410, 397);
            this.Valid_Upto_Date.Name = "Valid_Upto_Date";
            this.Valid_Upto_Date.Size = new System.Drawing.Size(87, 32);
            this.Valid_Upto_Date.TabIndex = 12;
            this.Valid_Upto_Date.Text = "07/28";
            // 
            // Valid_Upto_Text_Label
            // 
            this.Valid_Upto_Text_Label.AutoSize = true;
            this.Valid_Upto_Text_Label.BackColor = System.Drawing.Color.Black;
            this.Valid_Upto_Text_Label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Valid_Upto_Text_Label.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Valid_Upto_Text_Label.Location = new System.Drawing.Point(342, 397);
            this.Valid_Upto_Text_Label.Name = "Valid_Upto_Text_Label";
            this.Valid_Upto_Text_Label.Size = new System.Drawing.Size(58, 36);
            this.Valid_Upto_Text_Label.TabIndex = 11;
            this.Valid_Upto_Text_Label.Text = "VALID\r\nUPTO\r\n";
            // 
            // Uniq_Id_Number
            // 
            this.Uniq_Id_Number.AutoSize = true;
            this.Uniq_Id_Number.BackColor = System.Drawing.Color.Black;
            this.Uniq_Id_Number.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Uniq_Id_Number.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Uniq_Id_Number.Location = new System.Drawing.Point(157, 373);
            this.Uniq_Id_Number.Name = "Uniq_Id_Number";
            this.Uniq_Id_Number.Size = new System.Drawing.Size(33, 12);
            this.Uniq_Id_Number.TabIndex = 10;
            this.Uniq_Id_Number.Text = "6522";
            // 
            // Debit_Card_Fourth_Number
            // 
            this.Debit_Card_Fourth_Number.AutoSize = true;
            this.Debit_Card_Fourth_Number.BackColor = System.Drawing.Color.Black;
            this.Debit_Card_Fourth_Number.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Debit_Card_Fourth_Number.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Debit_Card_Fourth_Number.Location = new System.Drawing.Point(410, 341);
            this.Debit_Card_Fourth_Number.Name = "Debit_Card_Fourth_Number";
            this.Debit_Card_Fourth_Number.Size = new System.Drawing.Size(79, 32);
            this.Debit_Card_Fourth_Number.TabIndex = 9;
            this.Debit_Card_Fourth_Number.Text = "6522";
            // 
            // Debit_Card_Third_Number
            // 
            this.Debit_Card_Third_Number.AutoSize = true;
            this.Debit_Card_Third_Number.BackColor = System.Drawing.Color.Black;
            this.Debit_Card_Third_Number.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Debit_Card_Third_Number.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Debit_Card_Third_Number.Location = new System.Drawing.Point(325, 341);
            this.Debit_Card_Third_Number.Name = "Debit_Card_Third_Number";
            this.Debit_Card_Third_Number.Size = new System.Drawing.Size(79, 32);
            this.Debit_Card_Third_Number.TabIndex = 8;
            this.Debit_Card_Third_Number.Text = "6522";
            // 
            // Debit_Card_Secondt_Number
            // 
            this.Debit_Card_Secondt_Number.AutoSize = true;
            this.Debit_Card_Secondt_Number.BackColor = System.Drawing.Color.Black;
            this.Debit_Card_Secondt_Number.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Debit_Card_Secondt_Number.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Debit_Card_Secondt_Number.Location = new System.Drawing.Point(238, 341);
            this.Debit_Card_Secondt_Number.Name = "Debit_Card_Secondt_Number";
            this.Debit_Card_Secondt_Number.Size = new System.Drawing.Size(79, 32);
            this.Debit_Card_Secondt_Number.TabIndex = 7;
            this.Debit_Card_Secondt_Number.Text = "6522";
            // 
            // Debit_Card_First_Number
            // 
            this.Debit_Card_First_Number.AutoSize = true;
            this.Debit_Card_First_Number.BackColor = System.Drawing.Color.Black;
            this.Debit_Card_First_Number.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Debit_Card_First_Number.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Debit_Card_First_Number.Location = new System.Drawing.Point(153, 341);
            this.Debit_Card_First_Number.Name = "Debit_Card_First_Number";
            this.Debit_Card_First_Number.Size = new System.Drawing.Size(79, 32);
            this.Debit_Card_First_Number.TabIndex = 6;
            this.Debit_Card_First_Number.Text = "4000";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Bank_Management_System.Properties.Resources.Screenshot__190_6;
            this.pictureBox1.Location = new System.Drawing.Point(31, 44);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1564, 508);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Interval = 70;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Apply_Debit_Card
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(1934, 1100);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.Control_Panel);
            this.Controls.Add(this.Name_Detail_Panel);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Apply_Debit_Card";
            this.Text = "Apply_Debit_Card";
            this.Load += new System.EventHandler(this.Apply_Debit_Card_Load);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.Name_Detail_Panel.ResumeLayout(false);
            this.Name_Detail_Panel.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.Control_Panel.ResumeLayout(false);
            this.Loding_Panel.ResumeLayout(false);
            this.Loding_Panel.PerformLayout();
            this.Reset_Panel.ResumeLayout(false);
            this.Reset_Panel.PerformLayout();
            this.Apply_Apnel.ResumeLayout(false);
            this.Apply_Apnel.PerformLayout();
            this.Submit_Panel.ResumeLayout(false);
            this.Submit_Panel.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.Debit_Card_Panel.ResumeLayout(false);
            this.Debit_Card_Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        public System.Windows.Forms.TextBox CheckAcBalance;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Panel Name_Detail_Panel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label Lastname;
        private System.Windows.Forms.Label AcHoldername;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label AccountNumber;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel Control_Panel;
        private System.Windows.Forms.Panel Loding_Panel;
        private System.Windows.Forms.Panel Reset_Panel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel Apply_Apnel;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel Submit_Panel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Notification_Label;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel Debit_Card_Panel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label Debit_Card_CVV_Number;
        private System.Windows.Forms.Label Debit_Last_Name;
        private System.Windows.Forms.Label Debit_First_Name;
        private System.Windows.Forms.Label Valid_Upto_Date;
        private System.Windows.Forms.Label Valid_Upto_Text_Label;
        private System.Windows.Forms.Label Uniq_Id_Number;
        private System.Windows.Forms.Label Debit_Card_Fourth_Number;
        private System.Windows.Forms.Label Debit_Card_Third_Number;
        private System.Windows.Forms.Label Debit_Card_Secondt_Number;
        private System.Windows.Forms.Label Debit_Card_First_Number;
        private System.Windows.Forms.Label lblexit;
        private System.Windows.Forms.Label lblreset;
        private System.Windows.Forms.TextBox Temper_TextBox;
        private System.Windows.Forms.Timer timer1;

    }
}