﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Globalization;

namespace Bank_Management_System
{
    public partial class View_Account_Details : Form
    {
        SqlConnection con;
        SqlCommand cmd, comm;
        string  BlockList = "";
        public View_Account_Details()
        {
            InitializeComponent();
        }
         public void Block_List()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();
            string qry = "select * from Blocke_Ac where BalockAcNumber='" + CheckAcBalance.Text + "'";
            comm = new SqlCommand(qry, con);
            DataTable dt = new DataTable();
            SqlDataAdapter oda = new SqlDataAdapter(comm);
            oda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                BlockList = dr["BalockAcNumber"].ToString();

            }
        }
        private void View_Account_Details_Load(object sender, EventArgs e)
        {
            Logout_Panel.Visible = false;
            AccountDetailPanel.Enabled = false;
            
        }
      
        private void BTN_CANCEL_Click(object sender, EventArgs e)
        {
            this.Close();
            Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
            obj.Show();
        }

        private void CheckAcBalance_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt16(CheckAcBalance.Text.Length) == 15)
            {

                Block_List();
                if (BlockList == CheckAcBalance.Text)
                {
                    MessageBox.Show("Account Is Blocked Please Try Another Account !! ", "DeActivated", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    CheckAcBalance.Clear();
                    CheckAcBalance.Enabled = true;
                    CheckAcBalance.Focus();
                    AccountDetailPanel.Enabled = false;
                    this.OnLoad(e);
                }
                else
                {
                    CheckAcBalance.Enabled = false;
                    AccountDetailPanel.Enabled = true;
                    con = new SqlConnection(Con_Class.cnn);
                    con.Open();
                    string qry = "select * from Customer_Table where AcNumber='" + CheckAcBalance.Text + "'";
                    cmd = new SqlCommand(qry, con);
                    DataTable dt = new DataTable();
                    SqlDataAdapter oda = new SqlDataAdapter(cmd);
                    oda.Fill(dt);
                    foreach (DataRow dr in dt.Rows)
                    {
                        string Bal = dr["AcBalance"].ToString();
                        Bal = string.Format(CultureInfo.CreateSpecificCulture("hi-IN"), "{0:C}", double.Parse(Bal));
                        Balance.Text = Bal;
                        lblfirstname.Text = dr["Firstname"].ToString();
                        Middlename.Text = dr["Middlename"].ToString();
                        lastname.Text = dr["Lastname"].ToString();
                        DateOfBirth.Text = dr["Dob"].ToString();
                        Gender.Text = dr["Gender"].ToString();
                        MobileNumber.Text = dr["MobileNumber"].ToString();
                        Email.Text = dr["EmailId"].ToString();
                        AlternateNumber.Text = dr["AlternateNumber"].ToString();
                        Qulification.Text = dr["Qulification"].ToString();
                        Taluka.Text = dr["Taluka"].ToString();
                        CityTown.Text = dr["City"].ToString();
                        Contry.Text = dr["Contry"].ToString();
                        State.Text = dr["State"].ToString();
                        Distric.Text = dr["Distric"].ToString();
                        Pincode.Text = dr["Pincode"].ToString();
                        AcType.Text = dr["AcType"].ToString();
                        AcNum.Text = dr["AcNumber"].ToString();
                        Pancard.Text = dr["PanNumber"].ToString();
                        AddharNumber.Text = dr["AddharNumber"].ToString();
                        Occupation.Text = dr["Occupation"].ToString();
                        Logout_Panel.Visible = true;
                    }
                    if (lblfirstname.Text == "-")
                    {
                        MessageBox.Show("Account Not Found", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        CheckAcBalance.Enabled = true;
                        CheckAcBalance.Clear();
                        CheckAcBalance.Focus();
                        AccountDetailPanel.Enabled = false;
                        Logout_Panel.Visible = false;

                    }
                }

            }
        }
        private void CheckAcBalance_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                if (lblfirstname.Text != "-")
                {
                    MessageBox.Show("Please Logout First", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Logout_Panel.Visible = false;
                }
                else
                {

                    this.Close();
                    Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
                    obj.Show();
                }
            }
        }

        private void Temper_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                if (lblfirstname.Text != "-")
                {
                    MessageBox.Show("Please Logout First", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Logout_Panel.Visible = false;
                }
                else
                {

                    this.Close();
                    Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
                    obj.Show();
                }
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                lblfirstname.Text = "-";
                Middlename.Text = "-";
                lastname.Text = "-";
                DateOfBirth.Text = "-";
                Gender.Text = "-";
                MobileNumber.Text = "-";
                Email.Text = "-";
                AlternateNumber.Text = "-";
                Qulification.Text = "-";
                Taluka.Text = "-";
                CityTown.Text = "-";
                Contry.Text = "-";
                State.Text = "-";
                Distric.Text = "-";
                Pincode.Text = "-";
                AcType.Text = "-";
                AcNum.Text = "-";
                Pancard.Text = "-";
                AddharNumber.Text = "-"; ;
                Occupation.Text = "-";
                Balance.Text = "-";
                CheckAcBalance.Enabled = true;
                CheckAcBalance.Clear();
                CheckAcBalance.Focus();
                AccountDetailPanel.Enabled = false;
                Logout_Panel.Visible = false;
            }
        }
    }
}
