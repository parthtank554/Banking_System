﻿namespace Bank_Management_System
{
    partial class Customer_Ragistration_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label41 = new System.Windows.Forms.Label();
            this.Qulification = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.txtAlternateNuber = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDob = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtEmailId = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.txtMobileNumber = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.ComboGender = new System.Windows.Forms.ComboBox();
            this.txtMiddlename = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtFirstname = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtLastname = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtPincode = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.txtTawonCity = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txtTaluka = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtDistric = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtState = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.ComboContry = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.AcBalance = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.Occupation = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.AddharNumber = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.PancardNumber = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.AccountNumber = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.ComboAccountType = new System.Windows.Forms.ComboBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label46 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label47 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.Captcha = new System.Windows.Forms.Label();
            this.text_Captcha = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Teal;
            this.groupBox1.Controls.Add(this.label41);
            this.groupBox1.Controls.Add(this.Qulification);
            this.groupBox1.Controls.Add(this.label42);
            this.groupBox1.Controls.Add(this.txtAlternateNuber);
            this.groupBox1.Controls.Add(this.label33);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtDob);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.txtEmailId);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.txtMobileNumber);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.ComboGender);
            this.groupBox1.Controls.Add(this.txtMiddlename);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txtFirstname);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.txtLastname);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Yellow;
            this.groupBox1.Location = new System.Drawing.Point(17, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1688, 345);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Personal Information";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.Color.Red;
            this.label41.Location = new System.Drawing.Point(1346, 246);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(23, 28);
            this.label41.TabIndex = 87;
            this.label41.Text = "*";
            // 
            // Qulification
            // 
            this.Qulification.BackColor = System.Drawing.Color.CadetBlue;
            this.Qulification.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Qulification.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Qulification.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.Qulification.Location = new System.Drawing.Point(1229, 286);
            this.Qulification.Name = "Qulification";
            this.Qulification.Size = new System.Drawing.Size(349, 39);
            this.Qulification.TabIndex = 86;
            this.Qulification.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLastname_KeyDown_1);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.Color.Yellow;
            this.label42.Location = new System.Drawing.Point(1225, 254);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(126, 24);
            this.label42.TabIndex = 85;
            this.label42.Text = "Qulification";
            // 
            // txtAlternateNuber
            // 
            this.txtAlternateNuber.BackColor = System.Drawing.Color.CadetBlue;
            this.txtAlternateNuber.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAlternateNuber.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAlternateNuber.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtAlternateNuber.Location = new System.Drawing.Point(586, 286);
            this.txtAlternateNuber.MaxLength = 10;
            this.txtAlternateNuber.Name = "txtAlternateNuber";
            this.txtAlternateNuber.Size = new System.Drawing.Size(342, 39);
            this.txtAlternateNuber.TabIndex = 82;
            this.txtAlternateNuber.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLastname_KeyDown_1);
            this.txtAlternateNuber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAlternateNuber_KeyPress);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.Yellow;
            this.label33.Location = new System.Drawing.Point(582, 254);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(257, 24);
            this.label33.TabIndex = 80;
            this.label33.Text = "Alternate Mobile  Number";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(222, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 28);
            this.label4.TabIndex = 79;
            this.label4.Text = "*";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(248, 143);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 28);
            this.label1.TabIndex = 78;
            this.label1.Text = "*";
            // 
            // txtDob
            // 
            this.txtDob.BackColor = System.Drawing.Color.CadetBlue;
            this.txtDob.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDob.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDob.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtDob.Location = new System.Drawing.Point(26, 181);
            this.txtDob.Name = "txtDob";
            this.txtDob.Size = new System.Drawing.Size(342, 39);
            this.txtDob.TabIndex = 77;
            this.txtDob.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLastname_KeyDown_1);
            this.txtDob.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDob_KeyPress);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Yellow;
            this.label15.Location = new System.Drawing.Point(22, 154);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(223, 24);
            this.label15.TabIndex = 76;
            this.label15.Text = "DOB (DD/MM/YYYY)";
            // 
            // txtEmailId
            // 
            this.txtEmailId.BackColor = System.Drawing.Color.CadetBlue;
            this.txtEmailId.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtEmailId.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmailId.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtEmailId.Location = new System.Drawing.Point(26, 286);
            this.txtEmailId.Name = "txtEmailId";
            this.txtEmailId.Size = new System.Drawing.Size(342, 39);
            this.txtEmailId.TabIndex = 75;
            this.txtEmailId.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLastname_KeyDown_1);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Red;
            this.label27.Location = new System.Drawing.Point(122, 245);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(23, 28);
            this.label27.TabIndex = 74;
            this.label27.Text = "*";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.Yellow;
            this.label28.Location = new System.Drawing.Point(22, 254);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(99, 24);
            this.label28.TabIndex = 73;
            this.label28.Text = "Email-Id";
            // 
            // txtMobileNumber
            // 
            this.txtMobileNumber.BackColor = System.Drawing.Color.CadetBlue;
            this.txtMobileNumber.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMobileNumber.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMobileNumber.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtMobileNumber.Location = new System.Drawing.Point(1229, 187);
            this.txtMobileNumber.MaxLength = 10;
            this.txtMobileNumber.Name = "txtMobileNumber";
            this.txtMobileNumber.Size = new System.Drawing.Size(342, 39);
            this.txtMobileNumber.TabIndex = 72;
            this.txtMobileNumber.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLastname_KeyDown_1);
            this.txtMobileNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMobileNumber_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Red;
            this.label12.Location = new System.Drawing.Point(1537, 143);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(23, 28);
            this.label12.TabIndex = 71;
            this.label12.Text = "*";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Yellow;
            this.label16.Location = new System.Drawing.Point(1225, 155);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(317, 24);
            this.label16.TabIndex = 70;
            this.label16.Text = "Mobile Number (Valid 10 Digit)";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(713, 150);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(23, 28);
            this.label13.TabIndex = 69;
            this.label13.Text = "*";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Yellow;
            this.label14.Location = new System.Drawing.Point(582, 154);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(136, 24);
            this.label14.TabIndex = 68;
            this.label14.Text = "Select Gender";
            // 
            // ComboGender
            // 
            this.ComboGender.BackColor = System.Drawing.Color.CadetBlue;
            this.ComboGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboGender.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ComboGender.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboGender.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.ComboGender.FormattingEnabled = true;
            this.ComboGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.ComboGender.Location = new System.Drawing.Point(586, 181);
            this.ComboGender.Name = "ComboGender";
            this.ComboGender.Size = new System.Drawing.Size(349, 45);
            this.ComboGender.TabIndex = 67;
            this.ComboGender.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLastname_KeyDown_1);
            this.ComboGender.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ComboGender_KeyPress);
            // 
            // txtMiddlename
            // 
            this.txtMiddlename.BackColor = System.Drawing.Color.CadetBlue;
            this.txtMiddlename.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMiddlename.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMiddlename.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtMiddlename.Location = new System.Drawing.Point(1229, 61);
            this.txtMiddlename.Name = "txtMiddlename";
            this.txtMiddlename.Size = new System.Drawing.Size(342, 39);
            this.txtMiddlename.TabIndex = 64;
            this.txtMiddlename.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLastname_KeyDown_1);
            this.txtMiddlename.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMiddlename_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(1346, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(23, 28);
            this.label7.TabIndex = 63;
            this.label7.Text = "*";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Yellow;
            this.label8.Location = new System.Drawing.Point(1225, 29);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(125, 24);
            this.label8.TabIndex = 62;
            this.label8.Text = "Middlename";
            // 
            // txtFirstname
            // 
            this.txtFirstname.BackColor = System.Drawing.Color.CadetBlue;
            this.txtFirstname.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtFirstname.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFirstname.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtFirstname.Location = new System.Drawing.Point(586, 75);
            this.txtFirstname.Name = "txtFirstname";
            this.txtFirstname.Size = new System.Drawing.Size(349, 39);
            this.txtFirstname.TabIndex = 61;
            this.txtFirstname.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLastname_KeyDown_1);
            this.txtFirstname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFirstname_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(682, 39);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 28);
            this.label5.TabIndex = 60;
            this.label5.Text = "*";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Yellow;
            this.label6.Location = new System.Drawing.Point(582, 43);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 24);
            this.label6.TabIndex = 59;
            this.label6.Text = "Firstname";
            // 
            // txtLastname
            // 
            this.txtLastname.BackColor = System.Drawing.Color.CadetBlue;
            this.txtLastname.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtLastname.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLastname.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtLastname.Location = new System.Drawing.Point(26, 75);
            this.txtLastname.Name = "txtLastname";
            this.txtLastname.Size = new System.Drawing.Size(342, 39);
            this.txtLastname.TabIndex = 58;
            this.txtLastname.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLastname_KeyDown_1);
            this.txtLastname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLastname_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Yellow;
            this.label3.Location = new System.Drawing.Point(22, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(205, 24);
            this.label3.TabIndex = 57;
            this.label3.Text = "Lastname (Surname)";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Teal;
            this.groupBox2.Controls.Add(this.txtPincode);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.txtTawonCity);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.txtTaluka);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.txtDistric);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.txtState);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.ComboContry);
            this.groupBox2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Yellow;
            this.groupBox2.Location = new System.Drawing.Point(17, 356);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1688, 250);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Addresh";
            // 
            // txtPincode
            // 
            this.txtPincode.BackColor = System.Drawing.Color.CadetBlue;
            this.txtPincode.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPincode.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPincode.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtPincode.Location = new System.Drawing.Point(1229, 191);
            this.txtPincode.MaxLength = 6;
            this.txtPincode.Name = "txtPincode";
            this.txtPincode.Size = new System.Drawing.Size(349, 39);
            this.txtPincode.TabIndex = 71;
            this.txtPincode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLastname_KeyDown_1);
            this.txtPincode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPincode_KeyPress);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Red;
            this.label25.Location = new System.Drawing.Point(1419, 155);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(23, 28);
            this.label25.TabIndex = 70;
            this.label25.Text = "*";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Yellow;
            this.label26.Location = new System.Drawing.Point(1225, 159);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(188, 24);
            this.label26.TabIndex = 69;
            this.label26.Text = "Pincode (Zip Code)";
            // 
            // txtTawonCity
            // 
            this.txtTawonCity.BackColor = System.Drawing.Color.CadetBlue;
            this.txtTawonCity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTawonCity.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTawonCity.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtTawonCity.Location = new System.Drawing.Point(586, 191);
            this.txtTawonCity.Name = "txtTawonCity";
            this.txtTawonCity.Size = new System.Drawing.Size(349, 39);
            this.txtTawonCity.TabIndex = 68;
            this.txtTawonCity.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLastname_KeyDown_1);
            this.txtTawonCity.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTawonCity_KeyPress);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Red;
            this.label23.Location = new System.Drawing.Point(695, 145);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(23, 28);
            this.label23.TabIndex = 67;
            this.label23.Text = "*";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Yellow;
            this.label24.Location = new System.Drawing.Point(582, 155);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(114, 24);
            this.label24.TabIndex = 66;
            this.label24.Text = "Tawon/City";
            // 
            // txtTaluka
            // 
            this.txtTaluka.BackColor = System.Drawing.Color.CadetBlue;
            this.txtTaluka.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTaluka.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTaluka.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtTaluka.Location = new System.Drawing.Point(26, 191);
            this.txtTaluka.Name = "txtTaluka";
            this.txtTaluka.Size = new System.Drawing.Size(349, 39);
            this.txtTaluka.TabIndex = 65;
            this.txtTaluka.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLastname_KeyDown_1);
            this.txtTaluka.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTaluka_KeyPress);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Red;
            this.label21.Location = new System.Drawing.Point(95, 155);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(23, 28);
            this.label21.TabIndex = 64;
            this.label21.Text = "*";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Yellow;
            this.label22.Location = new System.Drawing.Point(22, 159);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(78, 24);
            this.label22.TabIndex = 63;
            this.label22.Text = "Taluka";
            // 
            // txtDistric
            // 
            this.txtDistric.BackColor = System.Drawing.Color.CadetBlue;
            this.txtDistric.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDistric.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDistric.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtDistric.Location = new System.Drawing.Point(1222, 86);
            this.txtDistric.Name = "txtDistric";
            this.txtDistric.Size = new System.Drawing.Size(349, 39);
            this.txtDistric.TabIndex = 62;
            this.txtDistric.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLastname_KeyDown_1);
            this.txtDistric.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDistric_KeyPress);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Red;
            this.label19.Location = new System.Drawing.Point(1299, 43);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(23, 28);
            this.label19.TabIndex = 61;
            this.label19.Text = "*";
            // 
            // txtState
            // 
            this.txtState.BackColor = System.Drawing.Color.CadetBlue;
            this.txtState.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtState.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtState.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.txtState.Location = new System.Drawing.Point(586, 92);
            this.txtState.Name = "txtState";
            this.txtState.Size = new System.Drawing.Size(349, 39);
            this.txtState.TabIndex = 59;
            this.txtState.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLastname_KeyDown_1);
            this.txtState.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtState_KeyPress);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Red;
            this.label17.Location = new System.Drawing.Point(644, 46);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(23, 28);
            this.label17.TabIndex = 58;
            this.label17.Text = "*";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Yellow;
            this.label20.Location = new System.Drawing.Point(1218, 54);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(75, 24);
            this.label20.TabIndex = 60;
            this.label20.Text = "Distric";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Yellow;
            this.label18.Location = new System.Drawing.Point(582, 54);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(56, 24);
            this.label18.TabIndex = 57;
            this.label18.Text = "State";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(150, 40);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(23, 28);
            this.label9.TabIndex = 56;
            this.label9.Text = "*";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Yellow;
            this.label10.Location = new System.Drawing.Point(22, 54);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(131, 24);
            this.label10.TabIndex = 55;
            this.label10.Text = "Select Contry";
            // 
            // ComboContry
            // 
            this.ComboContry.BackColor = System.Drawing.Color.CadetBlue;
            this.ComboContry.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboContry.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ComboContry.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboContry.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.ComboContry.FormattingEnabled = true;
            this.ComboContry.Items.AddRange(new object[] {
            "India",
            "Japan",
            "Autrailia",
            "Bangladesh",
            "Malasiya",
            "USA",
            "China",
            "Myanmar",
            "Shree Lanka",
            "Afghanistan"});
            this.ComboContry.Location = new System.Drawing.Point(26, 86);
            this.ComboContry.Name = "ComboContry";
            this.ComboContry.Size = new System.Drawing.Size(349, 45);
            this.ComboContry.TabIndex = 54;
            this.ComboContry.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLastname_KeyDown_1);
            this.ComboContry.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ComboContry_KeyPress);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Teal;
            this.groupBox3.Controls.Add(this.AcBalance);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label43);
            this.groupBox3.Controls.Add(this.Occupation);
            this.groupBox3.Controls.Add(this.label37);
            this.groupBox3.Controls.Add(this.label38);
            this.groupBox3.Controls.Add(this.AddharNumber);
            this.groupBox3.Controls.Add(this.label35);
            this.groupBox3.Controls.Add(this.label36);
            this.groupBox3.Controls.Add(this.PancardNumber);
            this.groupBox3.Controls.Add(this.label32);
            this.groupBox3.Controls.Add(this.AccountNumber);
            this.groupBox3.Controls.Add(this.label34);
            this.groupBox3.Controls.Add(this.label30);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label31);
            this.groupBox3.Controls.Add(this.label29);
            this.groupBox3.Controls.Add(this.ComboAccountType);
            this.groupBox3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.Color.Yellow;
            this.groupBox3.Location = new System.Drawing.Point(17, 612);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1688, 242);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Account Information";
            // 
            // AcBalance
            // 
            this.AcBalance.BackColor = System.Drawing.Color.CadetBlue;
            this.AcBalance.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AcBalance.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AcBalance.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.AcBalance.Location = new System.Drawing.Point(1229, 192);
            this.AcBalance.Name = "AcBalance";
            this.AcBalance.Size = new System.Drawing.Size(349, 39);
            this.AcBalance.TabIndex = 83;
            this.AcBalance.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLastname_KeyDown_1);
            this.AcBalance.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AcBalance_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(1457, 152);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 28);
            this.label2.TabIndex = 82;
            this.label2.Text = "*";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.Color.Yellow;
            this.label43.Location = new System.Drawing.Point(1225, 160);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(235, 24);
            this.label43.TabIndex = 81;
            this.label43.Text = "Balance(Minimum 500)";
            // 
            // Occupation
            // 
            this.Occupation.BackColor = System.Drawing.Color.CadetBlue;
            this.Occupation.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Occupation.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Occupation.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.Occupation.Location = new System.Drawing.Point(586, 192);
            this.Occupation.Name = "Occupation";
            this.Occupation.Size = new System.Drawing.Size(349, 39);
            this.Occupation.TabIndex = 80;
            this.Occupation.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLastname_KeyDown_1);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.Color.Red;
            this.label37.Location = new System.Drawing.Point(695, 152);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(23, 28);
            this.label37.TabIndex = 79;
            this.label37.Text = "*";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.Yellow;
            this.label38.Location = new System.Drawing.Point(582, 160);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(113, 24);
            this.label38.TabIndex = 78;
            this.label38.Text = "Occupation";
            // 
            // AddharNumber
            // 
            this.AddharNumber.BackColor = System.Drawing.Color.CadetBlue;
            this.AddharNumber.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AddharNumber.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddharNumber.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.AddharNumber.Location = new System.Drawing.Point(19, 192);
            this.AddharNumber.MaxLength = 12;
            this.AddharNumber.Name = "AddharNumber";
            this.AddharNumber.Size = new System.Drawing.Size(349, 39);
            this.AddharNumber.TabIndex = 77;
            this.AddharNumber.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLastname_KeyDown_1);
            this.AddharNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AddharNumber_KeyPress);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.Red;
            this.label35.Location = new System.Drawing.Point(333, 141);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(23, 28);
            this.label35.TabIndex = 76;
            this.label35.Text = "*";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.Yellow;
            this.label36.Location = new System.Drawing.Point(15, 156);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(322, 24);
            this.label36.TabIndex = 75;
            this.label36.Text = "Addhar Number (Valid 12 Digit)";
            // 
            // PancardNumber
            // 
            this.PancardNumber.BackColor = System.Drawing.Color.CadetBlue;
            this.PancardNumber.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.PancardNumber.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PancardNumber.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.PancardNumber.Location = new System.Drawing.Point(1229, 87);
            this.PancardNumber.MaxLength = 10;
            this.PancardNumber.Name = "PancardNumber";
            this.PancardNumber.Size = new System.Drawing.Size(349, 39);
            this.PancardNumber.TabIndex = 74;
            this.PancardNumber.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLastname_KeyDown_1);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.Red;
            this.label32.Location = new System.Drawing.Point(1588, 32);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(23, 28);
            this.label32.TabIndex = 73;
            this.label32.Text = "*";
            // 
            // AccountNumber
            // 
            this.AccountNumber.BackColor = System.Drawing.Color.CadetBlue;
            this.AccountNumber.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.AccountNumber.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AccountNumber.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.AccountNumber.Location = new System.Drawing.Point(586, 90);
            this.AccountNumber.MaxLength = 4;
            this.AccountNumber.Name = "AccountNumber";
            this.AccountNumber.Size = new System.Drawing.Size(349, 39);
            this.AccountNumber.TabIndex = 74;
            this.AccountNumber.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLastname_KeyDown_1);
            this.AccountNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AccountNumber_KeyPress);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.Yellow;
            this.label34.Location = new System.Drawing.Point(1225, 51);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(371, 24);
            this.label34.TabIndex = 72;
            this.label34.Text = "Pancard Number (Valid 10 Character)";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.Red;
            this.label30.Location = new System.Drawing.Point(801, 32);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(23, 28);
            this.label30.TabIndex = 73;
            this.label30.Text = "*";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(222, 32);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(23, 28);
            this.label11.TabIndex = 59;
            this.label11.Text = "*";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.Yellow;
            this.label31.Location = new System.Drawing.Point(582, 51);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(225, 24);
            this.label31.TabIndex = 72;
            this.label31.Text = "Enter Account Number";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.Yellow;
            this.label29.Location = new System.Drawing.Point(22, 51);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(196, 24);
            this.label29.TabIndex = 58;
            this.label29.Text = "Select Account Type";
            // 
            // ComboAccountType
            // 
            this.ComboAccountType.BackColor = System.Drawing.Color.CadetBlue;
            this.ComboAccountType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboAccountType.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ComboAccountType.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboAccountType.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.ComboAccountType.FormattingEnabled = true;
            this.ComboAccountType.Items.AddRange(new object[] {
            "Saving",
            "Current",
            "Fix Deposite"});
            this.ComboAccountType.Location = new System.Drawing.Point(19, 84);
            this.ComboAccountType.Name = "ComboAccountType";
            this.ComboAccountType.Size = new System.Drawing.Size(349, 45);
            this.ComboAccountType.TabIndex = 57;
            this.ComboAccountType.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLastname_KeyDown_1);
            this.ComboAccountType.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ComboAccountType_KeyPress);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Teal;
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Controls.Add(this.label39);
            this.panel3.Controls.Add(this.label40);
            this.panel3.Controls.Add(this.Captcha);
            this.panel3.Controls.Add(this.text_Captcha);
            this.panel3.Location = new System.Drawing.Point(20, 860);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1436, 99);
            this.panel3.TabIndex = 7;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkCyan;
            this.panel5.Controls.Add(this.label46);
            this.panel5.Location = new System.Drawing.Point(583, 43);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(357, 70);
            this.panel5.TabIndex = 59;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.Color.White;
            this.label46.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.ForeColor = System.Drawing.Color.Red;
            this.label46.Location = new System.Drawing.Point(57, 24);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(251, 33);
            this.label46.TabIndex = 22;
            this.label46.Text = "Reset  - (Ctrl + R)";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkCyan;
            this.panel4.Controls.Add(this.label47);
            this.panel4.Location = new System.Drawing.Point(1015, 43);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(342, 70);
            this.panel4.TabIndex = 58;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.BackColor = System.Drawing.Color.White;
            this.label47.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.ForeColor = System.Drawing.Color.Red;
            this.label47.Location = new System.Drawing.Point(81, 21);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(212, 33);
            this.label47.TabIndex = 22;
            this.label47.Text = "Exit - (Ctrl + X)";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Calisto MT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.Yellow;
            this.label39.Location = new System.Drawing.Point(251, 43);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(99, 17);
            this.label39.TabIndex = 37;
            this.label39.Text = "Captcha Code";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Calisto MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.Color.Yellow;
            this.label40.Location = new System.Drawing.Point(35, 39);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(77, 22);
            this.label40.TabIndex = 34;
            this.label40.Text = "Captcha";
            // 
            // Captcha
            // 
            this.Captcha.AutoSize = true;
            this.Captcha.BackColor = System.Drawing.Color.LightSkyBlue;
            this.Captcha.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Captcha.Font = new System.Drawing.Font("Buxton Sketch", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Captcha.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.Captcha.Location = new System.Drawing.Point(254, 60);
            this.Captcha.Name = "Captcha";
            this.Captcha.Size = new System.Drawing.Size(118, 45);
            this.Captcha.TabIndex = 35;
            this.Captcha.Text = "Captcha";
            // 
            // text_Captcha
            // 
            this.text_Captcha.BackColor = System.Drawing.Color.CadetBlue;
            this.text_Captcha.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.text_Captcha.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_Captcha.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.text_Captcha.Location = new System.Drawing.Point(39, 64);
            this.text_Captcha.Name = "text_Captcha";
            this.text_Captcha.Size = new System.Drawing.Size(175, 39);
            this.text_Captcha.TabIndex = 36;
            this.text_Captcha.TextChanged += new System.EventHandler(this.text_Captcha_TextChanged);
            this.text_Captcha.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtLastname_KeyDown_1);
            this.text_Captcha.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.text_Captcha_KeyPress);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.label44);
            this.panel1.Controls.Add(this.label45);
            this.panel1.Location = new System.Drawing.Point(458, -62);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(821, 61);
            this.panel1.TabIndex = 8;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.Teal;
            this.label44.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.Chartreuse;
            this.label44.Location = new System.Drawing.Point(64, 13);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(270, 43);
            this.label44.TabIndex = 3;
            this.label44.Text = "GIR BANK  - ";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Teal;
            this.label45.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.OldLace;
            this.label45.Location = new System.Drawing.Point(329, 13);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(387, 43);
            this.label45.TabIndex = 2;
            this.label45.Text = "Open New Account";
            // 
            // Customer_Ragistration_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(1455, 1016);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Customer_Ragistration_Form";
            this.Text = "Customer_Ragistration_Form";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Customer_Ragistration_Form_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.TextBox txtEmailId;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        public System.Windows.Forms.TextBox txtMobileNumber;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox ComboGender;
        public System.Windows.Forms.TextBox txtMiddlename;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        public System.Windows.Forms.TextBox txtFirstname;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.TextBox txtLastname;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox txtDob;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.GroupBox groupBox2;
        public System.Windows.Forms.TextBox txtAlternateNuber;
        private System.Windows.Forms.Label label33;
        public System.Windows.Forms.TextBox txtPincode;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        public System.Windows.Forms.TextBox txtTawonCity;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        public System.Windows.Forms.TextBox txtTaluka;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        public System.Windows.Forms.TextBox txtDistric;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        public System.Windows.Forms.TextBox txtState;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox ComboContry;
        private System.Windows.Forms.GroupBox groupBox3;
        public System.Windows.Forms.TextBox Occupation;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        public System.Windows.Forms.TextBox AddharNumber;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        public System.Windows.Forms.TextBox PancardNumber;
        private System.Windows.Forms.Label label32;
        public System.Windows.Forms.TextBox AccountNumber;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ComboBox ComboAccountType;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label Captcha;
        public System.Windows.Forms.TextBox text_Captcha;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label41;
        public System.Windows.Forms.TextBox Qulification;
        private System.Windows.Forms.Label label42;
        public System.Windows.Forms.TextBox AcBalance;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label47;
    }
}