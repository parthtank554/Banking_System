﻿namespace Bank_Management_System
{
    partial class Transfer_Amount_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.Logout_Panel = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.FromPanel = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.FromDetailPanel = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.FromLastname = new System.Windows.Forms.Label();
            this.FromAcHoldername = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.FromAccountBal = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.FromAccountBalancetextbox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.Submit_Button_Panel = new System.Windows.Forms.Panel();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.Captcha = new System.Windows.Forms.Label();
            this.text_Captcha = new System.Windows.Forms.TextBox();
            this.Deposite_Panel = new System.Windows.Forms.Panel();
            this.DebitAmount = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ToPanel = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.ToNameDetailPanel = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.ToLastname = new System.Windows.Forms.Label();
            this.ToAcHoldername = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.ToAccountBal = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ToAccountBalancetextbox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.Logout_Panel.SuspendLayout();
            this.FromPanel.SuspendLayout();
            this.panel10.SuspendLayout();
            this.FromDetailPanel.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.Submit_Button_Panel.SuspendLayout();
            this.Deposite_Panel.SuspendLayout();
            this.ToPanel.SuspendLayout();
            this.panel8.SuspendLayout();
            this.ToNameDetailPanel.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Teal;
            this.panel2.Controls.Add(this.Logout_Panel);
            this.panel2.Controls.Add(this.FromPanel);
            this.panel2.Controls.Add(this.Submit_Button_Panel);
            this.panel2.Controls.Add(this.Deposite_Panel);
            this.panel2.Controls.Add(this.ToPanel);
            this.panel2.Location = new System.Drawing.Point(93, 100);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1717, 970);
            this.panel2.TabIndex = 16;
            // 
            // Logout_Panel
            // 
            this.Logout_Panel.BackColor = System.Drawing.Color.DarkCyan;
            this.Logout_Panel.Controls.Add(this.label8);
            this.Logout_Panel.Location = new System.Drawing.Point(610, 884);
            this.Logout_Panel.Name = "Logout_Panel";
            this.Logout_Panel.Size = new System.Drawing.Size(495, 71);
            this.Logout_Panel.TabIndex = 43;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(133, 21);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(249, 33);
            this.label8.TabIndex = 22;
            this.label8.Text = "Logout - (Ctrl+R)";
            // 
            // FromPanel
            // 
            this.FromPanel.BackColor = System.Drawing.Color.DarkCyan;
            this.FromPanel.Controls.Add(this.panel10);
            this.FromPanel.Controls.Add(this.FromDetailPanel);
            this.FromPanel.Controls.Add(this.FromAccountBalancetextbox);
            this.FromPanel.Controls.Add(this.label12);
            this.FromPanel.Location = new System.Drawing.Point(12, 340);
            this.FromPanel.Name = "FromPanel";
            this.FromPanel.Size = new System.Drawing.Size(1687, 282);
            this.FromPanel.TabIndex = 43;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.DarkCyan;
            this.panel10.Controls.Add(this.label6);
            this.panel10.Location = new System.Drawing.Point(3, 3);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(202, 68);
            this.panel10.TabIndex = 21;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.DarkCyan;
            this.label6.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Yellow;
            this.label6.Location = new System.Drawing.Point(24, 14);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(124, 43);
            this.label6.TabIndex = 4;
            this.label6.Text = "From";
            // 
            // FromDetailPanel
            // 
            this.FromDetailPanel.BackColor = System.Drawing.Color.Teal;
            this.FromDetailPanel.Controls.Add(this.panel12);
            this.FromDetailPanel.Controls.Add(this.panel13);
            this.FromDetailPanel.Controls.Add(this.label10);
            this.FromDetailPanel.Controls.Add(this.label11);
            this.FromDetailPanel.Location = new System.Drawing.Point(3, 141);
            this.FromDetailPanel.Name = "FromDetailPanel";
            this.FromDetailPanel.Size = new System.Drawing.Size(1684, 118);
            this.FromDetailPanel.TabIndex = 42;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.DarkCyan;
            this.panel12.Controls.Add(this.FromLastname);
            this.panel12.Controls.Add(this.FromAcHoldername);
            this.panel12.Location = new System.Drawing.Point(391, 36);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(318, 56);
            this.panel12.TabIndex = 25;
            // 
            // FromLastname
            // 
            this.FromLastname.AutoSize = true;
            this.FromLastname.BackColor = System.Drawing.Color.DarkCyan;
            this.FromLastname.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FromLastname.ForeColor = System.Drawing.Color.White;
            this.FromLastname.Location = new System.Drawing.Point(136, 14);
            this.FromLastname.Name = "FromLastname";
            this.FromLastname.Size = new System.Drawing.Size(25, 33);
            this.FromLastname.TabIndex = 25;
            this.FromLastname.Text = "-";
            // 
            // FromAcHoldername
            // 
            this.FromAcHoldername.AutoSize = true;
            this.FromAcHoldername.BackColor = System.Drawing.Color.DarkCyan;
            this.FromAcHoldername.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FromAcHoldername.ForeColor = System.Drawing.Color.White;
            this.FromAcHoldername.Location = new System.Drawing.Point(17, 14);
            this.FromAcHoldername.Name = "FromAcHoldername";
            this.FromAcHoldername.Size = new System.Drawing.Size(25, 33);
            this.FromAcHoldername.TabIndex = 22;
            this.FromAcHoldername.Text = "-";
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.DarkCyan;
            this.panel13.Controls.Add(this.FromAccountBal);
            this.panel13.Location = new System.Drawing.Point(1312, 36);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(258, 56);
            this.panel13.TabIndex = 13;
            // 
            // FromAccountBal
            // 
            this.FromAccountBal.AutoSize = true;
            this.FromAccountBal.BackColor = System.Drawing.Color.DarkCyan;
            this.FromAccountBal.Font = new System.Drawing.Font("Calisto MT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FromAccountBal.ForeColor = System.Drawing.Color.White;
            this.FromAccountBal.Location = new System.Drawing.Point(13, 9);
            this.FromAccountBal.Name = "FromAccountBal";
            this.FromAccountBal.Size = new System.Drawing.Size(26, 37);
            this.FromAccountBal.TabIndex = 24;
            this.FromAccountBal.Text = "-";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Teal;
            this.label10.Font = new System.Drawing.Font("Century Schoolbook", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.OldLace;
            this.label10.Location = new System.Drawing.Point(1047, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(242, 30);
            this.label10.TabIndex = 23;
            this.label10.Text = "Account Balance : ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Teal;
            this.label11.Font = new System.Drawing.Font("Century Schoolbook", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.OldLace;
            this.label11.Location = new System.Drawing.Point(53, 50);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(307, 30);
            this.label11.TabIndex = 21;
            this.label11.Text = "Account Holder Name : ";
            // 
            // FromAccountBalancetextbox
            // 
            this.FromAccountBalancetextbox.BackColor = System.Drawing.Color.CadetBlue;
            this.FromAccountBalancetextbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.FromAccountBalancetextbox.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FromAccountBalancetextbox.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.FromAccountBalancetextbox.Location = new System.Drawing.Point(823, 61);
            this.FromAccountBalancetextbox.MaxLength = 15;
            this.FromAccountBalancetextbox.Name = "FromAccountBalancetextbox";
            this.FromAccountBalancetextbox.Size = new System.Drawing.Size(510, 43);
            this.FromAccountBalancetextbox.TabIndex = 20;
            this.FromAccountBalancetextbox.TextChanged += new System.EventHandler(this.FromAccountBalancetextbox_TextChanged);
            this.FromAccountBalancetextbox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FromAccountBalancetextbox_KeyDown);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.DarkCyan;
            this.label12.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.OldLace;
            this.label12.Location = new System.Drawing.Point(309, 61);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(497, 43);
            this.label12.TabIndex = 4;
            this.label12.Text = "Enter Account Number : ";
            // 
            // Submit_Button_Panel
            // 
            this.Submit_Button_Panel.BackColor = System.Drawing.Color.DarkCyan;
            this.Submit_Button_Panel.Controls.Add(this.label39);
            this.Submit_Button_Panel.Controls.Add(this.label40);
            this.Submit_Button_Panel.Controls.Add(this.Captcha);
            this.Submit_Button_Panel.Controls.Add(this.text_Captcha);
            this.Submit_Button_Panel.Location = new System.Drawing.Point(15, 758);
            this.Submit_Button_Panel.Name = "Submit_Button_Panel";
            this.Submit_Button_Panel.Size = new System.Drawing.Size(1687, 99);
            this.Submit_Button_Panel.TabIndex = 27;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Calisto MT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.Yellow;
            this.label39.Location = new System.Drawing.Point(917, 18);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(99, 17);
            this.label39.TabIndex = 37;
            this.label39.Text = "Captcha Code";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Calisto MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.Color.Yellow;
            this.label40.Location = new System.Drawing.Point(701, 14);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(77, 22);
            this.label40.TabIndex = 34;
            this.label40.Text = "Captcha";
            // 
            // Captcha
            // 
            this.Captcha.AutoSize = true;
            this.Captcha.BackColor = System.Drawing.Color.LightSkyBlue;
            this.Captcha.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Captcha.Font = new System.Drawing.Font("Buxton Sketch", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Captcha.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.Captcha.Location = new System.Drawing.Point(920, 35);
            this.Captcha.Name = "Captcha";
            this.Captcha.Size = new System.Drawing.Size(118, 45);
            this.Captcha.TabIndex = 35;
            this.Captcha.Text = "Captcha";
            // 
            // text_Captcha
            // 
            this.text_Captcha.BackColor = System.Drawing.Color.CadetBlue;
            this.text_Captcha.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.text_Captcha.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_Captcha.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.text_Captcha.Location = new System.Drawing.Point(705, 39);
            this.text_Captcha.Name = "text_Captcha";
            this.text_Captcha.Size = new System.Drawing.Size(174, 39);
            this.text_Captcha.TabIndex = 36;
            this.text_Captcha.KeyDown += new System.Windows.Forms.KeyEventHandler(this.text_Captcha_KeyDown);
            // 
            // Deposite_Panel
            // 
            this.Deposite_Panel.BackColor = System.Drawing.Color.DarkCyan;
            this.Deposite_Panel.Controls.Add(this.DebitAmount);
            this.Deposite_Panel.Controls.Add(this.label3);
            this.Deposite_Panel.Location = new System.Drawing.Point(12, 649);
            this.Deposite_Panel.Name = "Deposite_Panel";
            this.Deposite_Panel.Size = new System.Drawing.Size(1687, 86);
            this.Deposite_Panel.TabIndex = 26;
            // 
            // DebitAmount
            // 
            this.DebitAmount.BackColor = System.Drawing.Color.CadetBlue;
            this.DebitAmount.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DebitAmount.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DebitAmount.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.DebitAmount.Location = new System.Drawing.Point(896, 28);
            this.DebitAmount.MaxLength = 15;
            this.DebitAmount.Name = "DebitAmount";
            this.DebitAmount.Size = new System.Drawing.Size(281, 43);
            this.DebitAmount.TabIndex = 21;
            this.DebitAmount.KeyDown += new System.Windows.Forms.KeyEventHandler(this.DebitAmount_KeyDown);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.DarkCyan;
            this.label3.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.OldLace;
            this.label3.Location = new System.Drawing.Point(348, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(513, 43);
            this.label3.TabIndex = 21;
            this.label3.Text = "Enter Transfer  Amount : ";
            // 
            // ToPanel
            // 
            this.ToPanel.BackColor = System.Drawing.Color.DarkCyan;
            this.ToPanel.Controls.Add(this.panel8);
            this.ToPanel.Controls.Add(this.ToNameDetailPanel);
            this.ToPanel.Controls.Add(this.ToAccountBalancetextbox);
            this.ToPanel.Controls.Add(this.label1);
            this.ToPanel.Location = new System.Drawing.Point(12, 30);
            this.ToPanel.Name = "ToPanel";
            this.ToPanel.Size = new System.Drawing.Size(1687, 282);
            this.ToPanel.TabIndex = 11;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.DarkCyan;
            this.panel8.Controls.Add(this.label4);
            this.panel8.Location = new System.Drawing.Point(3, 3);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(138, 68);
            this.panel8.TabIndex = 21;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.DarkCyan;
            this.label4.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Yellow;
            this.label4.Location = new System.Drawing.Point(39, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 43);
            this.label4.TabIndex = 4;
            this.label4.Text = "To\r\n";
            // 
            // ToNameDetailPanel
            // 
            this.ToNameDetailPanel.BackColor = System.Drawing.Color.Teal;
            this.ToNameDetailPanel.Controls.Add(this.panel6);
            this.ToNameDetailPanel.Controls.Add(this.panel5);
            this.ToNameDetailPanel.Controls.Add(this.label5);
            this.ToNameDetailPanel.Controls.Add(this.label2);
            this.ToNameDetailPanel.Location = new System.Drawing.Point(3, 143);
            this.ToNameDetailPanel.Name = "ToNameDetailPanel";
            this.ToNameDetailPanel.Size = new System.Drawing.Size(1684, 116);
            this.ToNameDetailPanel.TabIndex = 42;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DarkCyan;
            this.panel6.Controls.Add(this.ToLastname);
            this.panel6.Controls.Add(this.ToAcHoldername);
            this.panel6.Location = new System.Drawing.Point(353, 27);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(318, 56);
            this.panel6.TabIndex = 25;
            // 
            // ToLastname
            // 
            this.ToLastname.AutoSize = true;
            this.ToLastname.BackColor = System.Drawing.Color.DarkCyan;
            this.ToLastname.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ToLastname.ForeColor = System.Drawing.Color.Transparent;
            this.ToLastname.Location = new System.Drawing.Point(120, 14);
            this.ToLastname.Name = "ToLastname";
            this.ToLastname.Size = new System.Drawing.Size(25, 33);
            this.ToLastname.TabIndex = 25;
            this.ToLastname.Text = "-";
            // 
            // ToAcHoldername
            // 
            this.ToAcHoldername.AutoSize = true;
            this.ToAcHoldername.BackColor = System.Drawing.Color.DarkCyan;
            this.ToAcHoldername.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ToAcHoldername.ForeColor = System.Drawing.Color.Transparent;
            this.ToAcHoldername.Location = new System.Drawing.Point(17, 14);
            this.ToAcHoldername.Name = "ToAcHoldername";
            this.ToAcHoldername.Size = new System.Drawing.Size(25, 33);
            this.ToAcHoldername.TabIndex = 22;
            this.ToAcHoldername.Text = "-";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkCyan;
            this.panel5.Controls.Add(this.ToAccountBal);
            this.panel5.Location = new System.Drawing.Point(1312, 27);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(234, 56);
            this.panel5.TabIndex = 13;
            // 
            // ToAccountBal
            // 
            this.ToAccountBal.AutoSize = true;
            this.ToAccountBal.BackColor = System.Drawing.Color.DarkCyan;
            this.ToAccountBal.Font = new System.Drawing.Font("Calisto MT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ToAccountBal.ForeColor = System.Drawing.Color.Transparent;
            this.ToAccountBal.Location = new System.Drawing.Point(13, 9);
            this.ToAccountBal.Name = "ToAccountBal";
            this.ToAccountBal.Size = new System.Drawing.Size(26, 37);
            this.ToAccountBal.TabIndex = 24;
            this.ToAccountBal.Text = "-";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Teal;
            this.label5.Font = new System.Drawing.Font("Century Schoolbook", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.OldLace;
            this.label5.Location = new System.Drawing.Point(1064, 44);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(242, 30);
            this.label5.TabIndex = 23;
            this.label5.Text = "Account Balance : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Teal;
            this.label2.Font = new System.Drawing.Font("Century Schoolbook", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.OldLace;
            this.label2.Location = new System.Drawing.Point(40, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(307, 30);
            this.label2.TabIndex = 21;
            this.label2.Text = "Account Holder Name : ";
            // 
            // ToAccountBalancetextbox
            // 
            this.ToAccountBalancetextbox.BackColor = System.Drawing.Color.CadetBlue;
            this.ToAccountBalancetextbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ToAccountBalancetextbox.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ToAccountBalancetextbox.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.ToAccountBalancetextbox.Location = new System.Drawing.Point(823, 61);
            this.ToAccountBalancetextbox.MaxLength = 15;
            this.ToAccountBalancetextbox.Name = "ToAccountBalancetextbox";
            this.ToAccountBalancetextbox.Size = new System.Drawing.Size(510, 43);
            this.ToAccountBalancetextbox.TabIndex = 20;
            this.ToAccountBalancetextbox.TextChanged += new System.EventHandler(this.ToAccountBalancetextbox_TextChanged);
            this.ToAccountBalancetextbox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ToAccountBalancetextbox_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkCyan;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.OldLace;
            this.label1.Location = new System.Drawing.Point(309, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(497, 43);
            this.label1.TabIndex = 4;
            this.label1.Text = "Enter Account Number : ";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.label44);
            this.panel1.Controls.Add(this.label45);
            this.panel1.Location = new System.Drawing.Point(491, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(834, 82);
            this.panel1.TabIndex = 15;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.Teal;
            this.label44.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.Chartreuse;
            this.label44.Location = new System.Drawing.Point(122, 14);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(270, 43);
            this.label44.TabIndex = 3;
            this.label44.Text = "GIR BANK  - ";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Teal;
            this.label45.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.OldLace;
            this.label45.Location = new System.Drawing.Point(379, 14);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(350, 43);
            this.label45.TabIndex = 2;
            this.label45.Text = "Transfer Amount";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Teal;
            this.panel4.Controls.Add(this.label7);
            this.panel4.Location = new System.Drawing.Point(1382, 12);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(272, 82);
            this.panel4.TabIndex = 55;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(31, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(212, 33);
            this.label7.TabIndex = 22;
            this.label7.Text = "Exit - (Ctrl + X)";
            // 
            // Transfer_Amount_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(1904, 1100);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Transfer_Amount_Form";
            this.Text = "Transfer_Amount_Form";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Transfer_Amount_Form_Load);
            this.panel2.ResumeLayout(false);
            this.Logout_Panel.ResumeLayout(false);
            this.Logout_Panel.PerformLayout();
            this.FromPanel.ResumeLayout(false);
            this.FromPanel.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.FromDetailPanel.ResumeLayout(false);
            this.FromDetailPanel.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.Submit_Button_Panel.ResumeLayout(false);
            this.Submit_Button_Panel.PerformLayout();
            this.Deposite_Panel.ResumeLayout(false);
            this.Deposite_Panel.PerformLayout();
            this.ToPanel.ResumeLayout(false);
            this.ToPanel.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.ToNameDetailPanel.ResumeLayout(false);
            this.ToNameDetailPanel.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel ToNameDetailPanel;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label ToLastname;
        private System.Windows.Forms.Label ToAcHoldername;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label ToAccountBal;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel Submit_Button_Panel;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label Captcha;
        public System.Windows.Forms.TextBox text_Captcha;
        private System.Windows.Forms.Panel Deposite_Panel;
        public System.Windows.Forms.TextBox DebitAmount;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel ToPanel;
        public System.Windows.Forms.TextBox ToAccountBalancetextbox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Panel FromPanel;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel FromDetailPanel;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label FromLastname;
        private System.Windows.Forms.Label FromAcHoldername;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label FromAccountBal;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        public System.Windows.Forms.TextBox FromAccountBalancetextbox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel Logout_Panel;
        private System.Windows.Forms.Label label8;
    }
}