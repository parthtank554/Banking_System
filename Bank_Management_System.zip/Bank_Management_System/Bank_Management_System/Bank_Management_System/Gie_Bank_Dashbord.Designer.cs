﻿namespace Bank_Management_System
{
    partial class Gie_Bank_Dashbord
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblusername = new System.Windows.Forms.Label();
            this.New_User_Link = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.BtnLogin = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.Remove_Ac = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.View_Ac_History = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.Transfer_Amount = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.View_Ac_Details = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.Withdrawal_Amount = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.Deposite_Amount = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.Check_Ac_Balance = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.Search_Ac_Details = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Open_New_Account = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.panel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.panel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.lblusername);
            this.panel1.Controls.Add(this.New_User_Link);
            this.panel1.Location = new System.Drawing.Point(59, 15);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(521, 92);
            this.panel1.TabIndex = 0;
            // 
            // lblusername
            // 
            this.lblusername.AutoSize = true;
            this.lblusername.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblusername.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblusername.ForeColor = System.Drawing.Color.Azure;
            this.lblusername.Location = new System.Drawing.Point(179, 25);
            this.lblusername.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblusername.Name = "lblusername";
            this.lblusername.Size = new System.Drawing.Size(204, 43);
            this.lblusername.TabIndex = 9;
            this.lblusername.Text = "Username";
            // 
            // New_User_Link
            // 
            this.New_User_Link.AutoSize = true;
            this.New_User_Link.Cursor = System.Windows.Forms.Cursors.Hand;
            this.New_User_Link.Font = new System.Drawing.Font("Century", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.New_User_Link.ForeColor = System.Drawing.Color.Yellow;
            this.New_User_Link.Location = new System.Drawing.Point(20, 25);
            this.New_User_Link.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.New_User_Link.Name = "New_User_Link";
            this.New_User_Link.Size = new System.Drawing.Size(134, 44);
            this.New_User_Link.TabIndex = 8;
            this.New_User_Link.Text = "Hello !";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Teal;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(617, 15);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1353, 92);
            this.panel2.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.DarkCyan;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 33.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Cyan;
            this.label2.Location = new System.Drawing.Point(73, 14);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(1158, 66);
            this.label2.TabIndex = 3;
            this.label2.Text = "Welcome !  To Bank Management System";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Teal;
            this.panel3.Controls.Add(this.BtnLogin);
            this.panel3.Location = new System.Drawing.Point(2001, 15);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(528, 92);
            this.panel3.TabIndex = 1;
            // 
            // BtnLogin
            // 
            this.BtnLogin.BackColor = System.Drawing.Color.CadetBlue;
            this.BtnLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnLogin.Font = new System.Drawing.Font("Century Schoolbook", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnLogin.ForeColor = System.Drawing.Color.Black;
            this.BtnLogin.Location = new System.Drawing.Point(20, 12);
            this.BtnLogin.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.BtnLogin.Name = "BtnLogin";
            this.BtnLogin.Size = new System.Drawing.Size(489, 66);
            this.BtnLogin.TabIndex = 25;
            this.BtnLogin.Text = "Logout !";
            this.BtnLogin.UseVisualStyleBackColor = false;
            this.BtnLogin.Click += new System.EventHandler(this.BtnLogin_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Teal;
            this.panel4.Controls.Add(this.panel14);
            this.panel4.Controls.Add(this.panel11);
            this.panel4.Controls.Add(this.panel9);
            this.panel4.Controls.Add(this.panel12);
            this.panel4.Controls.Add(this.panel13);
            this.panel4.Controls.Add(this.panel10);
            this.panel4.Controls.Add(this.panel8);
            this.panel4.Controls.Add(this.panel7);
            this.panel4.Controls.Add(this.panel6);
            this.panel4.Controls.Add(this.panel5);
            this.panel4.Location = new System.Drawing.Point(59, 130);
            this.panel4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(2471, 1125);
            this.panel4.TabIndex = 9;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.DarkCyan;
            this.panel14.Controls.Add(this.Remove_Ac);
            this.panel14.Controls.Add(this.pictureBox9);
            this.panel14.Location = new System.Drawing.Point(1793, 779);
            this.panel14.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(616, 293);
            this.panel14.TabIndex = 12;
            // 
            // Remove_Ac
            // 
            this.Remove_Ac.AutoSize = true;
            this.Remove_Ac.BackColor = System.Drawing.Color.DarkCyan;
            this.Remove_Ac.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Remove_Ac.Font = new System.Drawing.Font("Arial Unicode MS", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Remove_Ac.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Remove_Ac.Location = new System.Drawing.Point(352, 78);
            this.Remove_Ac.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Remove_Ac.Name = "Remove_Ac";
            this.Remove_Ac.Size = new System.Drawing.Size(194, 177);
            this.Remove_Ac.TabIndex = 17;
            this.Remove_Ac.Text = "Remove\r\nAccount \r\n\r\n";
            this.Remove_Ac.Click += new System.EventHandler(this.Remove_Ac_Click);
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::Bank_Management_System.Properties.Resources.remove_friend2;
            this.pictureBox9.Location = new System.Drawing.Point(32, 31);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(268, 238);
            this.pictureBox9.TabIndex = 10;
            this.pictureBox9.TabStop = false;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.DarkCyan;
            this.panel11.Controls.Add(this.View_Ac_History);
            this.panel11.Controls.Add(this.pictureBox8);
            this.panel11.Location = new System.Drawing.Point(953, 779);
            this.panel11.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(616, 293);
            this.panel11.TabIndex = 11;
            // 
            // View_Ac_History
            // 
            this.View_Ac_History.AutoSize = true;
            this.View_Ac_History.BackColor = System.Drawing.Color.DarkCyan;
            this.View_Ac_History.Cursor = System.Windows.Forms.Cursors.Hand;
            this.View_Ac_History.Font = new System.Drawing.Font("Arial Unicode MS", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.View_Ac_History.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.View_Ac_History.Location = new System.Drawing.Point(337, 57);
            this.View_Ac_History.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.View_Ac_History.Name = "View_Ac_History";
            this.View_Ac_History.Size = new System.Drawing.Size(194, 177);
            this.View_Ac_History.TabIndex = 16;
            this.View_Ac_History.Text = "View\r\nAccount \r\nHistory\r\n";
            this.View_Ac_History.Click += new System.EventHandler(this.View_Ac_History_Click);
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::Bank_Management_System.Properties.Resources.history2;
            this.pictureBox8.Location = new System.Drawing.Point(31, 31);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(265, 238);
            this.pictureBox8.TabIndex = 10;
            this.pictureBox8.TabStop = false;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.DarkCyan;
            this.panel9.Controls.Add(this.Transfer_Amount);
            this.panel9.Controls.Add(this.pictureBox6);
            this.panel9.Location = new System.Drawing.Point(1793, 412);
            this.panel9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(616, 293);
            this.panel9.TabIndex = 10;
            // 
            // Transfer_Amount
            // 
            this.Transfer_Amount.AutoSize = true;
            this.Transfer_Amount.BackColor = System.Drawing.Color.DarkCyan;
            this.Transfer_Amount.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Transfer_Amount.Font = new System.Drawing.Font("Arial Unicode MS", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Transfer_Amount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Transfer_Amount.Location = new System.Drawing.Point(372, 75);
            this.Transfer_Amount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Transfer_Amount.Name = "Transfer_Amount";
            this.Transfer_Amount.Size = new System.Drawing.Size(188, 118);
            this.Transfer_Amount.TabIndex = 16;
            this.Transfer_Amount.Text = "Transfer\r\nAmount\r\n";
            this.Transfer_Amount.Click += new System.EventHandler(this.Transfer_Amount_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Bank_Management_System.Properties.Resources.transfer1;
            this.pictureBox6.Location = new System.Drawing.Point(32, 39);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(268, 235);
            this.pictureBox6.TabIndex = 10;
            this.pictureBox6.TabStop = false;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.DarkCyan;
            this.panel12.Controls.Add(this.View_Ac_Details);
            this.panel12.Controls.Add(this.pictureBox7);
            this.panel12.Location = new System.Drawing.Point(71, 779);
            this.panel12.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(616, 293);
            this.panel12.TabIndex = 12;
            // 
            // View_Ac_Details
            // 
            this.View_Ac_Details.AutoSize = true;
            this.View_Ac_Details.BackColor = System.Drawing.Color.DarkCyan;
            this.View_Ac_Details.Cursor = System.Windows.Forms.Cursors.Hand;
            this.View_Ac_Details.Font = new System.Drawing.Font("Arial Unicode MS", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.View_Ac_Details.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.View_Ac_Details.Location = new System.Drawing.Point(345, 57);
            this.View_Ac_Details.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.View_Ac_Details.Name = "View_Ac_Details";
            this.View_Ac_Details.Size = new System.Drawing.Size(194, 177);
            this.View_Ac_Details.TabIndex = 15;
            this.View_Ac_Details.Text = "View\r\nAccount \r\nDetails\r\n";
            this.View_Ac_Details.Click += new System.EventHandler(this.View_Ac_Details_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Bank_Management_System.Properties.Resources.passbook3;
            this.pictureBox7.Location = new System.Drawing.Point(31, 31);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(263, 217);
            this.pictureBox7.TabIndex = 10;
            this.pictureBox7.TabStop = false;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.DarkCyan;
            this.panel13.Location = new System.Drawing.Point(-768, 770);
            this.panel13.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(616, 293);
            this.panel13.TabIndex = 13;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.DarkCyan;
            this.panel10.Controls.Add(this.Withdrawal_Amount);
            this.panel10.Controls.Add(this.pictureBox5);
            this.panel10.Location = new System.Drawing.Point(953, 412);
            this.panel10.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(616, 293);
            this.panel10.TabIndex = 10;
            // 
            // Withdrawal_Amount
            // 
            this.Withdrawal_Amount.AutoSize = true;
            this.Withdrawal_Amount.BackColor = System.Drawing.Color.DarkCyan;
            this.Withdrawal_Amount.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Withdrawal_Amount.Font = new System.Drawing.Font("Arial Unicode MS", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Withdrawal_Amount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Withdrawal_Amount.Location = new System.Drawing.Point(337, 75);
            this.Withdrawal_Amount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Withdrawal_Amount.Name = "Withdrawal_Amount";
            this.Withdrawal_Amount.Size = new System.Drawing.Size(240, 118);
            this.Withdrawal_Amount.TabIndex = 15;
            this.Withdrawal_Amount.Text = "Withdrawal\r\nAmount\r\n";
            this.Withdrawal_Amount.Click += new System.EventHandler(this.Withdrawal_Amount_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Bank_Management_System.Properties.Resources.pay1;
            this.pictureBox5.Location = new System.Drawing.Point(31, 25);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(265, 235);
            this.pictureBox5.TabIndex = 11;
            this.pictureBox5.TabStop = false;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.DarkCyan;
            this.panel8.Controls.Add(this.Deposite_Amount);
            this.panel8.Controls.Add(this.pictureBox4);
            this.panel8.Location = new System.Drawing.Point(71, 412);
            this.panel8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(616, 293);
            this.panel8.TabIndex = 10;
            // 
            // Deposite_Amount
            // 
            this.Deposite_Amount.AutoSize = true;
            this.Deposite_Amount.BackColor = System.Drawing.Color.DarkCyan;
            this.Deposite_Amount.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Deposite_Amount.Font = new System.Drawing.Font("Arial Unicode MS", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Deposite_Amount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Deposite_Amount.Location = new System.Drawing.Point(345, 75);
            this.Deposite_Amount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Deposite_Amount.Name = "Deposite_Amount";
            this.Deposite_Amount.Size = new System.Drawing.Size(196, 118);
            this.Deposite_Amount.TabIndex = 14;
            this.Deposite_Amount.Text = "Deposite\r\nAmount\r\n";
            this.Deposite_Amount.Click += new System.EventHandler(this.Deposite_Amount_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Bank_Management_System.Properties.Resources.salary1;
            this.pictureBox4.Location = new System.Drawing.Point(31, 25);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(263, 250);
            this.pictureBox4.TabIndex = 10;
            this.pictureBox4.TabStop = false;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.DarkCyan;
            this.panel7.Controls.Add(this.Check_Ac_Balance);
            this.panel7.Controls.Add(this.pictureBox3);
            this.panel7.Location = new System.Drawing.Point(1793, 52);
            this.panel7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(616, 293);
            this.panel7.TabIndex = 10;
            // 
            // Check_Ac_Balance
            // 
            this.Check_Ac_Balance.AutoSize = true;
            this.Check_Ac_Balance.BackColor = System.Drawing.Color.DarkCyan;
            this.Check_Ac_Balance.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Check_Ac_Balance.Font = new System.Drawing.Font("Arial Unicode MS", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Check_Ac_Balance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Check_Ac_Balance.Location = new System.Drawing.Point(352, 38);
            this.Check_Ac_Balance.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Check_Ac_Balance.Name = "Check_Ac_Balance";
            this.Check_Ac_Balance.Size = new System.Drawing.Size(194, 295);
            this.Check_Ac_Balance.TabIndex = 13;
            this.Check_Ac_Balance.Text = "Check\r\nAccount \r\nBalance\r\n\r\n\r\n";
            this.Check_Ac_Balance.Click += new System.EventHandler(this.Check_Ac_Balance_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Bank_Management_System.Properties.Resources.rupee1;
            this.pictureBox3.Location = new System.Drawing.Point(32, 22);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(268, 242);
            this.pictureBox3.TabIndex = 11;
            this.pictureBox3.TabStop = false;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DarkCyan;
            this.panel6.Controls.Add(this.Search_Ac_Details);
            this.panel6.Controls.Add(this.pictureBox1);
            this.panel6.Location = new System.Drawing.Point(953, 52);
            this.panel6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(616, 293);
            this.panel6.TabIndex = 10;
            // 
            // Search_Ac_Details
            // 
            this.Search_Ac_Details.AutoSize = true;
            this.Search_Ac_Details.BackColor = System.Drawing.Color.DarkCyan;
            this.Search_Ac_Details.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Search_Ac_Details.Font = new System.Drawing.Font("Arial Unicode MS", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Search_Ac_Details.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Search_Ac_Details.Location = new System.Drawing.Point(337, 63);
            this.Search_Ac_Details.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Search_Ac_Details.Name = "Search_Ac_Details";
            this.Search_Ac_Details.Size = new System.Drawing.Size(232, 236);
            this.Search_Ac_Details.TabIndex = 12;
            this.Search_Ac_Details.Text = "Block And \r\nUnblock \r\nAccount\r\n\r\n";
            this.Search_Ac_Details.Click += new System.EventHandler(this.Search_Ac_Details_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Bank_Management_System.Properties.Resources.block_user1;
            this.pictureBox1.Location = new System.Drawing.Point(31, 22);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(265, 242);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkCyan;
            this.panel5.Controls.Add(this.Open_New_Account);
            this.panel5.Controls.Add(this.pictureBox2);
            this.panel5.Location = new System.Drawing.Point(71, 52);
            this.panel5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(616, 293);
            this.panel5.TabIndex = 9;
            // 
            // Open_New_Account
            // 
            this.Open_New_Account.AutoSize = true;
            this.Open_New_Account.BackColor = System.Drawing.Color.DarkCyan;
            this.Open_New_Account.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Open_New_Account.Font = new System.Drawing.Font("Arial Unicode MS", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Open_New_Account.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.Open_New_Account.Location = new System.Drawing.Point(333, 63);
            this.Open_New_Account.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Open_New_Account.Name = "Open_New_Account";
            this.Open_New_Account.Size = new System.Drawing.Size(231, 118);
            this.Open_New_Account.TabIndex = 11;
            this.Open_New_Account.Text = "Open New\r\nAccount\r\n";
            this.Open_New_Account.Click += new System.EventHandler(this.Open_New_Account_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Bank_Management_System.Properties.Resources.add_user4;
            this.pictureBox2.Location = new System.Drawing.Point(31, 22);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(248, 242);
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.Location = new System.Drawing.Point(2468, 1259);
            this.linkLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(63, 32);
            this.linkLabel1.TabIndex = 10;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = ">>>";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // Gie_Bank_Dashbord
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(1942, 1102);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Gie_Bank_Dashbord";
            this.Text = "Gie_Bank_Dashbord";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Gie_Bank_Dashbord_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label New_User_Link;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label Open_New_Account;
        private System.Windows.Forms.Label Search_Ac_Details;
        private System.Windows.Forms.Label Check_Ac_Balance;
        private System.Windows.Forms.Label Deposite_Amount;
        private System.Windows.Forms.Label Withdrawal_Amount;
        private System.Windows.Forms.Label Transfer_Amount;
        private System.Windows.Forms.Label View_Ac_Details;
        private System.Windows.Forms.Label View_Ac_History;
        private System.Windows.Forms.Label Remove_Ac;
        public System.Windows.Forms.Label lblusername;
        public System.Windows.Forms.Button BtnLogin;
        private System.Windows.Forms.LinkLabel linkLabel1;

    }
}