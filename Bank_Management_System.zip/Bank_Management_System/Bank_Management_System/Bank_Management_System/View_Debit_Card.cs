﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Bank_Management_System
{
    public partial class View_Debit_Card : Form
    {
        SqlConnection con;
        SqlCommand cmd,cmd2;
        SqlDataAdapter oda,oda2;
        DataTable dt,dt2;
        int i = 0;
        string blocklist = "",debitnumber = "";
        public View_Debit_Card()
        {
            InitializeComponent();
        }
        public void Block_List()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();

            cmd2 = new SqlCommand("select * from Block_Unblock_Status where Debit_Number='" + CheckAcBalance.Text + "'",con);
            oda2 = new SqlDataAdapter(cmd2);
            dt2 = new DataTable();
            oda2.Fill(dt2);

            foreach(DataRow dr in dt2.Rows)
            {
                blocklist = dr["Debit_Number"].ToString();
            }
        }
        public void Debit_Label_Visible_False()
        {
            Debit_Card_Panel.Visible = false;
            Debit_First_Name.Visible = false;
            Debit_Last_Name.Visible = false;
            Debit_Card_First_Number.Visible = false;
            Debit_Card_Secondt_Number.Visible = false;
            Debit_Card_Third_Number.Visible = false;
            Debit_Card_Fourth_Number.Visible = false;
            Valid_Upto_Date.Visible = false;
            Valid_Upto_Text_Label.Visible = false;
            Uniq_Id_Number.Visible = false;
            Debit_Card_CVV_Number.Visible = false;
           
        }
        public void Debit_Label_Visible_True()
        {
            Debit_Card_Panel.Visible = true;
            Debit_First_Name.Visible = true;
            Debit_Last_Name.Visible = true;
            Debit_Card_First_Number.Visible = true;
            Debit_Card_Secondt_Number.Visible = true;
            Debit_Card_Third_Number.Visible = true;
            Debit_Card_Fourth_Number.Visible = true;
            Valid_Upto_Date.Visible = true;
            Valid_Upto_Text_Label.Visible = true;
            Uniq_Id_Number.Visible = true;
            Debit_Card_CVV_Number.Visible = true;
        }
        private void View_Debit_Card_Load(object sender, EventArgs e)
        {
            CheckAcBalance.Focus();
            Debit_Label_Visible_False();
            Loding_Panel.Visible = false;
        }

        private void CheckAcBalance_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt32(CheckAcBalance.Text.Length) == 16)
            {
               
                 Block_List();
                 if (blocklist == CheckAcBalance.Text)
                 {
                     MessageBox.Show("Account Is Blocked...", "DeActivated", MessageBoxButtons.OK, MessageBoxIcon.Error);
                     CheckAcBalance.Enabled = true;
                     CheckAcBalance.Clear();
                     CheckAcBalance.Focus();
                 }
                 else
                 {
                     CheckAcBalance.Enabled = false;
                     con = new SqlConnection(Con_Class.cnn);
                     con.Open();

                     cmd = new SqlCommand("select * from Debit_Card_Apply where DebitNumber='" + CheckAcBalance.Text + "'", con);
                     oda = new SqlDataAdapter(cmd);
                     dt = new DataTable();
                     oda.Fill(dt);
                     foreach (DataRow dr in dt.Rows)
                     {
                         Debit_Card_First_Number.Text = dr["FirstNumber"].ToString();
                         Debit_Card_Secondt_Number.Text = dr["SecondNumber"].ToString();
                         Debit_Card_Third_Number.Text = dr["ThirdNumber"].ToString();
                         Debit_Card_Fourth_Number.Text = dr["FourthNumber"].ToString();
                         Debit_First_Name.Text = dr["Firstname"].ToString();
                         Debit_Last_Name.Text = dr["Lastname"].ToString();
                         Debit_Card_CVV_Number.Text = dr["CvvNumber"].ToString();
                         Uniq_Id_Number.Text = dr["UniqueNumber"].ToString();
                         Valid_Upto_Date.Text = dr["ValidUpto"].ToString();
                         debitnumber = dr["DebitNumber"].ToString();
                         Loding_Panel.Visible = true;
                         timer1.Start();
                     }
                     if (blocklist == debitnumber)
                     {
                         Loding_Panel.Visible = false;
                         timer1.Stop();
                         MessageBox.Show("Account Is Blocked....", "DeActivated", MessageBoxButtons.OK, MessageBoxIcon.Error);
                         Debit_Label_Visible_False();
                         CheckAcBalance.Enabled = true;
                         CheckAcBalance.Clear();
                         CheckAcBalance.Focus();
                         i = 0;
                     }
                     else
                     {
                         if (Loding_Panel.Visible == false)
                         {
                             MessageBox.Show("Account Not Found...?", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                             Debit_Label_Visible_False();
                             CheckAcBalance.Enabled = true;
                             CheckAcBalance.Clear();
                             CheckAcBalance.Focus();
                         }
                     }
                 }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            i++;
            if (i == 50)
            {

                Debit_Label_Visible_True();
                Loding_Panel.Visible = false;
                timer1.Stop();
                i = 0;
            }

        }

        private void CheckAcBalance_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                this.Close();
                Next_Page_Dashbord obj = new Next_Page_Dashbord();
                obj.Show();
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                MessageBox.Show("Please Logout First......", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                timer1.Stop();
                i = 0;
                Debit_Label_Visible_False();
                CheckAcBalance.Enabled = true;
                CheckAcBalance.Clear();
                CheckAcBalance.Focus();
                
            }
        }
    }
}
