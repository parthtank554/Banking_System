﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Bank_Management_System
{
    public partial class Customer_Ragistration_Form : Form
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        DataSet ds = new DataSet();
        string acnumber = "33021011000";
        public Customer_Ragistration_Form()
        {
            InitializeComponent();
        }
        public void exit()
        {
            this.Close();
            Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
            obj.Show();
        }
        public void resetdata()
        {

            txtFirstname.Clear();
            txtMiddlename.Clear();
            txtLastname.Clear();
            ComboGender.SelectedItem = "";
            txtDob.Text = "";
            txtMobileNumber.Text = "";
            txtEmailId.Text = "";
            txtAlternateNuber.Text = "";
            ComboContry.SelectedItem = "";
            txtState.Clear();
            txtDistric.Clear();
            txtTaluka.Clear();
            txtTawonCity.Clear();
            txtPincode.Clear();
            ComboAccountType.SelectedItem = "";
            AccountNumber.Clear();
            PancardNumber.Clear();
            AddharNumber.Clear();
            AcBalance.Clear();
            Occupation.Clear();
            Qulification.Clear();
            text_Captcha.Clear();
            txtLastname.Focus();
        }

        private void Customer_Ragistration_Form_Load(object sender, EventArgs e)
        {

            Random rand = new Random();
            int num = rand.Next(6, 7);
            int total = 0;
            string captcha = "";

            do
            {
                int chr = rand.Next(100, 123);
                if ((chr >= 48 && chr <= 57) || (chr >= 65 && chr <= 90) || (chr >= 97 && chr <= 122))
                {
                    captcha = captcha + (char)chr;
                    total++;
                    if (total == num)
                        break;
                    {

                    }
                }
            } while (true);
            Captcha.Text = captcha;
        }

        private void txtLastname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 48 && e.KeyChar <= 57)
            {
                e.Handled = true;
            }
        }

        private void txtFirstname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 48 && e.KeyChar <= 57)
            {
                e.Handled = true;
            }
        }

        private void txtMiddlename_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 48 && e.KeyChar <= 57)
            {
                e.Handled = true;
            }
        }

        private void txtDob_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122)
            {
                e.Handled = true;
            }
        }

        private void ComboGender_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 48 && e.KeyChar <= 57)
            {
                e.Handled = true;
            }
        }

        private void txtMobileNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122)
            {
                e.Handled = true;
            }
        }

        private void txtAlternateNuber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122)
            {
                e.Handled = true;
            }
        }

        private void ComboContry_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 48 && e.KeyChar <= 57)
            {
                e.Handled = true;
            }
        }

        private void txtState_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 48 && e.KeyChar <= 57)
            {
                e.Handled = true;
            }
        }

        private void txtDistric_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 48 && e.KeyChar <= 57)
            {
                e.Handled = true;
            }
        }

        private void txtTaluka_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 48 && e.KeyChar <= 57)
            {
                e.Handled = true;
            }
        }

        private void txtTawonCity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 48 && e.KeyChar <= 57)
            {
                e.Handled = true;
            }
        }

        private void txtPincode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122)
            {
                e.Handled = true;
            }
        }

        private void ComboAccountType_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 48 && e.KeyChar <= 57)
            {
                e.Handled = true;
            }
        }

        private void AccountNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122)
            {
                e.Handled = true;
            }
        }

        private void AddharNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122)
            {
                e.Handled = true;
            }
        }

        private void text_Captcha_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 48 && e.KeyChar <= 57)
            {
                e.Handled = true;
            }
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            this.OnLoad(e);
            txtLastname.Focus();
        }
        private void AcBalance_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122)
            {
                e.Handled = true;
            }
        }
        private void text_Captcha_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt32(text_Captcha.Text.Length) == 6)
            {
                if (txtFirstname.Text == "" || txtMiddlename.Text == "" || txtLastname.Text == "" || ComboGender.SelectedItem == "" || txtDob.Text == "" || txtMobileNumber.Text == "" || txtEmailId.Text == "" || ComboContry.SelectedItem == "" || txtState.Text == "" || txtDistric.Text == "" || txtTaluka.Text == "" || txtTawonCity.Text == "" || txtPincode.Text == "" || ComboAccountType.SelectedItem == "" || AccountNumber.Text == "" || PancardNumber.Text == "" || AddharNumber.Text == "" || Occupation.Text == "" || Qulification.Text == "" || AcBalance.Text == "")
                {
                    MessageBox.Show("Please Fillout All Madatory Field", "Blank record", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.OnLoad(e);
                    text_Captcha.Clear();
                    text_Captcha.Focus();
                }
                else
                {
                    if (text_Captcha.Text == "")
                    {
                        MessageBox.Show("Please Enter Captcha Code !!", "Captcha", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        text_Captcha.Focus();
                        this.OnLoad(e);
                    }
                    else
                    {
                        if (Captcha.Text != text_Captcha.Text)
                        {
                            MessageBox.Show("Incorrect Capcha Code !!", "Incorrect", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            text_Captcha.Clear();
                            text_Captcha.Focus();
                            this.OnLoad(e);
                        }
                        else
                        {
                            con = new SqlConnection(Con_Class.cnn);
                            con.Open();
                            string MixAc = acnumber + AccountNumber.Text;
                            cmd = new SqlCommand("insert into  Customer_Table values('" + txtLastname.Text + "','" + txtFirstname.Text + "','" + txtMiddlename.Text + "','" + txtDob.Text + "','" + ComboGender.SelectedItem + "','" + txtMobileNumber.Text + "','" + txtEmailId.Text + "','" + txtAlternateNuber.Text + "','" + ComboContry.SelectedItem + "','" + txtState.Text + "','" + txtDistric.Text + "', '" + txtTaluka.Text + "', '" + txtTawonCity.Text + "','" + txtPincode.Text + "','" + ComboAccountType.SelectedItem + "','" + MixAc + "', '" + PancardNumber.Text + "','" + AddharNumber.Text + "','" + Occupation.Text + "','" + Qulification.Text + "','" + AcBalance.Text + "')", con);
                            int res = cmd.ExecuteNonQuery();
                            if (res > 0)
                            {
                                MessageBox.Show("Detail Submited Successfully", "Detail Submited", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                txtFirstname.Clear();
                                txtMiddlename.Clear();
                                txtLastname.Clear();
                                ComboGender.SelectedItem = "";
                                AcBalance.Clear();
                                txtDob.Text = "";
                                txtMobileNumber.Text = "";
                                txtEmailId.Text = "";
                                txtAlternateNuber.Text = "";
                                ComboContry.SelectedItem = "";
                                txtState.Clear();
                                txtDistric.Clear();
                                txtTaluka.Clear();
                                txtTawonCity.Clear();
                                txtPincode.Clear();
                                ComboAccountType.SelectedItem = "";
                                AccountNumber.Clear();
                                PancardNumber.Clear();
                                AddharNumber.Clear();
                                Occupation.Clear();
                                Qulification.Clear();
                                text_Captcha.Clear();
                                this.OnLoad(e);
                                txtLastname.Focus();
                            }
                            else
                            {
                                MessageBox.Show("Somthing Went Wrong Please try Again...!", "404", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                txtFirstname.Clear();
                                txtMiddlename.Clear();
                                txtLastname.Clear();
                                AcBalance.Clear();
                                ComboGender.SelectedItem = "";
                                txtDob.Text = "";
                                txtMobileNumber.Text = "";
                                txtEmailId.Text = "";
                                txtAlternateNuber.Text = "";
                                ComboContry.SelectedItem = "";
                                txtState.Clear();
                                txtDistric.Clear();
                                txtTaluka.Clear();
                                txtTawonCity.Clear();
                                txtPincode.Clear();
                                ComboAccountType.SelectedItem = "";
                                AccountNumber.Clear();
                                PancardNumber.Clear();
                                AddharNumber.Clear();
                                Occupation.Clear();
                                Qulification.Clear();
                                text_Captcha.Clear();
                                this.OnLoad(e);
                                txtLastname.Focus();
                            }
                        }
                    }
                }

            }
        }


        private void txtLastname_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                this.Close();
                Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
                obj.Show();
            }
        }
    }
}
