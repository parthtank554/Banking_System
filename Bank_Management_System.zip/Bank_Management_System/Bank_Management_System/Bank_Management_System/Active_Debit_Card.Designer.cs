﻿namespace Bank_Management_System
{
    partial class Active_Debit_Card
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Reset_Panel = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.Exit_Panel = new System.Windows.Forms.Panel();
            this.lblexit = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.CheckAcBalance = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.Status_Panel = new System.Windows.Forms.Panel();
            this.lbl_Satus = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.Temper = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Reset_Panel.SuspendLayout();
            this.Exit_Panel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel6.SuspendLayout();
            this.Status_Panel.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // Reset_Panel
            // 
            this.Reset_Panel.BackColor = System.Drawing.Color.DarkCyan;
            this.Reset_Panel.Controls.Add(this.label3);
            this.Reset_Panel.Location = new System.Drawing.Point(1935, 23);
            this.Reset_Panel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Reset_Panel.Name = "Reset_Panel";
            this.Reset_Panel.Size = new System.Drawing.Size(437, 90);
            this.Reset_Panel.TabIndex = 68;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(33, 25);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(362, 37);
            this.label3.TabIndex = 25;
            this.label3.Text = "DeActivate  - (Ctrl + D)";
            // 
            // Exit_Panel
            // 
            this.Exit_Panel.BackColor = System.Drawing.Color.DarkCyan;
            this.Exit_Panel.Controls.Add(this.lblexit);
            this.Exit_Panel.Location = new System.Drawing.Point(21, 23);
            this.Exit_Panel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Exit_Panel.Name = "Exit_Panel";
            this.Exit_Panel.Size = new System.Drawing.Size(492, 90);
            this.Exit_Panel.TabIndex = 67;
            // 
            // lblexit
            // 
            this.lblexit.AutoSize = true;
            this.lblexit.BackColor = System.Drawing.Color.White;
            this.lblexit.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblexit.ForeColor = System.Drawing.Color.Red;
            this.lblexit.Location = new System.Drawing.Point(108, 25);
            this.lblexit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblexit.Name = "lblexit";
            this.lblexit.Size = new System.Drawing.Size(244, 37);
            this.lblexit.TabIndex = 25;
            this.lblexit.Text = "Exit  - (Ctrl + X)";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.label44);
            this.panel1.Controls.Add(this.label45);
            this.panel1.Location = new System.Drawing.Point(684, 15);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1264, 90);
            this.panel1.TabIndex = 66;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.Teal;
            this.label44.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.Chartreuse;
            this.label44.Location = new System.Drawing.Point(163, 11);
            this.label44.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(340, 56);
            this.label44.TabIndex = 3;
            this.label44.Text = "GIR BANK  - ";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Teal;
            this.label45.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.OldLace;
            this.label45.Location = new System.Drawing.Point(531, 11);
            this.label45.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(508, 112);
            this.label45.TabIndex = 2;
            this.label45.Text = "Activate Debit Card\r\n\r\n";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkCyan;
            this.panel3.Controls.Add(this.CheckAcBalance);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(427, 76);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1477, 102);
            this.panel3.TabIndex = 69;
            // 
            // CheckAcBalance
            // 
            this.CheckAcBalance.BackColor = System.Drawing.Color.CadetBlue;
            this.CheckAcBalance.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CheckAcBalance.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckAcBalance.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.CheckAcBalance.Location = new System.Drawing.Point(693, 27);
            this.CheckAcBalance.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.CheckAcBalance.MaxLength = 16;
            this.CheckAcBalance.Name = "CheckAcBalance";
            this.CheckAcBalance.Size = new System.Drawing.Size(736, 53);
            this.CheckAcBalance.TabIndex = 22;
            this.CheckAcBalance.TextChanged += new System.EventHandler(this.CheckAcBalance_TextChanged);
            this.CheckAcBalance.KeyDown += new System.Windows.Forms.KeyEventHandler(this.CheckAcBalance_KeyDown);
            this.CheckAcBalance.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CheckAcBalance_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkCyan;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.OldLace;
            this.label1.Location = new System.Drawing.Point(92, 25);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(559, 56);
            this.label1.TabIndex = 21;
            this.label1.Text = "Enter Card  Number : ";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Teal;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(2879, 560);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(431, 90);
            this.panel2.TabIndex = 70;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(83, 28);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(248, 37);
            this.label2.TabIndex = 25;
            this.label2.Text = "Exit  - (Ctrl + R)";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkCyan;
            this.panel4.Controls.Add(this.label4);
            this.panel4.Location = new System.Drawing.Point(669, 23);
            this.panel4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(492, 90);
            this.panel4.TabIndex = 69;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(83, 25);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(279, 37);
            this.label4.TabIndex = 25;
            this.label4.Text = "Reset  - (Ctrl + R)";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DarkCyan;
            this.panel6.Controls.Add(this.label6);
            this.panel6.Location = new System.Drawing.Point(1336, 23);
            this.panel6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(492, 90);
            this.panel6.TabIndex = 71;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(72, 25);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(295, 37);
            this.label6.TabIndex = 25;
            this.label6.Text = "Activte  - (Ctrl + X)";
            // 
            // Status_Panel
            // 
            this.Status_Panel.BackColor = System.Drawing.Color.DarkCyan;
            this.Status_Panel.Controls.Add(this.lbl_Satus);
            this.Status_Panel.Location = new System.Drawing.Point(1099, 348);
            this.Status_Panel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Status_Panel.Name = "Status_Panel";
            this.Status_Panel.Size = new System.Drawing.Size(364, 90);
            this.Status_Panel.TabIndex = 72;
            // 
            // lbl_Satus
            // 
            this.lbl_Satus.AutoSize = true;
            this.lbl_Satus.BackColor = System.Drawing.Color.White;
            this.lbl_Satus.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Satus.ForeColor = System.Drawing.Color.Red;
            this.lbl_Satus.Location = new System.Drawing.Point(67, 27);
            this.lbl_Satus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Satus.Name = "lbl_Satus";
            this.lbl_Satus.Size = new System.Drawing.Size(28, 37);
            this.lbl_Satus.TabIndex = 25;
            this.lbl_Satus.Text = "-";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.DarkCyan;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(783, 375);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(267, 37);
            this.label7.TabIndex = 73;
            this.label7.Text = "Current Ststus : \r\n";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Teal;
            this.panel7.Controls.Add(this.panel3);
            this.panel7.Controls.Add(this.label7);
            this.panel7.Controls.Add(this.Status_Panel);
            this.panel7.Location = new System.Drawing.Point(127, 385);
            this.panel7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(2411, 501);
            this.panel7.TabIndex = 73;
            // 
            // Temper
            // 
            this.Temper.BackColor = System.Drawing.Color.DarkCyan;
            this.Temper.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Temper.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Temper.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.Temper.Location = new System.Drawing.Point(1192, 1329);
            this.Temper.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Temper.MaxLength = 16;
            this.Temper.Name = "Temper";
            this.Temper.Size = new System.Drawing.Size(13, 53);
            this.Temper.TabIndex = 23;
            this.Temper.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Temper_KeyDown);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Teal;
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Controls.Add(this.Exit_Panel);
            this.panel5.Controls.Add(this.Reset_Panel);
            this.panel5.Controls.Add(this.panel4);
            this.panel5.Location = new System.Drawing.Point(127, 185);
            this.panel5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(2411, 145);
            this.panel5.TabIndex = 68;
            // 
            // Active_Debit_Card
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(1942, 1102);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.Temper);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Active_Debit_Card";
            this.Text = "Active_Debit_Card";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Active_Debit_Card_Load);
            this.Reset_Panel.ResumeLayout(false);
            this.Reset_Panel.PerformLayout();
            this.Exit_Panel.ResumeLayout(false);
            this.Exit_Panel.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.Status_Panel.ResumeLayout(false);
            this.Status_Panel.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel Reset_Panel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel Exit_Panel;
        private System.Windows.Forms.Label lblexit;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Panel panel3;
        public System.Windows.Forms.TextBox CheckAcBalance;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel Status_Panel;
        private System.Windows.Forms.Label lbl_Satus;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel7;
        public System.Windows.Forms.TextBox Temper;
        private System.Windows.Forms.Panel panel5;
    }
}