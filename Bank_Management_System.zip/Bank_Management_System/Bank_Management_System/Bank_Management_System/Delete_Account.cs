﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Globalization;

namespace Bank_Management_System
{
    public partial class Delete_Account : Form
    {
        SqlConnection con;
        SqlCommand cmd, comm, delete;
        SqlDataAdapter da;
        DataSet ds = new DataSet();
        int check = 0;
        string BlockList = "";
        public Delete_Account()
        {
            InitializeComponent();
        }
        public void Block_List()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();
            string qry = "select * from Blocke_Ac where BalockAcNumber='" + CheckAcBalance.Text + "'";
            comm = new SqlCommand(qry, con);
            DataTable dt = new DataTable();
            SqlDataAdapter oda = new SqlDataAdapter(comm);
            oda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                BlockList = dr["BalockAcNumber"].ToString();

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
            obj.Show();
        }

        private void Delete_Account_Load(object sender, EventArgs e)
        {
            AcDetailpanel.Enabled = false;
            Remove_Ac_Panel.Enabled = false;
            Withdrawal_Ac_Panel.Enabled = false;
            Logout_Ac_Panel.Enabled = false;
        }
        private void CheckAcBalance_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt16(CheckAcBalance.Text.Length) == 15)
            {
                Block_List();
                if (BlockList == CheckAcBalance.Text)
                {
                    MessageBox.Show("Account Is Blocked Please Contact Nearest Breansh !!", "DeActivated", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    AcDetailpanel.Enabled = false;
                    Remove_Ac_Panel.Enabled = false;
                    Withdrawal_Ac_Panel.Enabled = false;
                    Logout_Ac_Panel.Enabled = false;
                    CheckAcBalance.Clear();
                    CheckAcBalance.Focus();
                }
                else
                {

                    con = new SqlConnection(Con_Class.cnn);
                    con.Open();
                    string qry = "select * from Customer_Table where AcNumber='" + CheckAcBalance.Text + "'";
                    cmd = new SqlCommand(qry, con);
                    DataTable dt = new DataTable();
                    SqlDataAdapter oda = new SqlDataAdapter(cmd);
                    oda.Fill(dt);
                    foreach (DataRow dr in dt.Rows)
                    {

                        string Bal = dr["AcBalance"].ToString();
                        check = Convert.ToInt32(dr["AcBalance"]);
                        Bal = string.Format(CultureInfo.CreateSpecificCulture("hi-IN"), "{0:C}", double.Parse(Bal));
                        AccountBal.Text = Bal;
                        AcHoldername.Text = dr["Firstname"].ToString();
                        Lastname.Text = dr["Lastname"].ToString();
                    }
                    Exit_Ac_Panel.Enabled = false;
                    CheckAcBalance.Enabled = false;
                    AcDetailpanel.Enabled = true;
                    Temp.Focus();
                    if (check > 0)
                    {
                        MessageBox.Show("Please Withdrawal Amount In This Account Before Withdrawal All Amount You Can  Not Remove This Account", "Not Procced", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        AcDetailpanel.Enabled = true;
                        Remove_Ac_Panel.Enabled = false;
                        Withdrawal_Ac_Panel.Enabled = true;
                        Logout_Ac_Panel.Enabled = true;
                        Exit_Ac_Panel.Enabled = false;
                    }
                    else
                    {
                        AcDetailpanel.Enabled = true;
                        Remove_Ac_Panel.Enabled = true;
                        Withdrawal_Ac_Panel.Enabled = false;
                        Logout_Ac_Panel.Enabled = true;
                        Exit_Ac_Panel.Enabled = false;
                    }
                    if (AccountBal.Text == "-")
                    {
                        AcDetailpanel.Enabled = false;
                        Remove_Ac_Panel.Enabled = false;
                        Withdrawal_Ac_Panel.Enabled = false;
                        Logout_Ac_Panel.Enabled = false;
                        MessageBox.Show("Account Not Found ? ", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        AcDetailpanel.Enabled = false;
                        Remove_Ac_Panel.Enabled = false;
                        Withdrawal_Ac_Panel.Enabled = false;
                        Logout_Ac_Panel.Enabled = false;
                        AcHoldername.Text = "-";
                        Lastname.Text = "-";
                        AccountBal.Text = "-";
                        CheckAcBalance.Enabled = true;
                        CheckAcBalance.Clear();
                        CheckAcBalance.Focus();
                        Exit_Ac_Panel.Enabled = true;

                    }
                }
            }
        }
        private void Temp_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.D)
            {
                if (MessageBox.Show("Conform ! Account Is Permenant Delete", "Remove", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    con = new SqlConnection(Con_Class.cnn);
                    con.Open();
                    delete = new SqlCommand("delete from Customer_Table where AcNumber='" + CheckAcBalance.Text + "'", con);
                    int res = delete.ExecuteNonQuery();
                    if (res > 0)
                    {
                        MessageBox.Show("Account Is SuccessFully Removed", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        AcDetailpanel.Enabled = false;
                        Remove_Ac_Panel.Enabled = false;
                        Withdrawal_Ac_Panel.Enabled = false;
                        Logout_Ac_Panel.Enabled = false;
                        CheckAcBalance.Enabled = true;
                        AcHoldername.Text = "-";
                        Lastname.Text = "-";
                        AccountBal.Text = "-";
                        CheckAcBalance.Clear();
                        CheckAcBalance.Focus();
                        Exit_Ac_Panel.Enabled = true;
                    }

                }
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                AcDetailpanel.Enabled = false;
                Remove_Ac_Panel.Enabled = false;
                Withdrawal_Ac_Panel.Enabled = false;
                Logout_Ac_Panel.Enabled = false;
                AcHoldername.Text = "-";
                Lastname.Text = "-";
                AccountBal.Text = "-";
                CheckAcBalance.Enabled = true;
                CheckAcBalance.Clear();
                CheckAcBalance.Focus();
                Exit_Ac_Panel.Enabled = true;
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.W)
            {
                this.Hide();
                Debit_Amount_Form obj = new Debit_Amount_Form();
                obj.Show();
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                if (AcHoldername.Text != "-")
                {
                    MessageBox.Show("Please Logout First", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {

                    this.Close();
                    Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
                    obj.Show();
                }
            }
        }

        private void CheckAcBalance_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                if (AcHoldername.Text != "-")
                {
                    MessageBox.Show("Please Logout First", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {

                    this.Close();
                    Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
                    obj.Show();
                }
            }
        }
    }
}

