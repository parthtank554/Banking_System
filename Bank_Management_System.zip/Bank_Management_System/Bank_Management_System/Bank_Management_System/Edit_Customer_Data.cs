﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Bank_Management_System
{
    public partial class Edit_Customer_Data : Form
    {
        SqlConnection con;
        SqlCommand cmd, comm;
        DataSet ds = new DataSet();
        string BlockList = "";
        public Edit_Customer_Data()
        {
            InitializeComponent();
        }
        public void Con()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();
        }
        public void ResetTextBoxValue()
        {
                txtfirstname.Text ="";
                txtmiddlename.Text = "";
                txtlastname.Text ="";
                txtdob.Text = "";
                txtmobile.Text = "";
                txtemail.Text = "";
                selectgender.SelectedItem = null;
                selectcontry.SelectedItem = null;
                txtstate.Text = "";
                txtdistric.Text =""; 
                txttaluka.Text ="";
                cityvillage.Text = "";
                selectactype.SelectedItem = null; 
                CheckAcBalance.Enabled = true;
                CheckAcBalance.Clear();
                CheckAcBalance.Focus();
        }
        public void resetdata()
        {
            lblaccounttype.Text = "--";
            lblcityvillage.Text = "--";
            lblcontry.Text = "--";
            lblDatOfBirth.Text = "--";
            lbldistric.Text =  "--";
            lblemailid.Text = "--";
            lblfirstname.Text = "--";
            lblgender.Text = "--";
            lbllastname.Text = "--";
            lblmiddlename.Text = "--";
            lblMobilenumber.Text = "--";
            lblstate.Text = "--";
            lbltaluka.Text = "--";
            categorypael.Enabled = false;
            oddvaluepanel.Enabled = false;
            newvaluepanel.Enabled = false;
            CheckAcBalance.Enabled = true;
            CheckAcBalance.Clear();
            CheckAcBalance.Focus();
            
        }
        public void exit()
        {
            this.Close();
            Next_Page_Dashbord obj = new Next_Page_Dashbord();
            obj.Show();
        }
        public void Block_List()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();
            string qry = "select * from Blocke_Ac where BalockAcNumber='" + CheckAcBalance.Text + "'";
            comm = new SqlCommand(qry, con);
            DataTable dt = new DataTable();
            SqlDataAdapter oda = new SqlDataAdapter(comm);
            oda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                BlockList = dr["BalockAcNumber"].ToString();

            }
        }
        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void CheckAcBalance_TextChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt16(CheckAcBalance.Text.Length) == 15)
            {

                Block_List();
                if (BlockList == CheckAcBalance.Text)
                {
                    MessageBox.Show("Account Is Blocked Please Try Another Account !! ", "DeActivated", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    CheckAcBalance.Clear();
                    CheckAcBalance.Enabled = true;
                    CheckAcBalance.Focus();
                    this.OnLoad(e);
                }
                else
                {
                    CheckAcBalance.Enabled = false;
                    con = new SqlConnection(Con_Class.cnn);
                    con.Open();
                    string qry = "select * from Customer_Table where AcNumber='" + CheckAcBalance.Text + "'";
                    cmd = new SqlCommand(qry, con);
                    DataTable dt = new DataTable();
                    SqlDataAdapter oda = new SqlDataAdapter(cmd);
                    oda.Fill(dt);
                    foreach (DataRow dr in dt.Rows)
                    {

                        categorypael.Enabled = true;
                        oddvaluepanel.Enabled = true;
                        newvaluepanel.Enabled = true;
                        lblfirstname.Text = dr["Firstname"].ToString();
                        lblmiddlename.Text = dr["Middlename"].ToString();
                        lbllastname.Text = dr["Lastname"].ToString();
                        lblDatOfBirth.Text = dr["Dob"].ToString();
                        lblgender.Text = dr["Gender"].ToString();
                        lblMobilenumber.Text = dr["MobileNumber"].ToString();
                        lblemailid.Text = dr["EmailId"].ToString();
                        lbltaluka.Text = dr["Taluka"].ToString();
                        lblcityvillage.Text = dr["City"].ToString();
                        lblcontry.Text = dr["Contry"].ToString();
                        lbldistric.Text = dr["Distric"].ToString();
                        lblstate.Text = dr["State"].ToString();
                        lblaccounttype.Text = dr["AcType"].ToString();
                        txtfirstname.Focus();
                    }
                    if (lblfirstname.Text == "--")
                    {
                        MessageBox.Show("Account Number Not Found Please Try Again....?", "Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        categorypael.Enabled = false;
                        oddvaluepanel.Enabled = false;
                        newvaluepanel.Enabled = false;
                        CheckAcBalance.Enabled = true;
                        CheckAcBalance.Clear();
                        CheckAcBalance.Focus();
                    }

                }
            }
        }

        private void Edit_Customer_Data_Load(object sender, EventArgs e)
        {
            categorypael.Enabled = false;
            oddvaluepanel.Enabled = false;
            newvaluepanel.Enabled = false;
        }

        private void txtfirstname_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                 resetdata();
                 ResetTextBoxValue();
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                if (lblfirstname.Text != "--")
                {
                    MessageBox.Show("Please Logout First You Can Not Exit Before Logout Please Logout First...!", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }

            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.S)
            {
                txtfirstname.Text = lblfirstname.Text;
                txtmiddlename.Text = lblmiddlename.Text;
                txtlastname.Text = lbllastname.Text;
                txtdob.Text = lblDatOfBirth.Text;
                txtmobile.Text = lblMobilenumber.Text;
                txtemail.Text = lblemailid.Text;
                selectgender.SelectedItem = lblgender.Text;
                selectcontry.SelectedItem = lblcontry.Text;
                txtstate.Text = lblstate.Text;
                txtdistric.Text = lbldistric.Text;
                txttaluka.Text = lbltaluka.Text;
                cityvillage.Text = lblcityvillage.Text;
                selectactype.SelectedItem = lblaccounttype.Text;
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.U)
            {
                con = new SqlConnection(Con_Class.cnn);
                con.Open();
                SqlCommand update;
                update = new SqlCommand("update Customer_Table set Firstname='" + txtfirstname.Text + "',Middlename='" + txtmiddlename.Text + "',Lastname='" + txtlastname.Text + "',Dob='" + txtdob.Text + "',Gender='" + selectgender.SelectedItem + "',MobileNumber='" + txtmobile.Text + "',EmailId='" + txtemail.Text + "',Taluka='" + txttaluka.Text + "',City='" + cityvillage.Text + "',Contry='" + selectcontry.SelectedItem + "',Distric='" + txtdistric.Text + "',State='" + txtstate.Text + "',AcType='" + selectactype.SelectedItem + "'  where AcNumber='" + CheckAcBalance.Text + "'", con);
                int res = update.ExecuteNonQuery();
                if (res > 0)
                {
                    MessageBox.Show("Data Updated Successfully", "Update", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    resetdata();
                    ResetTextBoxValue();
                }
                else
                {
                    MessageBox.Show("Somthing went wrong Please Try Again");
                    resetdata();
                    ResetTextBoxValue();
                }
                
            }
       }

        private void CheckAcBalance_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                this.Close();
                Next_Page_Dashbord obj = new Next_Page_Dashbord();
                obj.Show();
            }
        }
    }
}
