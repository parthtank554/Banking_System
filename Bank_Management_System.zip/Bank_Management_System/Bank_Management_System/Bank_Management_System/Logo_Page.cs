﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank_Management_System
{
    public partial class Logo_Page : Form
    {
        int i=0;
        public Logo_Page()
        {
            InitializeComponent();
        }

        private void Logo_Page_Load(object sender, EventArgs e)
        {
            label1.Visible = false;
            Loding_Buffring.Visible = false;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            i++;
           // label2.Text = i.ToString();
            if (i == 50)
            {
                label1.Visible = true;
                Loding_Buffring.Visible = true;
            }
            if (i == 100)
            {
                timer1.Stop();
                this.Hide();
                Form1 obj = new Form1();
                obj.Show();
            }

        }
    }
}
