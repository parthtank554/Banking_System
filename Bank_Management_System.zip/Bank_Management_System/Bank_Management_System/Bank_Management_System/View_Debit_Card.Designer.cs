﻿namespace Bank_Management_System
{
    partial class View_Debit_Card
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel8 = new System.Windows.Forms.Panel();
            this.Temper_TextBox = new System.Windows.Forms.TextBox();
            this.Debit_Card_Panel = new System.Windows.Forms.Panel();
            this.Debit_Card_CVV_Number = new System.Windows.Forms.Label();
            this.Debit_Last_Name = new System.Windows.Forms.Label();
            this.Debit_First_Name = new System.Windows.Forms.Label();
            this.Valid_Upto_Date = new System.Windows.Forms.Label();
            this.Valid_Upto_Text_Label = new System.Windows.Forms.Label();
            this.Uniq_Id_Number = new System.Windows.Forms.Label();
            this.Debit_Card_Fourth_Number = new System.Windows.Forms.Label();
            this.Debit_Card_Third_Number = new System.Windows.Forms.Label();
            this.Debit_Card_Secondt_Number = new System.Windows.Forms.Label();
            this.Debit_Card_First_Number = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.CheckAcBalance = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Loding_Panel = new System.Windows.Forms.Panel();
            this.test = new System.Windows.Forms.Label();
            this.Loding_Buffring = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel8.SuspendLayout();
            this.Debit_Card_Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.Loding_Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Loding_Buffring)).BeginInit();
            this.SuspendLayout();
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Teal;
            this.panel8.Controls.Add(this.Temper_TextBox);
            this.panel8.Controls.Add(this.Debit_Card_Panel);
            this.panel8.Location = new System.Drawing.Point(158, 290);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1659, 673);
            this.panel8.TabIndex = 60;
            // 
            // Temper_TextBox
            // 
            this.Temper_TextBox.BackColor = System.Drawing.Color.DarkCyan;
            this.Temper_TextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Temper_TextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 1.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Temper_TextBox.Location = new System.Drawing.Point(337, 667);
            this.Temper_TextBox.Name = "Temper_TextBox";
            this.Temper_TextBox.Size = new System.Drawing.Size(10, 3);
            this.Temper_TextBox.TabIndex = 26;
            // 
            // Debit_Card_Panel
            // 
            this.Debit_Card_Panel.BackColor = System.Drawing.Color.DarkCyan;
            this.Debit_Card_Panel.Controls.Add(this.Debit_Card_CVV_Number);
            this.Debit_Card_Panel.Controls.Add(this.Debit_Last_Name);
            this.Debit_Card_Panel.Controls.Add(this.Debit_First_Name);
            this.Debit_Card_Panel.Controls.Add(this.Valid_Upto_Date);
            this.Debit_Card_Panel.Controls.Add(this.Valid_Upto_Text_Label);
            this.Debit_Card_Panel.Controls.Add(this.Uniq_Id_Number);
            this.Debit_Card_Panel.Controls.Add(this.Debit_Card_Fourth_Number);
            this.Debit_Card_Panel.Controls.Add(this.Debit_Card_Third_Number);
            this.Debit_Card_Panel.Controls.Add(this.Debit_Card_Secondt_Number);
            this.Debit_Card_Panel.Controls.Add(this.Debit_Card_First_Number);
            this.Debit_Card_Panel.Controls.Add(this.pictureBox1);
            this.Debit_Card_Panel.Location = new System.Drawing.Point(14, 49);
            this.Debit_Card_Panel.Name = "Debit_Card_Panel";
            this.Debit_Card_Panel.Size = new System.Drawing.Size(1634, 583);
            this.Debit_Card_Panel.TabIndex = 60;
            // 
            // Debit_Card_CVV_Number
            // 
            this.Debit_Card_CVV_Number.AutoSize = true;
            this.Debit_Card_CVV_Number.BackColor = System.Drawing.Color.Black;
            this.Debit_Card_CVV_Number.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Debit_Card_CVV_Number.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Debit_Card_CVV_Number.Location = new System.Drawing.Point(1381, 180);
            this.Debit_Card_CVV_Number.Name = "Debit_Card_CVV_Number";
            this.Debit_Card_CVV_Number.Size = new System.Drawing.Size(66, 33);
            this.Debit_Card_CVV_Number.TabIndex = 15;
            this.Debit_Card_CVV_Number.Text = "652";
            // 
            // Debit_Last_Name
            // 
            this.Debit_Last_Name.AutoSize = true;
            this.Debit_Last_Name.BackColor = System.Drawing.Color.Black;
            this.Debit_Last_Name.Font = new System.Drawing.Font("Bookman Old Style", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Debit_Last_Name.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Debit_Last_Name.Location = new System.Drawing.Point(279, 462);
            this.Debit_Last_Name.Name = "Debit_Last_Name";
            this.Debit_Last_Name.Size = new System.Drawing.Size(163, 32);
            this.Debit_Last_Name.TabIndex = 14;
            this.Debit_Last_Name.Text = "KESHVALA";
            // 
            // Debit_First_Name
            // 
            this.Debit_First_Name.AutoSize = true;
            this.Debit_First_Name.BackColor = System.Drawing.Color.Black;
            this.Debit_First_Name.Font = new System.Drawing.Font("Bookman Old Style", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Debit_First_Name.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Debit_First_Name.Location = new System.Drawing.Point(153, 462);
            this.Debit_First_Name.Name = "Debit_First_Name";
            this.Debit_First_Name.Size = new System.Drawing.Size(111, 32);
            this.Debit_First_Name.TabIndex = 13;
            this.Debit_First_Name.Text = "RAHUL";
            // 
            // Valid_Upto_Date
            // 
            this.Valid_Upto_Date.AutoSize = true;
            this.Valid_Upto_Date.BackColor = System.Drawing.Color.Black;
            this.Valid_Upto_Date.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Valid_Upto_Date.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Valid_Upto_Date.Location = new System.Drawing.Point(410, 397);
            this.Valid_Upto_Date.Name = "Valid_Upto_Date";
            this.Valid_Upto_Date.Size = new System.Drawing.Size(87, 32);
            this.Valid_Upto_Date.TabIndex = 12;
            this.Valid_Upto_Date.Text = "07/28";
            // 
            // Valid_Upto_Text_Label
            // 
            this.Valid_Upto_Text_Label.AutoSize = true;
            this.Valid_Upto_Text_Label.BackColor = System.Drawing.Color.Black;
            this.Valid_Upto_Text_Label.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Valid_Upto_Text_Label.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Valid_Upto_Text_Label.Location = new System.Drawing.Point(342, 397);
            this.Valid_Upto_Text_Label.Name = "Valid_Upto_Text_Label";
            this.Valid_Upto_Text_Label.Size = new System.Drawing.Size(58, 36);
            this.Valid_Upto_Text_Label.TabIndex = 11;
            this.Valid_Upto_Text_Label.Text = "VALID\r\nUPTO\r\n";
            // 
            // Uniq_Id_Number
            // 
            this.Uniq_Id_Number.AutoSize = true;
            this.Uniq_Id_Number.BackColor = System.Drawing.Color.Black;
            this.Uniq_Id_Number.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Uniq_Id_Number.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Uniq_Id_Number.Location = new System.Drawing.Point(157, 373);
            this.Uniq_Id_Number.Name = "Uniq_Id_Number";
            this.Uniq_Id_Number.Size = new System.Drawing.Size(33, 12);
            this.Uniq_Id_Number.TabIndex = 10;
            this.Uniq_Id_Number.Text = "6522";
            // 
            // Debit_Card_Fourth_Number
            // 
            this.Debit_Card_Fourth_Number.AutoSize = true;
            this.Debit_Card_Fourth_Number.BackColor = System.Drawing.Color.Black;
            this.Debit_Card_Fourth_Number.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Debit_Card_Fourth_Number.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Debit_Card_Fourth_Number.Location = new System.Drawing.Point(410, 341);
            this.Debit_Card_Fourth_Number.Name = "Debit_Card_Fourth_Number";
            this.Debit_Card_Fourth_Number.Size = new System.Drawing.Size(79, 32);
            this.Debit_Card_Fourth_Number.TabIndex = 9;
            this.Debit_Card_Fourth_Number.Text = "6522";
            // 
            // Debit_Card_Third_Number
            // 
            this.Debit_Card_Third_Number.AutoSize = true;
            this.Debit_Card_Third_Number.BackColor = System.Drawing.Color.Black;
            this.Debit_Card_Third_Number.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Debit_Card_Third_Number.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Debit_Card_Third_Number.Location = new System.Drawing.Point(325, 341);
            this.Debit_Card_Third_Number.Name = "Debit_Card_Third_Number";
            this.Debit_Card_Third_Number.Size = new System.Drawing.Size(79, 32);
            this.Debit_Card_Third_Number.TabIndex = 8;
            this.Debit_Card_Third_Number.Text = "6522";
            // 
            // Debit_Card_Secondt_Number
            // 
            this.Debit_Card_Secondt_Number.AutoSize = true;
            this.Debit_Card_Secondt_Number.BackColor = System.Drawing.Color.Black;
            this.Debit_Card_Secondt_Number.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Debit_Card_Secondt_Number.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Debit_Card_Secondt_Number.Location = new System.Drawing.Point(238, 341);
            this.Debit_Card_Secondt_Number.Name = "Debit_Card_Secondt_Number";
            this.Debit_Card_Secondt_Number.Size = new System.Drawing.Size(79, 32);
            this.Debit_Card_Secondt_Number.TabIndex = 7;
            this.Debit_Card_Secondt_Number.Text = "6522";
            // 
            // Debit_Card_First_Number
            // 
            this.Debit_Card_First_Number.AutoSize = true;
            this.Debit_Card_First_Number.BackColor = System.Drawing.Color.Black;
            this.Debit_Card_First_Number.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Debit_Card_First_Number.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Debit_Card_First_Number.Location = new System.Drawing.Point(153, 341);
            this.Debit_Card_First_Number.Name = "Debit_Card_First_Number";
            this.Debit_Card_First_Number.Size = new System.Drawing.Size(79, 32);
            this.Debit_Card_First_Number.TabIndex = 6;
            this.Debit_Card_First_Number.Text = "8000";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Bank_Management_System.Properties.Resources.Screenshot__190_6;
            this.pictureBox1.Location = new System.Drawing.Point(31, 44);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1564, 508);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Teal;
            this.panel3.Controls.Add(this.CheckAcBalance);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(158, 153);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1421, 79);
            this.panel3.TabIndex = 62;
            // 
            // CheckAcBalance
            // 
            this.CheckAcBalance.BackColor = System.Drawing.Color.CadetBlue;
            this.CheckAcBalance.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CheckAcBalance.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckAcBalance.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.CheckAcBalance.Location = new System.Drawing.Point(855, 18);
            this.CheckAcBalance.MaxLength = 16;
            this.CheckAcBalance.Name = "CheckAcBalance";
            this.CheckAcBalance.Size = new System.Drawing.Size(510, 43);
            this.CheckAcBalance.TabIndex = 20;
            this.CheckAcBalance.TextChanged += new System.EventHandler(this.CheckAcBalance_TextChanged);
            this.CheckAcBalance.KeyDown += new System.Windows.Forms.KeyEventHandler(this.CheckAcBalance_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Teal;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.OldLace;
            this.label1.Location = new System.Drawing.Point(386, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(445, 43);
            this.label1.TabIndex = 4;
            this.label1.Text = "Enter Card  Number : ";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.label44);
            this.panel1.Controls.Add(this.label45);
            this.panel1.Location = new System.Drawing.Point(158, 32);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(948, 61);
            this.panel1.TabIndex = 61;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.Teal;
            this.label44.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.Chartreuse;
            this.label44.Location = new System.Drawing.Point(122, 9);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(270, 43);
            this.label44.TabIndex = 3;
            this.label44.Text = "GIR BANK  - ";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Teal;
            this.label45.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.OldLace;
            this.label45.Location = new System.Drawing.Point(398, 9);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(339, 86);
            this.label45.TabIndex = 2;
            this.label45.Text = "View Debit Card\r\n\r\n";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Teal;
            this.panel4.Controls.Add(this.label3);
            this.panel4.Location = new System.Drawing.Point(1125, 32);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(323, 61);
            this.panel4.TabIndex = 63;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(62, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(202, 32);
            this.label3.TabIndex = 22;
            this.label3.Text = "Exit - (Ctrl + X)";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Teal;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(1483, 32);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(323, 61);
            this.panel2.TabIndex = 64;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(39, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(232, 32);
            this.label2.TabIndex = 22;
            this.label2.Text = "Reset - (Ctrl + R)";
            // 
            // timer1
            // 
            this.timer1.Interval = 40;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Loding_Panel
            // 
            this.Loding_Panel.BackColor = System.Drawing.Color.DarkCyan;
            this.Loding_Panel.Controls.Add(this.test);
            this.Loding_Panel.Controls.Add(this.Loding_Buffring);
            this.Loding_Panel.Location = new System.Drawing.Point(1585, 143);
            this.Loding_Panel.Name = "Loding_Panel";
            this.Loding_Panel.Size = new System.Drawing.Size(232, 87);
            this.Loding_Panel.TabIndex = 65;
            // 
            // test
            // 
            this.test.AutoSize = true;
            this.test.BackColor = System.Drawing.Color.Black;
            this.test.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.test.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.test.Location = new System.Drawing.Point(48, 57);
            this.test.Name = "test";
            this.test.Size = new System.Drawing.Size(121, 24);
            this.test.TabIndex = 5;
            this.test.Text = "Loading....";
            // 
            // Loding_Buffring
            // 
            this.Loding_Buffring.BackColor = System.Drawing.Color.Black;
            this.Loding_Buffring.Image = global::Bank_Management_System.Properties.Resources._51929012;
            this.Loding_Buffring.Location = new System.Drawing.Point(85, 10);
            this.Loding_Buffring.Name = "Loding_Buffring";
            this.Loding_Buffring.Size = new System.Drawing.Size(40, 41);
            this.Loding_Buffring.TabIndex = 4;
            this.Loding_Buffring.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.DarkCyan;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.DarkCyan;
            this.textBox1.Location = new System.Drawing.Point(1013, 1047);
            this.textBox1.MaxLength = 16;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(10, 43);
            this.textBox1.TabIndex = 21;
            this.textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyDown);
            // 
            // View_Debit_Card
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(1887, 1056);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Loding_Panel);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel8);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "View_Debit_Card";
            this.Text = "View_Debit_Card";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.View_Debit_Card_Load);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.Debit_Card_Panel.ResumeLayout(false);
            this.Debit_Card_Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.Loding_Panel.ResumeLayout(false);
            this.Loding_Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Loding_Buffring)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox Temper_TextBox;
        private System.Windows.Forms.Panel Debit_Card_Panel;
        private System.Windows.Forms.Label Debit_Card_CVV_Number;
        private System.Windows.Forms.Label Debit_Last_Name;
        private System.Windows.Forms.Label Debit_First_Name;
        private System.Windows.Forms.Label Valid_Upto_Date;
        private System.Windows.Forms.Label Valid_Upto_Text_Label;
        private System.Windows.Forms.Label Uniq_Id_Number;
        private System.Windows.Forms.Label Debit_Card_Fourth_Number;
        private System.Windows.Forms.Label Debit_Card_Third_Number;
        private System.Windows.Forms.Label Debit_Card_Secondt_Number;
        private System.Windows.Forms.Label Debit_Card_First_Number;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        public System.Windows.Forms.TextBox CheckAcBalance;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel Loding_Panel;
        private System.Windows.Forms.Label test;
        private System.Windows.Forms.PictureBox Loding_Buffring;
        public System.Windows.Forms.TextBox textBox1;
    }
}