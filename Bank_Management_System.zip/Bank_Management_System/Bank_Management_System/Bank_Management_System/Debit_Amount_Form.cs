﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Globalization;

namespace Bank_Management_System
{
    public partial class Debit_Amount_Form : Form
    {
        SqlConnection con;
        SqlCommand cmd, comm, History;
        SqlDataAdapter da;
        DataSet ds = new DataSet();
        string BlockList = "";
        int Balanece = 0;
        string AcBalance = "";
        public Debit_Amount_Form()
        {
            InitializeComponent();
        }
        
        public void Block_List()
        {
            con = new SqlConnection(Con_Class.cnn);
            con.Open();
            string qry = "select * from Blocke_Ac where BalockAcNumber='" + CheckAcBalance.Text + "'";
            comm = new SqlCommand(qry, con);
            DataTable dt = new DataTable();
            SqlDataAdapter oda = new SqlDataAdapter(comm);
            oda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                BlockList = dr["BalockAcNumber"].ToString();

            }
        }
        private void Debit_Amount_Form_Load(object sender, EventArgs e)
        {
            Deposite_Panel.Enabled = false;
            Submit_Button.Enabled = false;
            Logout_Panel.Visible = false;
            Random rand = new Random();
            int num = rand.Next(6, 8);
            int total = 0;
            string captcha = "";

            do
            {
                int chr = rand.Next(100, 123);
                if ((chr >= 48 && chr <= 57) || (chr >= 65 && chr <= 90) || (chr >= 97 && chr <= 122))
                {
                    captcha = captcha + (char)chr;
                    total++;
                    if (total == num)
                        break;
                    {

                    }
                }
            } while (true);

            Captcha.Text = captcha;
        }


        private void DebitAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= 65 && e.KeyChar <= 90 || e.KeyChar >= 97 && e.KeyChar <= 122)
            {
                e.Handled = true;
            }
            e.Handled = !char.IsDigit(e.KeyChar) && e.KeyChar != (char)8;
         
        }

        private void CheckAcBalance_TextChanged_1(object sender, EventArgs e)
        {
            if (Convert.ToInt16(CheckAcBalance.Text.Length) == 15)
            {

                Block_List();
                if (BlockList == CheckAcBalance.Text)
                {
                    MessageBox.Show("Account Is Blocked Please Contact Nearest Breansh !!", "DeActivated", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Deposite_Panel.Enabled = false;
                    Logout_Panel.Visible = false;
                    Submit_Button.Enabled = false;
                    CheckAcBalance.Clear();
                    text_Captcha.Clear();
                    CheckAcBalance.Enabled = true;
                    CheckAcBalance.Focus();
                    this.OnLoad(e);
                }
                else
                {

                    CheckAcBalance.Enabled = false;
                    con = new SqlConnection(Con_Class.cnn);
                    con.Open();
                    string qry = "select * from Customer_Table where AcNumber='" + CheckAcBalance.Text + "'";
                    cmd = new SqlCommand(qry, con);
                    DataTable dt = new DataTable();
                    SqlDataAdapter oda = new SqlDataAdapter(cmd);
                    oda.Fill(dt);
                    foreach (DataRow dr in dt.Rows)
                    {

                        string Bal = dr["AcBalance"].ToString();
                        Bal = string.Format(CultureInfo.CreateSpecificCulture("hi-IN"), "{0:C}", double.Parse(Bal));
                        AccountBal.Text = Bal;
                        AcHoldername.Text = dr["Firstname"].ToString();
                        Lastname.Text = dr["Lastname"].ToString();
                        this.OnLoad(e);
                    }
                    Deposite_Panel.Enabled = true;
                    Logout_Panel.Visible = true;
                    Submit_Button.Enabled = true;
                    DebitAmount.Focus();
                    if (AcHoldername.Text == "-")
                    {
                        Deposite_Panel.Enabled = false;
                        Submit_Button.Enabled = false;
                        Logout_Panel.Visible = false;
                        MessageBox.Show("Account Number Not Found...!", "404 Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        CheckAcBalance.Clear();
                        CheckAcBalance.Enabled = true;
                        CheckAcBalance.Focus();
                        this.OnLoad(e);
                    }
                }
            }
        }
        private void CheckAcBalance_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                this.Close();
                Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
                obj.Show();
            }
        }

        private void text_Captcha_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                if (AcHoldername.Text != "-")
                {
                    MessageBox.Show("Please Logout First", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {

                    this.Close();
                    Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
                    obj.Show();
                }
               
            }
            {
                if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
                {
                    Deposite_Panel.Enabled = false;
                    Logout_Panel.Visible = false;
                    Submit_Button.Enabled = false;
                    CheckAcBalance.Clear();
                    text_Captcha.Clear();
                    CheckAcBalance.Enabled = true;
                    CheckAcBalance.Focus();
                    AcHoldername.Text = "-";
                    Lastname.Text = "-";
                    AccountBal.Text = "-";
                    this.OnLoad(e);
                }
                if (e.KeyCode == Keys.Enter)
                {
                    if (DebitAmount.Text == "")
                    {
                        MessageBox.Show("Please Enter Deposite Amount", "Invalid !!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        DebitAmount.Clear();
                        DebitAmount.Focus();
                        Logout_Panel.Visible = true;
                        text_Captcha.Clear();
                        this.OnLoad(e);
                    }
                    else
                    {
                        if (text_Captcha.Text == "")
                        {
                            MessageBox.Show("Please Enter Captcha Code !!", "Invalid Captcha !!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            text_Captcha.Focus();
                        }
                        else
                        {
                            if (text_Captcha.Text != Captcha.Text)
                            {
                                MessageBox.Show("Invalid Captcha!!", "Invalid Captcha !!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                text_Captcha.Clear();
                                text_Captcha.Focus();
                                Deposite_Panel.Enabled = true;
                                Logout_Panel.Visible = true;
                                this.OnLoad(e);
                            }
                            else
                            {

                                con = new SqlConnection(Con_Class.cnn);
                                con.Open();
                                string qry = "select AcBalance from Customer_Table where AcNumber='" + CheckAcBalance.Text + "'";
                                cmd = new SqlCommand(qry, con);
                                DataTable dt = new DataTable();
                                SqlDataAdapter oda = new SqlDataAdapter(cmd);
                                oda.Fill(dt);
                                foreach (DataRow dr in dt.Rows)
                                {
                                    Balanece = Convert.ToInt32(dr["AcBalance"].ToString());
                                    //AcNumber = Convert.ToInt32(DepositeAmount.Text);
                                    int UpdateBal = Balanece - Convert.ToInt32(DebitAmount.Text);
                                    AcBalance = UpdateBal.ToString();
                                }
                                cmd = new SqlCommand("update Customer_Table set AcBalance='" + AcBalance + "' where  AcNumber='" + CheckAcBalance.Text + "'", con);
                                string Date = DateTime.Now.ToLongDateString();
                                string Time = DateTime.Now.ToLongTimeString();
                                string Credit = "Debit";
                                History = new SqlCommand("insert into Ac_History values('" + Date + "','" + Time + "','" + AcHoldername.Text + "','" + CheckAcBalance.Text + "','" + Credit + "','" + DebitAmount.Text + "')", con);
                                History.ExecuteNonQuery();
                                int res = cmd.ExecuteNonQuery();
                                if (res > 0)
                                {
                                    MessageBox.Show("Trasaction Successful !", "Sccess", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    text_Captcha.Clear();
                                    this.OnLoad(e);
                                    Submit_Button.Enabled = false;
                                    Logout_Panel.Visible = true;
                                    DebitAmount.Clear();
                                    Deposite_Panel.Enabled = false;
                                    CheckAcBalance.Enabled = true;
                                    Logout_Panel.Visible = false;
                                    CheckAcBalance.Clear();
                                    AcHoldername.Text = "-";
                                    Lastname.Text = "-";
                                    AccountBal.Text = "-";
                                    CheckAcBalance.Focus();

                                }
                            }
                        }
                    }
                }
            }
        }

        private void DebitAmount_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.X)
            {
                if (AcHoldername.Text != "-")
                {
                    MessageBox.Show("Please Logout First", "Logout", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    this.Close();
                    Gie_Bank_Dashbord obj = new Gie_Bank_Dashbord();
                    obj.Show();
                }
            }
            if (e.Modifiers == Keys.Control && e.KeyCode == Keys.R)
            {
                Deposite_Panel.Enabled = false;
                Logout_Panel.Visible = false;
                Submit_Button.Enabled = false;
                CheckAcBalance.Clear();
                text_Captcha.Clear();
                CheckAcBalance.Enabled = true;
                CheckAcBalance.Focus();
                AcHoldername.Text = "-";
                Lastname.Text = "-";
                AccountBal.Text = "-";
                this.OnLoad(e);
            }
        }
    }
}


