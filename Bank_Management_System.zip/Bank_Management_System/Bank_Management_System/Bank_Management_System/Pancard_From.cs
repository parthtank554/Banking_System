﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank_Management_System
{
    public partial class Pancard_From : Form
    {
        public Pancard_From()
        {
            InitializeComponent();
        }

        private void btn_Clear_Click(object sender, EventArgs e)
        {
            Debit_Amount_Form obj = new Debit_Amount_Form();
            this.Close();
            obj.Show();
            obj.Acdetail_Panel.Enabled = true;
            obj.Deposite_Panel.Enabled = true;
            obj.Submit_Button.Enabled = true;
            obj.DebitAmount.Clear();
            obj.CheckAcBalance.Focus();
        }
    }
}
