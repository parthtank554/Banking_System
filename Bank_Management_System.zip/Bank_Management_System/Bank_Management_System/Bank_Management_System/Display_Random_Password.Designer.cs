﻿namespace Bank_Management_System
{
    partial class Display_Random_Password
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.LoginPassword = new System.Windows.Forms.TextBox();
            this.Reset_Password_Link = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblexit = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.LoginPassword);
            this.panel1.Controls.Add(this.Reset_Password_Link);
            this.panel1.Location = new System.Drawing.Point(24, 47);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(802, 82);
            this.panel1.TabIndex = 0;
            // 
            // LoginPassword
            // 
            this.LoginPassword.BackColor = System.Drawing.Color.CadetBlue;
            this.LoginPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.LoginPassword.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoginPassword.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.LoginPassword.Location = new System.Drawing.Point(495, 23);
            this.LoginPassword.Name = "LoginPassword";
            this.LoginPassword.Size = new System.Drawing.Size(216, 39);
            this.LoginPassword.TabIndex = 59;
            this.LoginPassword.KeyDown += new System.Windows.Forms.KeyEventHandler(this.LoginPassword_KeyDown_1);
            // 
            // Reset_Password_Link
            // 
            this.Reset_Password_Link.AutoSize = true;
            this.Reset_Password_Link.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Reset_Password_Link.Font = new System.Drawing.Font("Arial Rounded MT Bold", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Reset_Password_Link.ForeColor = System.Drawing.Color.LightCyan;
            this.Reset_Password_Link.Location = new System.Drawing.Point(39, 20);
            this.Reset_Password_Link.Name = "Reset_Password_Link";
            this.Reset_Password_Link.Size = new System.Drawing.Size(441, 40);
            this.Reset_Password_Link.TabIndex = 9;
            this.Reset_Password_Link.Text = "Enter  Varification Code :";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkCyan;
            this.panel2.Controls.Add(this.lblexit);
            this.panel2.Location = new System.Drawing.Point(285, 280);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(439, 75);
            this.panel2.TabIndex = 12;
            // 
            // lblexit
            // 
            this.lblexit.AutoSize = true;
            this.lblexit.BackColor = System.Drawing.Color.White;
            this.lblexit.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblexit.ForeColor = System.Drawing.Color.Red;
            this.lblexit.Location = new System.Drawing.Point(73, 20);
            this.lblexit.Name = "lblexit";
            this.lblexit.Size = new System.Drawing.Size(305, 37);
            this.lblexit.TabIndex = 27;
            this.lblexit.Text = "SUBMIT - (Ctrl + S)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label1.Font = new System.Drawing.Font("Century", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.LightCyan;
            this.label1.Location = new System.Drawing.Point(299, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(378, 33);
            this.label1.TabIndex = 21;
            this.label1.Text = "Check Your Email - Address\r\n";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Teal;
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.panel2);
            this.panel3.Location = new System.Drawing.Point(23, 96);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(977, 375);
            this.panel3.TabIndex = 40;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkCyan;
            this.panel5.Controls.Add(this.panel1);
            this.panel5.Location = new System.Drawing.Point(53, 67);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(872, 175);
            this.panel5.TabIndex = 41;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Teal;
            this.panel4.Controls.Add(this.label44);
            this.panel4.Controls.Add(this.label45);
            this.panel4.Location = new System.Drawing.Point(63, 12);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(851, 61);
            this.panel4.TabIndex = 10;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.Teal;
            this.label44.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.Chartreuse;
            this.label44.Location = new System.Drawing.Point(95, 9);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(270, 43);
            this.label44.TabIndex = 3;
            this.label44.Text = "GIR BANK  - ";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Teal;
            this.label45.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.OldLace;
            this.label45.Location = new System.Drawing.Point(383, 9);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(377, 43);
            this.label45.TabIndex = 2;
            this.label45.Text = "User - Varification\r\n";
            // 
            // Display_Random_Password
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(1051, 529);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Display_Random_Password";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Display_Random_Password";
            this.Load += new System.EventHandler(this.Display_Random_Password_Load_1);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label Reset_Password_Link;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblexit;
        public System.Windows.Forms.TextBox LoginPassword;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
    }
}