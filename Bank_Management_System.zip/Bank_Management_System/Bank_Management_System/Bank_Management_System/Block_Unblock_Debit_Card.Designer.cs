﻿namespace Bank_Management_System
{
    partial class Block_Unblock_Debit_Card
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Name_Detail_Panel = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Lastname = new System.Windows.Forms.Label();
            this.AcHoldername = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.DebitNumber = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.CheckAcBalance = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lblexit = new System.Windows.Forms.Label();
            this.Block_Unblock_Panel = new System.Windows.Forms.Panel();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.Captcha = new System.Windows.Forms.Label();
            this.text_Captcha = new System.Windows.Forms.TextBox();
            this.Unblock_Panel = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.Block_Panel = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.Name_Detail_Panel.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.Block_Unblock_Panel.SuspendLayout();
            this.Unblock_Panel.SuspendLayout();
            this.Block_Panel.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // Name_Detail_Panel
            // 
            this.Name_Detail_Panel.BackColor = System.Drawing.Color.Teal;
            this.Name_Detail_Panel.Controls.Add(this.panel2);
            this.Name_Detail_Panel.Controls.Add(this.panel5);
            this.Name_Detail_Panel.Controls.Add(this.label5);
            this.Name_Detail_Panel.Controls.Add(this.label2);
            this.Name_Detail_Panel.Location = new System.Drawing.Point(177, 419);
            this.Name_Detail_Panel.Name = "Name_Detail_Panel";
            this.Name_Detail_Panel.Size = new System.Drawing.Size(1659, 128);
            this.Name_Detail_Panel.TabIndex = 60;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkCyan;
            this.panel2.Controls.Add(this.Lastname);
            this.panel2.Controls.Add(this.AcHoldername);
            this.panel2.Location = new System.Drawing.Point(355, 33);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(500, 68);
            this.panel2.TabIndex = 25;
            // 
            // Lastname
            // 
            this.Lastname.AutoSize = true;
            this.Lastname.BackColor = System.Drawing.Color.DarkCyan;
            this.Lastname.Font = new System.Drawing.Font("Modern No. 20", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lastname.ForeColor = System.Drawing.Color.Transparent;
            this.Lastname.Location = new System.Drawing.Point(162, 11);
            this.Lastname.Name = "Lastname";
            this.Lastname.Size = new System.Drawing.Size(28, 36);
            this.Lastname.TabIndex = 25;
            this.Lastname.Text = "-";
            // 
            // AcHoldername
            // 
            this.AcHoldername.AutoSize = true;
            this.AcHoldername.BackColor = System.Drawing.Color.DarkCyan;
            this.AcHoldername.Font = new System.Drawing.Font("Modern No. 20", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AcHoldername.ForeColor = System.Drawing.Color.Transparent;
            this.AcHoldername.Location = new System.Drawing.Point(21, 14);
            this.AcHoldername.Name = "AcHoldername";
            this.AcHoldername.Size = new System.Drawing.Size(28, 36);
            this.AcHoldername.TabIndex = 22;
            this.AcHoldername.Text = "-";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkCyan;
            this.panel5.Controls.Add(this.DebitNumber);
            this.panel5.Location = new System.Drawing.Point(1241, 33);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(409, 68);
            this.panel5.TabIndex = 13;
            // 
            // DebitNumber
            // 
            this.DebitNumber.AutoSize = true;
            this.DebitNumber.BackColor = System.Drawing.Color.DarkCyan;
            this.DebitNumber.Font = new System.Drawing.Font("Calisto MT", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DebitNumber.ForeColor = System.Drawing.Color.Transparent;
            this.DebitNumber.Location = new System.Drawing.Point(13, 9);
            this.DebitNumber.Name = "DebitNumber";
            this.DebitNumber.Size = new System.Drawing.Size(26, 37);
            this.DebitNumber.TabIndex = 24;
            this.DebitNumber.Text = "-";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Teal;
            this.label5.Font = new System.Drawing.Font("Century Schoolbook", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.OldLace;
            this.label5.Location = new System.Drawing.Point(1010, 53);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(211, 30);
            this.label5.TabIndex = 23;
            this.label5.Text = "Card  Number : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Teal;
            this.label2.Font = new System.Drawing.Font("Century Schoolbook", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.OldLace;
            this.label2.Location = new System.Drawing.Point(42, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(307, 30);
            this.label2.TabIndex = 21;
            this.label2.Text = "Account Holder Name : ";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Teal;
            this.panel3.Controls.Add(this.CheckAcBalance);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Location = new System.Drawing.Point(177, 309);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1659, 91);
            this.panel3.TabIndex = 59;
            // 
            // CheckAcBalance
            // 
            this.CheckAcBalance.BackColor = System.Drawing.Color.CadetBlue;
            this.CheckAcBalance.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CheckAcBalance.Font = new System.Drawing.Font("Century Schoolbook", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckAcBalance.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.CheckAcBalance.Location = new System.Drawing.Point(820, 18);
            this.CheckAcBalance.MaxLength = 15;
            this.CheckAcBalance.Name = "CheckAcBalance";
            this.CheckAcBalance.Size = new System.Drawing.Size(510, 43);
            this.CheckAcBalance.TabIndex = 20;
            this.CheckAcBalance.TextChanged += new System.EventHandler(this.CheckAcBalance_TextChanged);
            this.CheckAcBalance.KeyDown += new System.Windows.Forms.KeyEventHandler(this.CheckAcBalance_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Teal;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.OldLace;
            this.label1.Location = new System.Drawing.Point(300, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(497, 43);
            this.label1.TabIndex = 4;
            this.label1.Text = "Enter Account Number : ";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Teal;
            this.panel1.Controls.Add(this.label44);
            this.panel1.Controls.Add(this.label45);
            this.panel1.Location = new System.Drawing.Point(177, 208);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(948, 73);
            this.panel1.TabIndex = 58;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.Teal;
            this.label44.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.Chartreuse;
            this.label44.Location = new System.Drawing.Point(122, 9);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(270, 43);
            this.label44.TabIndex = 3;
            this.label44.Text = "GIR BANK  - ";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Teal;
            this.label45.Font = new System.Drawing.Font("Century Schoolbook", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.OldLace;
            this.label45.Location = new System.Drawing.Point(398, 9);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(527, 43);
            this.label45.TabIndex = 2;
            this.label45.Text = "Block Unblock Debit Card";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Teal;
            this.panel6.Controls.Add(this.lblexit);
            this.panel6.Location = new System.Drawing.Point(1138, 208);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(369, 73);
            this.panel6.TabIndex = 61;
            // 
            // lblexit
            // 
            this.lblexit.AutoSize = true;
            this.lblexit.BackColor = System.Drawing.Color.White;
            this.lblexit.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblexit.ForeColor = System.Drawing.Color.Red;
            this.lblexit.Location = new System.Drawing.Point(81, 20);
            this.lblexit.Name = "lblexit";
            this.lblexit.Size = new System.Drawing.Size(191, 29);
            this.lblexit.TabIndex = 25;
            this.lblexit.Text = "Exit  - (Ctrl + X)";
            // 
            // Block_Unblock_Panel
            // 
            this.Block_Unblock_Panel.BackColor = System.Drawing.Color.Teal;
            this.Block_Unblock_Panel.Controls.Add(this.label39);
            this.Block_Unblock_Panel.Controls.Add(this.label40);
            this.Block_Unblock_Panel.Controls.Add(this.Captcha);
            this.Block_Unblock_Panel.Controls.Add(this.text_Captcha);
            this.Block_Unblock_Panel.Controls.Add(this.Unblock_Panel);
            this.Block_Unblock_Panel.Controls.Add(this.Block_Panel);
            this.Block_Unblock_Panel.Location = new System.Drawing.Point(177, 608);
            this.Block_Unblock_Panel.Name = "Block_Unblock_Panel";
            this.Block_Unblock_Panel.Size = new System.Drawing.Size(1659, 121);
            this.Block_Unblock_Panel.TabIndex = 64;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Calisto MT", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.Yellow;
            this.label39.Location = new System.Drawing.Point(262, 25);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(99, 17);
            this.label39.TabIndex = 54;
            this.label39.Text = "Captcha Code";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Calisto MT", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.Color.Yellow;
            this.label40.Location = new System.Drawing.Point(29, 23);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(77, 22);
            this.label40.TabIndex = 51;
            this.label40.Text = "Captcha";
            // 
            // Captcha
            // 
            this.Captcha.AutoSize = true;
            this.Captcha.BackColor = System.Drawing.Color.LightSkyBlue;
            this.Captcha.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Captcha.Font = new System.Drawing.Font("Buxton Sketch", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Captcha.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.Captcha.Location = new System.Drawing.Point(265, 42);
            this.Captcha.Name = "Captcha";
            this.Captcha.Size = new System.Drawing.Size(118, 45);
            this.Captcha.TabIndex = 52;
            this.Captcha.Text = "Captcha";
            // 
            // text_Captcha
            // 
            this.text_Captcha.BackColor = System.Drawing.Color.CadetBlue;
            this.text_Captcha.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.text_Captcha.Font = new System.Drawing.Font("Century Schoolbook", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_Captcha.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.text_Captcha.Location = new System.Drawing.Point(33, 48);
            this.text_Captcha.MaxLength = 7;
            this.text_Captcha.Name = "text_Captcha";
            this.text_Captcha.Size = new System.Drawing.Size(174, 39);
            this.text_Captcha.TabIndex = 53;
            this.text_Captcha.KeyDown += new System.Windows.Forms.KeyEventHandler(this.text_Captcha_KeyDown);
            // 
            // Unblock_Panel
            // 
            this.Unblock_Panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.Unblock_Panel.Controls.Add(this.label6);
            this.Unblock_Panel.Location = new System.Drawing.Point(1095, 18);
            this.Unblock_Panel.Name = "Unblock_Panel";
            this.Unblock_Panel.Size = new System.Drawing.Size(510, 81);
            this.Unblock_Panel.TabIndex = 50;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Yellow;
            this.label6.Location = new System.Drawing.Point(138, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(268, 33);
            this.label6.TabIndex = 23;
            this.label6.Text = "Unblock - (Ctrl+U)";
            // 
            // Block_Panel
            // 
            this.Block_Panel.BackColor = System.Drawing.Color.Red;
            this.Block_Panel.Controls.Add(this.label4);
            this.Block_Panel.Location = new System.Drawing.Point(535, 18);
            this.Block_Panel.Name = "Block_Panel";
            this.Block_Panel.Size = new System.Drawing.Size(522, 81);
            this.Block_Panel.TabIndex = 49;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Red;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Yellow;
            this.label4.Location = new System.Drawing.Point(133, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(230, 33);
            this.label4.TabIndex = 24;
            this.label4.Text = "Block - (Ctrl+B)";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Teal;
            this.panel4.Controls.Add(this.label3);
            this.panel4.Location = new System.Drawing.Point(1513, 208);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(323, 73);
            this.panel4.TabIndex = 62;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(62, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(194, 29);
            this.label3.TabIndex = 25;
            this.label3.Text = "Exit  - (Ctrl + R)";
            // 
            // Block_Unblock_Debit_Card
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(1887, 940);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.Block_Unblock_Panel);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.Name_Detail_Panel);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Block_Unblock_Debit_Card";
            this.Text = "Block_Unblock_Debit_Card";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Block_Unblock_Debit_Card_Load);
            this.Name_Detail_Panel.ResumeLayout(false);
            this.Name_Detail_Panel.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.Block_Unblock_Panel.ResumeLayout(false);
            this.Block_Unblock_Panel.PerformLayout();
            this.Unblock_Panel.ResumeLayout(false);
            this.Unblock_Panel.PerformLayout();
            this.Block_Panel.ResumeLayout(false);
            this.Block_Panel.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel Name_Detail_Panel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label Lastname;
        private System.Windows.Forms.Label AcHoldername;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label DebitNumber;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        public System.Windows.Forms.TextBox CheckAcBalance;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lblexit;
        private System.Windows.Forms.Panel Block_Unblock_Panel;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label Captcha;
        public System.Windows.Forms.TextBox text_Captcha;
        private System.Windows.Forms.Panel Unblock_Panel;
        private System.Windows.Forms.Panel Block_Panel;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
    }
}